# 📦 SPARKMIND-SOVEREIGN-MASTER-CONSOLIDATED-BUNDLE-v2.0

**Tanggal**: 2026-05-19
**Owner**: Reza Estes / Haidar — Sovereign AI Dev
**Status**: CANONICAL · EXECUTE-READY · PUBLIC-SAFE · **4-SUB-BRAND LOCKED**
**Supersedes**: MASTER-CONSOLIDATED v1.0 (3-sub-brand baseline)

═══════════════════════════════════════════════════════════════

## 🎯 APA INI?

Master consolidated bundle **v2.0** untuk SparkMind Sovereign Ecosystem — sintesis ulang penuh dari 20+ ZIP bundle dan 31 sources upload, dengan **lock permanen ke 4 sub-brand**:

| # | Sub-brand | Subdomain | Priority | Positioning |
|---|-----------|-----------|----------|-------------|
| 1 | **BarberKas** | `barberkas.sparkmind.web.id` | **P0** | Capster utama (asli) |
| 2 | **KuratorKas** | `kuratorkas.sparkmind.web.id` | **P1** | Sister-brand (AI Stylist + POS UMKM fashion) |
| 3 | **PaceLokal** | `pacelokal.sparkmind.web.id` | **P2** | Hobby (running OS Banyumas) |
| 4 | **Nurani.OS** | `nurani.os.sparkmind.web.id` | **P3** | Devotion (Tadarus-first, untuk Ibu) |

═══════════════════════════════════════════════════════════════

## 📁 STRUKTUR BUNDLE

```
SPARKMIND-SOVEREIGN-MASTER-CONSOLIDATED-BUNDLE-v2.0/
│
├── 00-master-doc/                      ← MULAI DI SINI
│   └── SPARKMIND-SOVEREIGN-MASTER-CONSOLIDATED-v2.0.md
│       └── 34 KB · 26 sections · paste-ready ke sesi AI manapun
│
├── 01-diff-report/
│   └── DIFF-REPORT-v1.0-to-v2.0-4SUB-BRAND-LOCK.md
│       └── Apa yang berubah dari v1.0 → v2.0 (full breakdown)
│
├── 02-gap-matrix/
│   └── GAP-MATRIX-v2.0-4SUB-BRAND.md
│       └── 42 gaps tracked (8 cross + 8 BK + 8 KK + 8 PL + 9 NU + 5 D)
│
├── 03-per-doc-index/
│   └── PER-DOC-INDEX-v2.0.md
│       └── Index lengkap 14 canonical DOCs + 29 Sovereign Engine docs
│
├── 04-source-manifest/
│   └── MANIFEST-v2.0.md
│       └── 31 sources catalogued (22 ZIP + 1 docx + 1 PDF + 7 txt)
│
├── 05-sub-brand-lock/                  ← THE LOCK ITSELF
│   └── SUB-BRAND-LOCK-v2.0.md
│       └── Immutable subdomain + priority declarations
│
├── 06-canonical-sources/               ← Reference offline
│   └── (key MD files copied dari extracted bundles)
│
└── BUNDLE-README.md                    ← (this file)
```

═══════════════════════════════════════════════════════════════

## 🚀 CARA PAKAI

### Skenario 1: Session AI Baru (Cold Start)

```
1. Paste seluruh isi `00-master-doc/SPARKMIND-SOVEREIGN-MASTER-CONSOLIDATED-v2.0.md`
2. AI output `[LAYER-0 INSPECT]` + `[CONSTITUTIONAL CHECK]`
3. Confirm doctrine snapshot (v2.0 loaded, 4-sub-brand locked)
4. Paste task spesifik:
   "@Sovereign-Architect v2.0
    Scope: kuratorkas
    Task: scaffold apps/kuratorkas/ dengan reverse-extract dari BK
    Cycle: full"
```

### Skenario 2: Session Continuation (Warm)

```
1. Paste `[HANDOFF]` block dari session sebelumnya
2. Paste hanya `## §01 CANONICAL CONTEXT` (sub-brand table v2.0)
3. AI auto-load via `.sovereign/doctrine.lock`
```

### Skenario 3: SOS Reset

```
Trigger: @SOS-Sovereign v2.0
Reset to canonical state.
```

### Skenario 4: Drill-Down Sub-brand

| Sub-brand | Drill-down ref |
|-----------|----------------|
| BarberKas | `00-master-doc §9.1` + `barberkas-bundle.zip` files |
| KuratorKas | `00-master-doc §9.2` + `kuratorkas-bundle.zip` (DOC-K) |
| PaceLokal | `00-master-doc §9.3` + `DOC-R-SOVEREIGN-RUNNING-BUNDLE` |
| Nurani.OS | `00-master-doc §9.4` + `DOC-S-SOVEREIGN-SPIRITUAL-OS-BUNDLE` |

═══════════════════════════════════════════════════════════════

## 🔑 KEY CHANGES dari v1.0

| Aspek | v1.0 | v2.0 |
|-------|------|------|
| Sub-brand count | 3 | **4** |
| Sub-brand list | BK, PL, NU | BK, **KK**, PL, NU |
| Priority basis | Phase-based | **Positioning-based** |
| Hard constraints | 12 | **14** (+#13 4-brand lock, +#14 priority lock) |
| Shared packages | 5 | **6** (+ `@sparkmind/curator-os`) |
| Parallel lanes | 3 | **4** (+ LANE K) |
| Cross-brand gaps | 7 | **8** (+ GAP-Z8) |
| Personas (1-user-N) | 3 | **4** |
| Health pillar weights | 8 (sum 100%) | 8 with KK weighted 12% |

**Detail lengkap**: lihat `01-diff-report/`

═══════════════════════════════════════════════════════════════

## ⚖️ DOCTRINE CONSTRAINTS (14 — semua hardcoded)

1. Stack Lock 100% Cloudflare
2. Repo Lock github.com/ganihypha/Sparkmind-Sovereign
3. No-Tracking, No-Ads-Default (Nurani.OS strict)
4. Halal-by-Default
5. NU + Muhammadiyah Dual-Acceptance (NU)
6. Public-Safe Doctrine (no PII Nurul/family)
7. Dual-PG Mandatory (Duitku + Xendit)
8. Monorepo SSOT (4 apps minimum: BK/KK/PL/NU)
9. Single-Operator Scalable
10. Revenue-First
11. Public-Safe Artifact (no secret leak)
12. Cost-Aware
13. **NEW v2.0**: 4-Sub-Brand Lock
14. **NEW v2.0**: Priority Order Lock (BK → KK → PL → NU)

═══════════════════════════════════════════════════════════════

## 📊 SOVEREIGN HEALTH SNAPSHOT

| Pillar | Weight | Current | Target D60 |
|--------|-------:|--------:|----------:|
| Cross-brand integration | 18% | 10/100 | 74/100 |
| BarberKas | 14% | 45/100 | 88/100 |
| **KuratorKas (NEW)** | **12%** | **0/100** | **70/100** |
| PaceLokal | 12% | 10/100 | 81/100 |
| Nurani.OS | 12% | 5/100 | 72/100 |
| Engineering discipline | 12% | 13/100 | 88/100 |
| Payment gateway | 10% | 0/100 | 85/100 |
| Doctrine & brand integrity | 10% | 51/100 | 88/100 |
| **Composite** | **100%** | **~28/100 RED** | **~78/100 GREEN** |

═══════════════════════════════════════════════════════════════

## 🗓 SPRINT TIMELINE D2 → D60

```
D2  ████░░░░░░░░░░░░░░░░░░░░░░░░░░░░  Start: 33/100 (now ~28/100 with KK new)
D7  █████░░░░░░░░░░░░░░░░░░░░░░░░░░  Foundation lane + 4-app skeleton
D15 ████████░░░░░░░░░░░░░░░░░░░░░░░  BK hardened, PL launch, KK init
D30 ███████████░░░░░░░░░░░░░░░░░░░░  BK MVP complete, KK reverse-extract done, PL MVP
D45 ████████████████░░░░░░░░░░░░░░░  KK Curator.OS 5 modules, PL complete, NU preview start
D60 ███████████████████████████░░░░  All 4 brands shipped, ~78/100 GREEN
```

═══════════════════════════════════════════════════════════════

## 🧭 NEXT ACTIONS (immediately post-bundle)

1. ✅ Register DNS: `kuratorkas.sparkmind.web.id`, `pacelokal.sparkmind.web.id`, `nurani.os.sparkmind.web.id` (Cloudflare)
2. ✅ Update monorepo: create `apps/kuratorkas/` + `packages/curator-os/`
3. ✅ Refresh dependent docs:
   - DOC-Y v1.0 → v1.2 (add LANE K)
   - DOC-Z v1.0 → v1.1 (6 shared packages)
   - DOC-S v1.0 → v1.1 (subdomain `.os` refresh)
   - MASTER-ARCHITECT-PROMPT v5.0 → v5.1 (4-sub-brand awareness)
   - DOC-AUDIT v2.0 → v2.1 (KK pillar weighted)
4. ✅ Decision-log entry (already in `SUB-BRAND-LOCK-v2.0.md`)
5. ✅ Resolve cross-brand P0 gaps before D15:
   - GAP-Z1 Shared identity (D10)
   - GAP-Z2 Shared payments (D14)
   - GAP-Z4 CI/CD untuk 4 apps (D15)
   - GAP-PL-1 PaceLokal subdomain (D15)
   - GAP-KK-1 KuratorKas subdomain (D17)

═══════════════════════════════════════════════════════════════

## 📜 MANTRA v2.0

> *"Empat sub-brand. Satu mother. Satu monorepo. Capster dulu. Sister-brand kedua. Hobby ketiga. Devotion terakhir. Lock. Execute."*

> *"Polyrepo adalah Trust Gap structural. Monorepo + packages/* + 4-app workspaces + consolidated doctrine = sovereign coherence."*
> — derived dari DOC-Z

═══════════════════════════════════════════════════════════════

**Bundle ready untuk eksekusi sprint D3 onwards.**

Doctrine date: 2026-05-19 · Owner: Reza Estes / Haidar — Sovereign AI Dev
Consolidated by: Sovereign AI Dev Co-Architect (Genspark re-synthesis session)

🔒 **4 SUB-BRAND LOCKED. PRIORITY LOCKED. EXECUTE.**
