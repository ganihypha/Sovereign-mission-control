# 🔒 SUB-BRAND LOCK v2.0 — SparkMind Sovereign Ecosystem

**Tanggal Lock**: 2026-05-19
**Owner**: Reza Estes / Haidar — Sovereign AI Dev
**Status**: **CANONICAL · IMMUTABLE · 4-SUB-BRAND LOCKED**
**Decision Type**: Architectural · Reversible: NO (requires explicit Haidar override + decision-log entry)

═══════════════════════════════════════════════════════════════

## 📌 LOCKED DECLARATION

Setelah deep dive synthesis dari 20+ ZIP bundle, 4 versi MASTER-ARCHITECT-PROMPT (v3.0 → v5.0), 14 canonical DOCs, dan 29 Sovereign Engine docs — **4 sub-brand SparkMind Sovereign Ecosystem dikunci permanen** dengan urutan prioritas berikut:

═══════════════════════════════════════════════════════════════

## 🥇 PRIORITY 0 — BARBERKAS (Capster Utama)

| Field | Value |
|-------|-------|
| **Subdomain (LOCKED)** | `barberkas.sparkmind.web.id` |
| **Tenant pattern** | `<tenant>.barberkas.sparkmind.web.id` |
| **Monorepo path** | `apps/barberkas/` |
| **Positioning** | Multi-tenant SaaS POS untuk barbershop Indonesia |
| **Persona Target** | Barbershop owner (UMKM jasa) |
| **Justifikasi P0** | Positioning asli Haidar; codebase paling matang (skor 45/100); **reverse-extract source** untuk packages shared lainnya |
| **Skor Saat Ini** | 45/100 AMBER |
| **Target D60** | 88/100 GREEN |
| **Doctrine Anchor** | BARBERKAS-CLOUDFLARE-NATIVE v2.0, DUAL-PG v1.0 |
| **PG Strategy** | Duitku primary (QRIS 0.7%) + Xendit fallback |
| **MVP Features** | Tenant onboarding, POS transaction, customer DB per-tenant, WhatsApp reminders (Fonnte), subscription billing |
| **Sprint Lane** | LANE E (Day 2–16 active, Day 17+ maintenance) |
| **D30 Outcome** | barberkas.sparkmind.web.id + 1 demo tenant + Duitku stub |
| **D60 Outcome** | Production-ready, 3+ tenants, billing live |

═══════════════════════════════════════════════════════════════

## 🥈 PRIORITY 1 — KURATORKAS (Sister-Brand of BarberKas) — **NEW LOCK v2.0**

| Field | Value |
|-------|-------|
| **Subdomain (LOCKED)** | `kuratorkas.sparkmind.web.id` |
| **Tenant pattern** | `<umkm>.kuratorkas.sparkmind.web.id` (TBD: tenant-claim atau white-label) |
| **Monorepo path** | `apps/kuratorkas/` |
| **Positioning** | AI Stylist Curator + POS untuk UMKM fashion retail Indonesia |
| **Tagline** | *"Setiap UMKM fashion di Indonesia berhak memiliki AI Stylist pribadi"* |
| **Persona Target** | UMKM fashion seller (owner toko offline/online dengan katalog produk) |
| **Justifikasi P1** | Sister-brand di bawah BarberKas; rebrand penuh dari "FashionKas"; **inherit 80% infra BK** (auth, tenant, PG); UMKM fashion = 16% e-commerce Indonesia (~$16B) |
| **Skor Saat Ini** | 0/100 NEW |
| **Target D60** | 70/100 AMBER→GREEN |
| **Doctrine Anchor** | DOC-K (KuratorKas PRD v2.0 + Curator.OS Spec v1.0) |
| **PG Strategy** | Duitku primary (UMKM-friendly QRIS) + Xendit fallback |
| **MVP Features** | **5 Curator AI Modules**: AI Stylist (outfit rec), Content (IG/TikTok caption gen), Trend (TikTok/IG scraping), Pricing (dynamic AI), Marketplace (Shopee/Tokopedia/TikTok Shop sync) |
| **AI Runtime** | Cloudflare Workers AI + new `@sparkmind/curator-os` package |
| **Sprint Lane** | **LANE K (Day 17–45)** — reverse-extract from BK |
| **D30 Outcome** | Subdomain claimed + auth+tenant reused dari BK |
| **D60 Outcome** | Curator.OS 5-module MVP, 10 UMKM alpha users |
| **Competitor Edge** | vs Moka POS/Olsera/Pawoon/Kasir Pintar/Majoo — **AI features (none have it)** |
| **Revenue Target 2026** | 1,000 UMKM active, Rp 50B GMV processed, NPS >50 |

### KuratorKas Curator Modules Detail

| Module | Cloudflare Stack | Reverse-Extract dari BK |
|--------|------------------|-------------------------|
| **AI Stylist Curator** | Workers AI (image embedding) + D1 (catalog) | Tenant middleware, catalog schema |
| **Content Curator** | Workers AI (text-gen) + R2 (asset store) | None (new) |
| **Trend Curator** | Queues + Scheduled Workers + KV cache | None (new) |
| **Pricing Curator** | D1 analytics + Workers AI | Pricing logic mirip subscription billing BK |
| **Marketplace Curator** | Workers fetch + webhook handler | Webhook pattern reused dari BK Duitku integration |

═══════════════════════════════════════════════════════════════

## 🥉 PRIORITY 2 — PACELOKAL (Hobby & Passion Lane)

| Field | Value |
|-------|-------|
| **Subdomain (LOCKED)** | `pacelokal.sparkmind.web.id` |
| **Monorepo path** | `apps/pacelokal/` |
| **Positioning** | Hyperlocal running OS untuk Banyumas Raya (Purwokerto beachhead) |
| **Persona Target** | A: Pelari Komunitas Aktif (Strava-savvy), B: Pelari Pemula Banyumas (blue ocean), C: Race Director |
| **Justifikasi P2** | Hobi & passion Haidar (lari); Strava blind-spot defensibility (hyperlocal verify-stub, Sunday Run Generator, leaderboard kabupaten); Banyumas Runners ~2k Strava-verified |
| **Skor Saat Ini** | 10/100 RED |
| **Target D60** | 81/100 GREEN |
| **Doctrine Anchor** | DOC-R (Sovereign Running Strategy v1.0, 16 May 2026) |
| **PG Strategy** | **None di MVP** (free Banyumas community), plug-in Phase 3 monetization |
| **MVP Features** | Verify-Stub (GPS verify hyperlocal), Sunday Run Generator (rute Baturraden/Karang Salam/GOR Satria), leaderboard kabupaten-level, WhatsApp-first onboarding (Persona B), R2 GPX storage |
| **Sprint Lane** | LANE B (Day 15–28, paralel dengan KK early) |
| **D30 Outcome** | pacelokal.sparkmind.web.id MVP shipped |
| **D60 Outcome** | Banyumas runner community 100+ users |

═══════════════════════════════════════════════════════════════

## 🏅 PRIORITY 3 — NURANI.OS (Devotional — Untuk Ibu) — **TERAKHIR**

| Field | Value |
|-------|-------|
| **Subdomain (LOCKED)** | `nurani.os.sparkmind.web.id` *(v1.0: `nurani.sparkmind.web.id` — superseded)* |
| **Monorepo path** | `apps/nurani-os/` |
| **Positioning** | Spiritual Sublimation Platform / **Tadarus-first OS Pan-Islamic** |
| **Persona Target** | Muslim Indonesia umum (NU + Muhammadiyah dual-acceptance), terutama **untuk Ibu Haidar** (private motivation, public-safe positioning) |
| **Justifikasi P3** | Deepest emotional layer (untuk Ibu); longest runway (Ramadhan 1448H = 8 Feb 2027 beachhead); **D60 ≠ production**, hanya preview + alpha enrollment; production target Q4 2026; trust vacuum dari Muslim Pro skandal 2020 = beachhead window |
| **Skor Saat Ini** | 5/100 RED (deepest red) |
| **Target D60** | 72/100 AMBER→GREEN (preview only, bukan production) |
| **Doctrine Anchor** | DOC-S (Sovereign Spiritual OS Strategy v1.0, 17 May 2026) |
| **PG Strategy** | **Xendit primary** (multi-channel donation/waqf, lembaga-trust) + Duitku fallback. **NO ADS DEFAULT**. Halal-by-default monetization = donation + premium fitur. |
| **MVP Features** | Quran reader, Murattal R2 streaming, **Tadarus group (gotong-royong khataman)**, juz-tracking kolektif, no-tracking aggregate cohort metrics |
| **Brand Pillars** | (1) Pan-Islamic dual-mazhab, (2) Tadarus-first, (3) No-tracking, (4) Halal monetization |
| **Sprint Lane** | LANE N (Day 30–60) |
| **D30 Outcome** | Workspace ready, doctrine refined |
| **D60 Outcome** | nurani.os.sparkmind.web.id preview live + alpha enrollment open |
| **Production Target** | Q4 2026 (Nov–Des) — 8–12 minggu sebelum Ramadhan 1448H (8 Feb 2027) |
| **SLO** | 99.5% normal, **99.9% selama Ramadhan** |

═══════════════════════════════════════════════════════════════

## 🔐 LOCK ENFORCEMENT RULES

### Rule 1 — Subdomain Immutability
Ke-4 subdomain di atas **immutable**. Setiap proposal alternatif (e.g., `nurani.sparkmind.web.id` tanpa `.os`, atau subdomain di TLD lain) **DRIFT** dan harus di-reject via §04 Anti-Drift Protocol.

### Rule 2 — Priority Order Immutability
Urutan P0 → P1 → P2 → P3 **immutable** tanpa override eksplisit Haidar yang ditulis di decision-log.
- ❌ Tidak boleh: prioritize Nurani.OS over BarberKas because "spiritual urgency"
- ❌ Tidak boleh: skip KuratorKas because "PaceLokal more passion-aligned"
- ✅ Boleh: rebalance internal milestones di setiap lane (e.g., shift GAP-BK-3 dari D18 ke D20)

### Rule 3 — No 5th Sub-Brand Without Doctrine Decision
Setiap proposal sub-brand kelima (e.g., "WaqafOS", "TaniLokal") **WAJIB**:
1. Decision-log entry (per §06.1)
2. Architecture review (apakah bisa share `@sparkmind/*` packages)
3. Sovereign Health pillar re-weight (current 4-brand weight sum = 100%)
4. Haidar explicit override

### Rule 4 — Sister-Brand Reverse-Extract Discipline
KuratorKas **HARUS** reverse-extract minimum 80% infrastruktur dari BarberKas:
- Auth + magic-link → `@sparkmind/auth`
- Tenant middleware → reuse pattern `withTenantContext()`
- Payment Gateway → `@sparkmind/pg-router`
- UI components → `@sparkmind/ui-kit`

Tulis ulang dari scratch = drift. Trigger `🚨 DRIFT DETECTED`.

### Rule 5 — Cross-Brand Identity Wajib
Satu user signup di `sparkmind.web.id/auth` HARUS bisa aktivasi semua 4 persona tanpa re-register. `@sparkmind/identity-core` (GAP-Z1, P0) blocker untuk semua sub-brand. Tidak boleh ada auth code inline di app workspace.

═══════════════════════════════════════════════════════════════

## 🧭 DNS REGISTRATION CHECKLIST (Cloudflare)

| Subdomain | Status | Action Required |
|-----------|--------|-----------------|
| `barberkas.sparkmind.web.id` | TBD verify | Confirm CNAME → Workers route |
| `*.barberkas.sparkmind.web.id` (wildcard) | TBD | For multi-tenant subdomains |
| `kuratorkas.sparkmind.web.id` | **NOT REGISTERED — DO IT NOW** | New record |
| `*.kuratorkas.sparkmind.web.id` (wildcard?) | TBD decide | Pending tenant strategy |
| `pacelokal.sparkmind.web.id` | NOT REGISTERED | New record |
| `nurani.os.sparkmind.web.id` | NOT REGISTERED | New record — note `.os` subdomain pattern |

═══════════════════════════════════════════════════════════════

## 🗂 MONOREPO LAYOUT LOCK (v2.0)

```
github.com/ganihypha/Sparkmind-Sovereign/
├── apps/
│   ├── barberkas/       ← P0 (capster)
│   ├── kuratorkas/      ← P1 (sister-brand, NEW v2.0)
│   ├── pacelokal/       ← P2 (hobby)
│   └── nurani-os/       ← P3 (devotional)
├── packages/
│   ├── core/            ← shared types, Result monad
│   ├── auth/            ← magic-link, JWT
│   ├── pg-router/       ← Duitku + Xendit
│   ├── ui-kit/          ← React components
│   ├── analytics/       ← CF Analytics Engine wrapper
│   └── curator-os/      ← NEW v2.0 — multi-agent AI runtime
├── docs/
│   ├── master-consolidated-v2.0.md   ← THIS DOCUMENT
│   ├── DOC-A/B/C/D/M/N/R/S/X/Y/Z/AUDIT/...
│   └── DOC-K-kuratorkas-v2.0.md      ← NEW v2.0
├── .sovereign/
│   ├── doctrine.lock                  ← 29-doc hash + version
│   ├── state/<brand>.json
│   └── decisions.md                   ← Decision Log
└── turbo.json, pnpm-workspace.yaml, wrangler.toml, package.json
```

═══════════════════════════════════════════════════════════════

## 📜 DECISION LOG ENTRY

```markdown
## [2026-05-19] sub-brand-lock-v2.0-4-brand
**Context**: Re-synthesis dari deep dive 20+ ZIP bundle reveals KuratorKas (rebrand FashionKas) sebagai sister-brand of BarberKas, tidak ada di v1.0 consolidated. Haidar instruksi explicit untuk lock 4 sub-brand dengan priority ordering positioning-based.
**Decision**:
  - LOCK 4 sub-brand: BarberKas (P0), KuratorKas (P1, NEW), PaceLokal (P2), Nurani.OS (P3 — terakhir)
  - Subdomain LOCKED: barberkas.sparkmind.web.id, kuratorkas.sparkmind.web.id, pacelokal.sparkmind.web.id, nurani.os.sparkmind.web.id
  - Nurani.OS subdomain pattern upgrade dari v1.0 `nurani.sparkmind.web.id` → `nurani.os.sparkmind.web.id`
  - Add 2 hard constraints (#13 4-sub-brand lock, #14 priority order lock)
  - Add 1 shared package `@sparkmind/curator-os`
**Rationale**: Positioning Haidar — capster utama (BK) → sister-brand (KK) → hobby (PL) → devotion (NU). Reverse-extract discipline ensures sister-brand inherits BK maturity.
**Refs**: [MASTER-CONSOLIDATED v2.0 §01, §09], [DOC-K KuratorKas PRD v2.0], [BARBERKAS-CFN v2.0]
**Reversible**: NO (architectural lock — requires explicit override + new decision-log entry)
```

═══════════════════════════════════════════════════════════════

# END OF SUB-BRAND LOCK v2.0

**4 sub-brand. 4 subdomain. 1 monorepo. 1 mother (SparkMind). LOCKED.**

Doctrine date: 2026-05-19 · Owner: Reza Estes / Haidar — Sovereign AI Dev
