# PER-DOC INDEX — SparkMind Sovereign Ecosystem v2.0

**Tanggal**: 2026-05-19
**Owner**: Reza Estes / Haidar — Sovereign AI Dev
**Status**: CANONICAL · 4-SUB-BRAND EDITION

═══════════════════════════════════════════════════════════════

## §1 · MASTER ARCHITECT PROMPT VERSIONS

| Doc ID | Version | Date | Size | Status | Anchor |
|--------|---------|------|------|--------|--------|
| MAP-v3.0 | v3.0 | early-2026 | 20.43 KB zip | Superseded | Foundation prompt doctrine |
| MAP-v3.1 | v3.1 | early-2026 | 32.11 KB zip | Superseded | + Layer-0 INSPECT |
| MAP-v4.0 | v4.0 | mid-2026 | 53.73 KB zip | Superseded | + Constitutional Layer (Anthropic-hardened) |
| **MAP-v5.0** | **v5.0** | **2026-05-19** | **31.92 KB docx** | **CANONICAL** | **+ 29-doc Sovereign Engine integration + LIBRARIAN role** |
| MAP-v5.1 | v5.1 | **PENDING** | — | Required for v2.0 lock | Add 4-sub-brand awareness, KuratorKas |

═══════════════════════════════════════════════════════════════

## §2 · CANONICAL DOC INDEX

| Code | Document | Tier | Tanggal | Status | Sub-brand Tag | Key Topics |
|------|----------|------|---------|--------|---------------|------------|
| **DOC-A** | Misi Hidup Haidar — Sovereign Frame v1.0 | Doctrine (Why) | 2026 | Locked, private | ALL | Identity, life mission, sovereign frame |
| **DOC-B** | Misi Nurul Reconnect Protocol v1.0 | Private | 2026 | PII-safe | n/a | Private framing only |
| **DOC-C** | Probability Matrix v1.0 | Strategy | 2026 | Public/Ecosystem track | ALL | Probability planning, scenario matrix |
| **DOC-D** | Sovereign Engineering Discipline v1.0 | Engineering | 14 May 2026 | Locked | ALL | E1-E5 vows, daily cadence, SLO |
| **DOC-K** | **KuratorKas PRD v2.0 + Curator.OS Spec v1.0** | **Product** | **2026-05-19** | **LOCKED NEW v2.0** | **KK** | **AI Stylist, Curator.OS 5 modules, UMKM fashion** |
| **DOC-M** | Monorepo Consolidation Bundle v1.0 | Engineering | 16 May 2026 | Locked | ALL | Monorepo SSOT, git subtree merge |
| **DOC-N** | Sovereign Reconnect Protocol v1.0 | Private | 2026 | PII-safe | n/a | Private framing only |
| **DOC-R** | Sovereign Running Strategy v1.0 (PaceLokal) | Product | 16 May 2026 | Locked | PL | Strava blind-spot, Verify-Stub, Sunday Run |
| **DOC-S** | Sovereign Spiritual OS Strategy v1.0 (Nurani.OS) | Product | 17 May 2026 | Locked | NU | Tadarus-first, Ramadhan 1448H beachhead, NU+Muhammadiyah dual-acceptance |
| **DOC-X** | Execution Reality Bundle v1.0 | Reality | 16 May 2026 | Locked | ALL | Reality check, scope discipline |
| **DOC-Y** | Sovereign Parallel Sprint v1.0/v1.1 | Plan | 17 May 2026 | Locked, v1.1 superior | ALL | 60-day calendar, 3 lanes (v2.0 needs LANE K → v1.2 pending) |
| **DOC-Z** | Cross-Brand Integration Bundle v1.0 | Integration | 18 May 2026 | Locked (v1.1 pending: 6 packages) | ALL | Shared packages, 1-user-N-personas |
| **DUAL-PG** | DUAL-PG-STRATEGY v1.0 (Duitku + Xendit) | Payment | 2026 | Locked | BK, KK, NU | PG routing, fees, failover |
| **BARBERKAS-CFN** | BARBERKAS-CLOUDFLARE-NATIVE v2.0 | Sub-brand | 2026 | Locked | BK | BK Cloudflare-native stack, multi-tenant |
| **DOC-AUDIT** | DOC-AUDIT v2.0 | Audit | 2026-05-18 | Current (v2.1 pending: KK pillar) | ALL | Health score (33/100 RED), gap matrix |

═══════════════════════════════════════════════════════════════

## §3 · 29 SOVEREIGN ENGINE DOCS

*(Identical to v1.0 PER-DOC-INDEX. Doc 00–Doc 27 unchanged. Anchors di MASTER-CONSOLIDATED v2.0 §10.)*

| # | Doc Name | Size | v2.0 Anchor |
|---|----------|------|-------------|
| 00 | MASTER-INDEX | 19.03 KB | §18.1 |
| 01 | NORTH-STAR-PRD | 6.94 KB | §18.2 |
| 02 | SYSTEM-ARCHITECTURE-BRIEF | 12.59 KB | §18.3 |
| 03 | BUILD-SPEC-PER-MODULE | 15.94 KB | §18.4 (BK Pattern B reference) |
| 04 | PROMPT-CONTRACT | 12.74 KB | §18.5 |
| 05 | REVENUE-SCORECARD | 11.28 KB | §07 |
| 06 | SOVEREIGN-ARCHITECT-NOTES | 25.80 KB | §18.6 |
| 06b | SOVEREIGN-BUILD-PACK | 26.27 KB | §18.7 |
| 07 | MODULE-TASK-BREAKDOWN | 34.62 KB | §18.8 |
| 08 | ACCEPTANCE-CRITERIA | 26.33 KB | §21 |
| 09 | CCA-ALIGNMENT-MAP | 36.33 KB | §20 |
| 10 | REVENUE-OFFER-SHEET | 11.39 KB | §07 |
| 11 | CUSTOMER-JOURNEY-FUNNEL | 12.36 KB | §18.9 |
| 12 | PROOF-TRUST-PACK | 13.22 KB | §18.10 |
| 13 | MODULE-SPEC-MONETIZABLE | 17.32 KB | §07 |
| 14 | OPERATIONAL-RUNBOOK | 17.97 KB | §22 |
| 15 | MASTER-INTELLIGENCE-PACK | 29.42 KB | §18.11 |
| 16 | DISTILLED-BUILD-RULES | 13.58 KB | §27/§24 |
| 17 | TASK-PROMPT-PACK-TEMPLATE | 27.85 KB | §18.12 |
| 18 | BUILD-SPRINT-LOG | 6.61 KB | §18.13 |
| 19 | DECISION-LOG | 8.26 KB | §23/§06 |
| 20 | CREDENTIAL-REGISTRY | 9.73 KB | §18.14 |
| 21 | PROOF-TRACKER-LIVE | 7.76 KB | §18.15 |
| 22 | WEEKLY-FOUNDER-REVIEW | 7.21 KB | §24/§11.3 |
| 23 | REPO-INVENTORY | 8.85 KB | §25/§22 |
| 24 | DATABASE-INVENTORY | 11.34 KB | §25/§22 |
| 25 | DEPLOYMENT-INVENTORY | 8.42 KB | §25/§22 |
| 26 | CANONICAL-ARCHITECTURE-MAP | 17.08 KB | §26/§23 |
| 27 | MOTHER-REPO-STRUCTURE | — | §18.16 |

═══════════════════════════════════════════════════════════════

## §4 · BUNDLE INDEX (20+ ZIP Upload)

| Bundle | Size | Type | Status | Sub-brand Tag |
|--------|------|------|--------|---------------|
| `aidev-bundle.zip` | 39.81 KB | Dev bundle | Locked | n/a (dev infra) |
| `barberkas-bundle.zip` | 22.47 KB | Sub-brand | Locked | BK |
| `kuratorkas-bundle.zip` | 45.54 KB | Sub-brand | **Locked NEW v2.0** | KK |
| `doc-y-bundle.zip` | 31.00 KB | Plan | Locked | ALL |
| `MASTER-ARCHITECT-PROMPT-v3.0-BUNDLE.zip` | 20.43 KB | Prompt v3.0 | Superseded | ALL |
| `MASTER-ARCHITECT-PROMPT-v3.1-BUNDLE.zip` | 32.11 KB | Prompt v3.1 | Superseded | ALL |
| `MASTER-ARCHITECT-PROMPT-v4.0-BUNDLE.zip` | 53.73 KB | Prompt v4.0 | Superseded | ALL |
| `Full bundle MASTER-ARCHITECT-PROMPT v5.0.docx` | 31.92 KB | Prompt v5.0 | CANONICAL | ALL |
| `DOC-AUDIT-v2.0-BUNDLE.zip` | 68.45 KB | Audit | Current | ALL |
| `DOC-M-MONOREPO-CONSOLIDATION-BUNDLE-v1.0.zip` | 39.00 KB | Engineering | Locked | ALL |
| `DOC-R-SOVEREIGN-RUNNING-BUNDLE-v1.0.zip` | 83.80 KB | Product | Locked | PL |
| `DOC-S-SOVEREIGN-SPIRITUAL-OS-BUNDLE-v1.0.zip` | 49.55 KB | Product | Locked | NU |
| `DOC-X-EXECUTION-REALITY-BUNDLE-v1.0.zip` | 46.15 KB | Reality | Locked | ALL |
| `DOC-Z-CROSS-BRAND-INTEGRATION-BUNDLE-v1.0.zip` | 135.30 KB | Integration | Locked (v1.1 pending) | ALL |
| `SPARKMIND-AI-DEV-HANDOFF-v1.0.zip` | 81.12 KB | Handoff | Locked | ALL |
| `sparkmind-full-bundle-v1.0.zip` | 49.97 KB | Full | Locked | ALL |
| `archive_20260518_055800.zip` | 285.69 KB | Archive | Reference | ALL |
| `Download.zip` | 177.90 KB | Mixed | Reference | ALL |
| `New Folder 25.*.zip` (3 files) | 777.48 KB, 3.67 MB, 5.0 MB | Working dir | Reference | ALL |

**Total**: 20+ bundles, ~1,046 file ekstraksi (per v1.0 manifest)

═══════════════════════════════════════════════════════════════

## §5 · CROSS-REFERENCE BY SUB-BRAND

### BarberKas (BK) — P0
- Primary docs: BARBERKAS-CFN v2.0, DOC-M (monorepo pattern), DUAL-PG v1.0
- Reference: DOC-AUDIT v2.0 §03 (BK pillar 45/100)
- Bundle: `barberkas-bundle.zip`
- Sprint anchor: DOC-Y LANE E (D2–D16)

### KuratorKas (KK) — P1 NEW v2.0
- Primary docs: **DOC-K KuratorKas PRD v2.0** (NEW), Curator.OS Spec v1.0 (NEW)
- Reference: BARBERKAS-CFN v2.0 (reverse-extract source), DUAL-PG v1.0
- Bundle: `kuratorkas-bundle.zip` (11 files: 01_PRD, 02_DESIGN, 03_ARCH, 04_SM_TOD, 05_CURATOR_OS_SPEC, 06_INTEGRATION_MAP, 07_EXECUTION_PLAN, 08_MASTER_INDEX, 09_README, 10_MANIFEST.json, 11_INTEGRATION_SCRIPT.sh)
- Sprint anchor: DOC-Y v1.2 LANE K (D17–D45, pending update)

### PaceLokal (PL) — P2
- Primary docs: DOC-R Sovereign Running Strategy v1.0
- Reference: DOC-AUDIT v2.0 §04 (PL pillar 10/100)
- Bundle: `DOC-R-SOVEREIGN-RUNNING-BUNDLE-v1.0.zip`
- Sprint anchor: DOC-Y LANE B (D15–D28)

### Nurani.OS (NU) — P3
- Primary docs: DOC-S Sovereign Spiritual OS Strategy v1.0
- Reference: DOC-AUDIT v2.0 §05 (NU pillar 5/100, deepest red)
- Bundle: `DOC-S-SOVEREIGN-SPIRITUAL-OS-BUNDLE-v1.0.zip`
- Sprint anchor: DOC-Y LANE N (D30–D60, preview only)

═══════════════════════════════════════════════════════════════

## §6 · DOCTRINE EVOLUTION TIMELINE

```
2026-01..2026-04   DOC-A, DOC-B, DOC-C, DOC-N drafted (private framing)
2026-05-14         DOC-D Engineering Discipline locked
2026-05-16         DOC-M Monorepo Consolidation + DOC-R Running Strategy locked
2026-05-17         DOC-S Spiritual OS + DOC-Y Parallel Sprint v1.0 locked
2026-05-18         DOC-Z Cross-Brand Integration locked + DOC-AUDIT v2.0
2026-05-18..19     MASTER-ARCHITECT-PROMPT v3.0 → v3.1 → v4.0 → v5.0 ladder
2026-05-19         MASTER-CONSOLIDATED v1.0 (3-sub-brand baseline)
2026-05-19         DOC-K KuratorKas PRD v2.0 + Curator.OS Spec v1.0 added (sister-brand surface)
2026-05-19         MASTER-CONSOLIDATED v2.0 LOCK (4-sub-brand, this document)

PENDING (post-v2.0):
- MASTER-ARCHITECT-PROMPT v5.1 (4-sub-brand awareness)
- DOC-Y v1.2 (LANE K added)
- DOC-Z v1.1 (6 shared packages)
- DOC-S v1.1 (subdomain refresh: `.os` pattern)
- DOC-AUDIT v2.1 (KK pillar weighted in)
- MASTER-INDEX (Doc 00) refresh dengan DOC-K
```

═══════════════════════════════════════════════════════════════

# END OF PER-DOC INDEX v2.0

Doctrine date: 2026-05-19 · Owner: Reza Estes / Haidar — Sovereign AI Dev
