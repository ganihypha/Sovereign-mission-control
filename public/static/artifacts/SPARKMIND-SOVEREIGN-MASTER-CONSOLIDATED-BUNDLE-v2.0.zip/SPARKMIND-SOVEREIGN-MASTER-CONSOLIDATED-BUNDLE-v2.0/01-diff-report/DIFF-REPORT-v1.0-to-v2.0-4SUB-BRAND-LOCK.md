# DIFF REPORT: MASTER-CONSOLIDATED v1.0 → v2.0

**Tanggal**: 2026-05-19
**Owner**: Reza Estes / Haidar — Sovereign AI Dev
**Trigger**: 4-sub-brand lock instruction (BarberKas → KuratorKas → PaceLokal → Nurani.OS)
**Severity**: **MAJOR** (struktur ekosistem berubah: 3 → 4 sub-brand)

═══════════════════════════════════════════════════════════════

## §1 · TL;DR

v2.0 menambahkan **KuratorKas** sebagai sub-brand ke-2 (sister-brand of BarberKas), re-order prioritas berdasarkan **positioning** (capster → sister → hobby → devotion) bukan **phase** seperti v1.0, dan menambah **1 shared package baru** (`@sparkmind/curator-os`).

**Tidak ada doktrin yang dihapus**. Semua doctrine v1.0 + v5.0 dipertahankan, hanya **diperluas**.

═══════════════════════════════════════════════════════════════

## §2 · PERUBAHAN STRUKTURAL

### 2.1 Sub-brand Count

| Aspek | v1.0 | v2.0 |
|-------|------|------|
| Jumlah sub-brand | 3 | **4** |
| Sub-brand list | BarberKas, PaceLokal, Nurani.OS | BarberKas, **KuratorKas (NEW)**, PaceLokal, Nurani.OS |
| Sub-brand subdomain count | 3 | 4 |
| Monorepo apps minimum | 3 (`apps/barberkas`, `apps/pacelokal`, `apps/nurani`) | 4 (+ `apps/kuratorkas`) |

### 2.2 Subdomain Lock (v2.0 LOCKED)

| # | Sub-brand | Subdomain |
|---|-----------|-----------|
| 1 | BarberKas | `barberkas.sparkmind.web.id` |
| 2 | **KuratorKas (NEW)** | `kuratorkas.sparkmind.web.id` |
| 3 | PaceLokal | `pacelokal.sparkmind.web.id` |
| 4 | Nurani.OS | `nurani.os.sparkmind.web.id` *(catatan: v1.0 pakai `nurani.sparkmind.web.id`; v2.0 lock ke `nurani.os.sparkmind.web.id` sesuai instruksi Haidar)* |

### 2.3 Priority Re-Ordering

| Priority | v1.0 (Phase-based) | v2.0 (Positioning-based) |
|----------|--------------------|--------------------------|
| **P0** | BarberKas (Phase 1) | **BarberKas** — Capster utama (positioning asli) |
| **P1** | PaceLokal (Phase 2) | **KuratorKas** — Sister-brand (rebrand FashionKas, reuse BK infra) |
| **P2** | Nurani.OS (Phase 3) | **PaceLokal** — Hobby/passion lane (lari Banyumas) |
| **P3** | — | **Nurani.OS** — Devotional last (untuk Ibu, Ramadhan 1448H) |

**Rationale v2.0** (per instruksi Haidar):
- BarberKas = positioning asli, codebase paling matang → **wajib first**
- KuratorKas = brand baru di bawah BarberKas (sister), **inherit infra** → **second**
- PaceLokal = hobi lari → **third**
- Nurani.OS = layer paling deep emotional (untuk Ibu) → **last** (longest runway, Ramadhan 1448H = Feb 2027)

═══════════════════════════════════════════════════════════════

## §3 · PERUBAHAN PER SECTION

### §00 Executive Summary

**v1.0**: 3 sub-brand mention, 5 critical gaps, mantra "Cross-brand first"
**v2.0**:
- 4 sub-brand mention
- 6 critical gaps (added GAP-KK)
- Mantra baru: *"Empat sub-brand. Satu mother. Satu monorepo. Capster dulu. Sister-brand kedua. Hobby ketiga. Devotion terakhir. Lock. Execute."*

### §01 Canonical Context

**Tabel 1.2 (Sub-Brands)**:
- v1.0: 3 baris (BK / PL / NU)
- v2.0: 4 baris (BK / **KK NEW** / PL / NU)
- Added: skor saat ini KuratorKas = 0/100 NEW, target D60 = 70/100

**Tabel 1.4 (Doctrine Stack)**:
- v2.0 added: `DOC-K — KuratorKas PRD v2.0 + Curator.OS Spec v1.0` (2026-05-19)
- v2.0 added: `BARBERKAS-CFN — BARBERKAS-CLOUDFLARE-NATIVE v2.0`

**§1.5 Hard Constraints**:
- v1.0: 12 constraints
- v2.0: **14 constraints** (+2 baru)
  - **#13** NEW: 4-Sub-Brand Lock — tidak boleh tambah/kurangi tanpa decision-log entry
  - **#14** NEW: Priority Order Lock — BK (P0) → KK (P1) → PL (P2) → NU (P3)

### §04 Drift Detection

v2.0 added drift signals:
- Skip KuratorKas dari diagram/list (4→3 drift)
- Re-order priority tanpa override eksplisit
- Treat Nurani.OS sebagai P1 (drift ke v1.0 ordering)

### §08 Cross-Brand Integration

**§8.1 Shared Packages**: 5 → **6** packages
- NEW: `@sparkmind/curator-os` — Multi-agent AI runtime untuk KuratorKas (extensible ke BK/PL/NU)

**§8.3 1-User-N-Personas Journey**: 3 personas → **4 personas**
- v1.0: Capster | Pelari | Spiritual Seeker
- v2.0: Capster | **Curator (UMKM Fashion)** | Pelari | Spiritual Seeker

**§8.4 Gap Cascade Map**: 7 → **8 cross-brand gaps**
- NEW: GAP-Z8 — Curator.OS runtime shared package (P1, MEDIUM cascade)

### §09 Sub-Brand Deep Dive

**v1.0 had**: 9.1 (BK), 9.2 (PL), 9.3 (NU)
**v2.0 has**: 9.1 (BK), **9.2 (KK NEW)**, 9.3 (PL), 9.4 (NU)

**§9.2 KuratorKas (NEW)** — full new section:
- Vision: AI Stylist pribadi untuk setiap UMKM fashion Indonesia
- 5 Curator Modules MVP: AI Stylist, Content, Trend, Pricing, Marketplace
- Objectives 2026: 1,000 UMKM, Rp 50B GMV, NPS >50
- 6 KuratorKas-specific gaps (KK-1 sampai KK-6)
- Reverse-extract strategy: 80% inherit BK auth + tenant + PG

### §11 Operational Discipline (SLO)

| Brand | v1.0 SLO | v2.0 SLO |
|-------|---------|---------|
| BarberKas | 99.5% | 99.5% |
| **KuratorKas** | — | **99.5%** (NEW) |
| PaceLokal | 99.0% | 99.0% |
| Nurani.OS | 99.5% (Ramadhan 99.9%) | 99.5% (Ramadhan 99.9%) |
| SparkMind root | 99.9% | 99.9% |

### §12 DOC-Y Parallel Sprint

**v1.0**: 3 lanes (F, E, B + bypassed D)
**v2.0**: **4 lanes** (F, E, **K NEW**, B, N) + bypassed D
- LANE K: KuratorKas Sister — D17 → D45, reverse-extract from BK
- LANE N renamed from "Nurani.OS phase" to formal Lane N

### §13 Composite Health Scorecard

Re-weighted to accommodate KuratorKas at 12%:

| Pillar | v1.0 Weight | v2.0 Weight | Δ |
|--------|------------:|------------:|--:|
| Cross-brand integration | 20% | 18% | -2 |
| BarberKas | 15% | 14% | -1 |
| **KuratorKas (NEW)** | — | **12%** | **+12** |
| PaceLokal | 15% | 12% | -3 |
| Nurani.OS | 15% | 12% | -3 |
| Engineering discipline | 15% | 12% | -3 |
| Payment gateway | 10% | 10% | 0 |
| Doctrine & brand integrity | 10% | 10% | 0 |
| **Total** | **100%** | **100%** | — |

**Composite anchor**: 33/100 (v1.0) → **~28/100 (v2.0)** karena KK start 0/100.

### §19 Anti-Patterns

v1.0: 16 items
v2.0: **18 items** (+2)
- #17 NEW: Skip KuratorKas dari diagram/list (4→3 drift)
- #18 NEW: Re-order 4-sub-brand priority tanpa Haidar override

### §20 SOS Trigger
- v1.0: `@SOS-Sovereign v5.0`
- v2.0: `@SOS-Sovereign v2.0` (consolidated version)

### §21 Invocation Patterns

v2.0 added §21.2 Sister-Brand Reverse-Extract pattern (specific untuk KK ← BK).

### §22 Triple-Lock Inventory
- v1.0: 3 brands inventory
- v2.0: **4 brands inventory** (+ KuratorKas D1, Worker, route)

### §23 Canonical Architecture Map
- v1.0 diagram: 3 sub-brand boxes
- v2.0 diagram: **4 sub-brand boxes** + 6 shared packages footer

### §24 Distilled Build Rules
- v1.0: 10 rules
- v2.0: **12 rules** (+ #11 4-sub-brand lock, +#12 priority order lock)

### §26 Cara Pakai
- §26.4 Sub-brand Drill-Down v1.0: 3 entries
- §26.4 v2.0: **4 entries** (+ KuratorKas drill-down)

═══════════════════════════════════════════════════════════════

## §4 · BREAKING CHANGES

### 4.1 Subdomain Pattern Nurani.OS

**v1.0**: `nurani.sparkmind.web.id`
**v2.0**: `nurani.os.sparkmind.web.id` (per Haidar instruksi)

**Action Required**:
- Update DNS planning di Triple-Lock Inventory (Doc 25)
- Update DOC-S §01 Identity → subdomain field
- Update monorepo apps path tetap `apps/nurani-os/` (sudah aligned)

### 4.2 New Required App Scaffold

**v2.0 mandates** `apps/kuratorkas/` di monorepo. CI/CD config (Turborepo) wajib include 4 apps, bukan 3.

### 4.3 New Shared Package

`@sparkmind/curator-os` belum exists. Harus dibuat sebagai package baru di `packages/curator-os/`.

═══════════════════════════════════════════════════════════════

## §5 · NON-BREAKING ADDITIONS

- DOC-K reference (new doctrine doc)
- LANE K (parallel sprint lane)
- KuratorKas drill-down section
- Curator.OS package canonical position
- Updated diagrams (architecture map, gap cascade)

═══════════════════════════════════════════════════════════════

## §6 · MIGRATION CHECKLIST (v1.0 → v2.0)

- [ ] Update `MASTER-CONSOLIDATED.md` reference di session prompt
- [ ] Update `.sovereign/doctrine.lock` hash (29-doc + KK now)
- [ ] Create `apps/kuratorkas/` workspace
- [ ] Create `packages/curator-os/` shared package
- [ ] Update DNS plan: register `kuratorkas.sparkmind.web.id` + `nurani.os.sparkmind.web.id`
- [ ] Update Cloudflare Analytics datasets (3 → 4)
- [ ] Update DOC-AUDIT next iteration (v2.1?) with KuratorKas pillar
- [ ] Update sprint calendar DOC-Y v1.2 with LANE K
- [ ] Update DOC-Z v1.1 dengan 6 shared packages
- [ ] Refresh BARBERKAS-CFN doc untuk note "KK akan reverse-extract dari kode ini"
- [ ] Tambah DOC-K entry ke MASTER-INDEX (Doc 00)

═══════════════════════════════════════════════════════════════

## §7 · COUNT OF CHANGES

| Type | Count |
|------|-------|
| New section | 1 (§9.2 KuratorKas) |
| Modified section | 12 (§00, §01, §04, §08, §11, §12, §13, §19, §20, §21, §22, §23, §24, §26) |
| New constraint | 2 (#13, #14) |
| New anti-pattern | 2 (#17, #18) |
| New gap | 1 (GAP-Z8) |
| New shared package | 1 (`@sparkmind/curator-os`) |
| New parallel lane | 1 (LANE K) |
| New doctrine doc (DOC-K) | 1 |
| Re-weighted pillars | 5 |

═══════════════════════════════════════════════════════════════

# END OF DIFF REPORT v1.0 → v2.0

Doctrine date: 2026-05-19 · Owner: Reza Estes / Haidar — Sovereign AI Dev
**Status**: CANONICAL · 4-SUB-BRAND LOCKED
