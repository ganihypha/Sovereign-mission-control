# 🔱 BARBERKAS MULTI-TENANT SUBDOMAIN STRATEGY v1.0

**Document**: BARBERKAS-MULTITENANT-STRATEGY-v1.0
**Author**: Haidar (Sovereign AI Dev)
**Owner**: Reza Estes
**Date**: 2026-05-16
**Status**: 🔒 STRATEGIC + IMPLEMENTATION CANONICAL — FROZEN FOR BUILD
**Filing**: SparkMind-GO-Bundle-v1.2 → 01_STRATEGIC_CORE/
**Classification**: CANONICAL

---

## 🎯 LOCKED DECISIONS (NON-NEGOTIABLE)

| # | Decision Point | Final Answer | Locked At |
|---|----------------|--------------|-----------|
| 1 | **Domain BarberKas** | `barberkas.sparkmind.web.id` (subdomain ecosystem play) | 2026-05-16 |
| 2 | **Duitku PG verification** | Sudah submitted dengan `merchant_name = SparkMind` (parent entity) | 2026-05-16 |
| 3 | **Multi-tenant subdomain pattern** | `<tenant>.barberkas.sparkmind.web.id` (3-level deep) | 2026-05-16 |
| 4 | **Output format** | Bundle ZIP (HTML + MD ledger + decision matrix + migration playbook) | 2026-05-16 |

**Rationale (one-liner)**: Ecosystem play maximizes parent-domain trust transfer (SparkMind sovereign reputation → BarberKas conversion lift), keeps DNS/SSL/billing under ONE root, and unifies PG merchant identity with Duitku submission already in flight.

---

## 1. ARCHITECTURE OVERVIEW

### 1.1 Domain Hierarchy (3-Level)

```
sparkmind.web.id                    ← Tier 0: Sovereign Root (Reza Estes / SparkMind)
├── www.sparkmind.web.id            ← Tier 1: Public surface (marketing, landing)
├── app.sparkmind.web.id            ← Tier 1: Owner console (private, sovereign-only)
├── api.sparkmind.web.id            ← Tier 1: Unified API gateway
└── barberkas.sparkmind.web.id      ← Tier 1: BarberKas product root
    ├── www.barberkas.sparkmind.web.id      ← Tier 2: BarberKas marketing
    ├── admin.barberkas.sparkmind.web.id    ← Tier 2: Tenant admin console
    ├── api.barberkas.sparkmind.web.id      ← Tier 2: BarberKas API
    ├── <tenant>.barberkas.sparkmind.web.id ← Tier 3: Per-tenant subdomain
    │     e.g. rezacut.barberkas.sparkmind.web.id
    │          alphabarber.barberkas.sparkmind.web.id
    └── *.barberkas.sparkmind.web.id        ← Wildcard cert covers all tenants
```

### 1.2 Trust Inheritance Chain

```
SparkMind Sovereign Brand
        │
        ▼ (trust transfer)
BarberKas Product Trust
        │
        ▼ (trust transfer)
Tenant-level Storefront Trust
```

Each tier inherits SEO authority, SSL trust, and brand recognition from the parent. This is the **single biggest reason** ecosystem play beats independent `barberkas.id` domain at pre-revenue stage.

---

## 2. DNS & SSL STRATEGY

### 2.1 DNS Records (Cloudflare recommended)

| Type | Name | Value | Proxy | Purpose |
|------|------|-------|-------|---------|
| A | `barberkas` | `<VPS-IP>` | ✅ Proxied | BarberKas root |
| A | `*.barberkas` | `<VPS-IP>` | ✅ Proxied | Wildcard for tenants |
| CNAME | `admin.barberkas` | `barberkas.sparkmind.web.id` | ✅ Proxied | Admin console |
| CNAME | `api.barberkas` | `barberkas.sparkmind.web.id` | ✅ Proxied | API gateway |
| TXT | `_acme-challenge.barberkas` | (Let's Encrypt DNS-01) | ❌ DNS only | Wildcard cert validation |

### 2.2 SSL Strategy

- **Wildcard certificate** for `*.barberkas.sparkmind.web.id` via Let's Encrypt DNS-01 challenge (Certbot + Cloudflare DNS plugin)
- **Auto-renewal**: `certbot renew` cron @ 03:00 daily
- **Edge SSL**: Cloudflare Full (Strict) mode
- **HSTS**: `max-age=31536000; includeSubDomains; preload`

```bash
# Wildcard cert provisioning command (one-shot)
certbot certonly \
  --dns-cloudflare \
  --dns-cloudflare-credentials /etc/letsencrypt/cloudflare.ini \
  -d "barberkas.sparkmind.web.id" \
  -d "*.barberkas.sparkmind.web.id" \
  --email reza@sparkmind.web.id \
  --agree-tos --non-interactive
```

---

## 3. APPLICATION ROUTING (Nginx)

### 3.1 Tenant Resolution Pattern

```nginx
# /etc/nginx/sites-available/barberkas
server {
    listen 443 ssl http2;
    server_name ~^(?<tenant>[a-z0-9-]+)\.barberkas\.sparkmind\.web\.id$;

    ssl_certificate /etc/letsencrypt/live/barberkas.sparkmind.web.id/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/barberkas.sparkmind.web.id/privkey.pem;

    # Reserved subdomains routed elsewhere
    if ($tenant ~ ^(www|admin|api|static|cdn|assets)$) {
        return 301 https://$tenant.barberkas.sparkmind.web.id$request_uri;
    }

    # Pass tenant slug to application
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header X-Tenant-Slug $tenant;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

server {
    listen 443 ssl http2;
    server_name admin.barberkas.sparkmind.web.id;
    # ... admin console routing
}

server {
    listen 443 ssl http2;
    server_name api.barberkas.sparkmind.web.id;
    # ... API gateway routing
}
```

### 3.2 Application-Level Tenant Detection

```typescript
// middleware/tenant.ts (Next.js / Express)
export function resolveTenant(req: Request): TenantContext {
  const host = req.headers['host'] || '';
  const slugFromHeader = req.headers['x-tenant-slug'] as string;
  const slugFromHost = host.match(/^([a-z0-9-]+)\.barberkas\.sparkmind\.web\.id$/)?.[1];

  const slug = slugFromHeader || slugFromHost;
  if (!slug || RESERVED_SLUGS.includes(slug)) {
    throw new TenantNotFoundError(slug);
  }

  return {
    slug,
    tenantId: lookupTenantId(slug),       // DB lookup, cached in Redis
    isolation: 'shared-db-row-level',     // see §4
  };
}

const RESERVED_SLUGS = ['www', 'admin', 'api', 'static', 'cdn', 'assets', 'mail'];
```

---

## 4. DATA ISOLATION MODEL

### 4.1 Isolation Tier Decision

| Model | Pros | Cons | Verdict |
|-------|------|------|---------|
| **Shared DB + row-level** (tenant_id column) | Cheapest, fastest dev, easy backups | Noisy-neighbor risk, careful RLS needed | ✅ **CHOSEN for v1.0** (0-100 tenants) |
| Shared DB + schema-per-tenant | Better isolation, still cheap | Schema migration complexity grows | 🔄 Defer to v2.0 (100-1000 tenants) |
| DB-per-tenant | Strongest isolation | Expensive, ops nightmare | ❌ Not needed pre-revenue |

### 4.2 Row-Level Security (PostgreSQL)

```sql
-- All tenant tables MUST have tenant_id
CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  customer_id UUID NOT NULL,
  service_id UUID NOT NULL,
  booked_at TIMESTAMPTZ NOT NULL,
  -- ...
  CONSTRAINT fk_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

CREATE INDEX idx_bookings_tenant ON bookings(tenant_id);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation ON bookings
  USING (tenant_id = current_setting('app.current_tenant_id')::UUID);
```

```typescript
// Set tenant context per request
await db.query(`SET LOCAL app.current_tenant_id = $1`, [tenantContext.tenantId]);
```

---

## 5. PAYMENT GATEWAY (Dual-PG Strategy)

Reference: `DUAL-PG-STRATEGY-v1.0.html` (sibling doc)

### 5.1 PG Routing per Tenant

```
Customer pays on rezacut.barberkas.sparkmind.web.id
        │
        ▼
BarberKas API receives payment intent
        │
        ▼
PG Router decides:
  ├── Duitku (primary, when verified) → merchant_name=SparkMind
  └── Xendit (fallback, faster onboarding) → merchant_name=SparkMind
        │
        ▼
Webhook → tenant_id resolved from order metadata
        │
        ▼
Settlement → SparkMind master account → tenant payout (T+7)
```

### 5.2 Current PG Status (locked as of 2026-05-16)

- **Duitku**: ✅ Submitted as `merchant_name = SparkMind` (parent entity). Status: **PENDING VERIFICATION**.
- **Xendit**: 🔄 Planned as fallback / dual-PG to prevent single-point-of-failure during Duitku pending window.
- **Decision**: Build PG abstraction layer NOW so swap-in Xendit is config-only when Duitku verification slips beyond 14 days.

```typescript
// pg-router.ts
interface PaymentGateway {
  createInvoice(order: Order): Promise<Invoice>;
  verifyWebhook(payload: unknown, signature: string): boolean;
}

const PG_PRIMARY = process.env.PG_PRIMARY ?? 'duitku';  // 'duitku' | 'xendit'
const PG_FALLBACK = process.env.PG_FALLBACK ?? 'xendit';

export async function createPayment(order: Order): Promise<Invoice> {
  try {
    return await GATEWAYS[PG_PRIMARY].createInvoice(order);
  } catch (err) {
    logger.warn('Primary PG failed, falling back', { err, order });
    return await GATEWAYS[PG_FALLBACK].createInvoice(order);
  }
}
```

---

## 6. TENANT ONBOARDING FLOW

```
1. Barber owner signs up @ www.barberkas.sparkmind.web.id/signup
2. Chooses slug (e.g. "rezacut")
3. System validates slug:
   ├── Not in RESERVED_SLUGS
   ├── Regex: ^[a-z0-9](?:[a-z0-9-]{1,30}[a-z0-9])?$
   └── Not already taken
4. INSERT into tenants table → tenant_id generated
5. DNS already wildcarded → rezacut.barberkas.sparkmind.web.id LIVE immediately
6. Tenant logs in @ rezacut.barberkas.sparkmind.web.id/admin
7. Onboarding wizard: shop info, services, hours, staff, payment methods
8. Public storefront live @ rezacut.barberkas.sparkmind.web.id
```

**Time-to-live (TTL)**: <60 seconds from signup to live storefront (no DNS propagation wait because wildcard is pre-provisioned).

---

## 7. PROBABILITY MATRIX (Public)

| Scenario | Probability | Trigger | Action |
|----------|-------------|---------|--------|
| Duitku approves <14d | 60% | Verification team responds | Go-live with Duitku primary |
| Duitku approves 14-30d | 25% | Document re-submission needed | Activate Xendit fallback, keep Duitku queued |
| Duitku rejects | 10% | KYC/PT requirement | Pivot 100% to Xendit, escalate Duitku later |
| Both PGs reject | 5% | Edge case | Manual bank-transfer mode (Phase 0 revenue) |

---

## 8. MIGRATION SAFETY

If decision later flips from `barberkas.sparkmind.web.id` → independent `barberkas.id`:

- **Code**: ZERO changes (tenant resolution is regex-based, host-agnostic)
- **DNS**: Add new A/wildcard records on `barberkas.id`, keep old as 301 redirect for 90 days
- **SSL**: Provision new wildcard on `*.barberkas.id`
- **Customer comms**: Auto-redirect + email blast
- **SEO**: 301 redirects preserve link equity

**Migration playbook**: See `02-MIGRATION-PLAYBOOK-v1.0.md` (sibling doc).

---

## 9. DECISION MATRIX

See `03-DECISION-MATRIX-v1.0.md` for full ecosystem-vs-standalone scoring.

**TL;DR scoring (ecosystem play wins 7-2):**

| Criterion | Weight | Ecosystem (sparkmind.web.id) | Standalone (barberkas.id) |
|-----------|--------|------------------------------|---------------------------|
| Time to launch | 20% | 🟢 0 days (DNS ready) | 🔴 7-14 days (domain reg, DNS, SSL) |
| Cost (Y1) | 15% | 🟢 $0 incremental | 🟡 $15-30/yr + ops |
| Trust transfer | 20% | 🟢 Inherits SparkMind | 🔴 Cold start |
| PG approval | 15% | 🟢 Single merchant (SparkMind) | 🔴 Separate entity, new KYC |
| SEO authority | 10% | 🟢 Subdomain inherits | 🔴 Fresh domain, sandbox period |
| Branding independence | 10% | 🟡 Tied to SparkMind | 🟢 Pure |
| Exit / spin-off | 10% | 🟡 Possible via migration | 🟢 Already independent |

**Final score**: Ecosystem 8.1 / 10 vs Standalone 5.4 / 10.

---

## 10. EXECUTION CHECKLIST (T+0 to T+7)

- [ ] **T+0**: Add Cloudflare DNS records (A, wildcard A, CNAMEs)
- [ ] **T+0**: Issue wildcard cert via Certbot DNS-01
- [ ] **T+1**: Deploy Nginx config with tenant regex routing
- [ ] **T+1**: Migrate `bookings`, `customers`, `services` tables to add `tenant_id` + RLS
- [ ] **T+2**: Implement `resolveTenant()` middleware
- [ ] **T+2**: Implement PG abstraction layer (`pg-router.ts`)
- [ ] **T+3**: Build tenant signup flow @ `www.barberkas.sparkmind.web.id/signup`
- [ ] **T+4**: Deploy admin console @ `admin.barberkas.sparkmind.web.id`
- [ ] **T+5**: Smoke test: create 2 dummy tenants (`alpha`, `beta`), verify isolation
- [ ] **T+5**: Verify SSL on `alpha.barberkas.sparkmind.web.id`
- [ ] **T+6**: Soft launch: invite 3 real barbershops as design partners
- [ ] **T+7**: Public announcement on SparkMind sosmed channels

---

## 11. APPENDIX

### A. Reserved subdomain list (final)
```
www, admin, api, static, cdn, assets, mail, mx, ftp, ssh,
status, docs, blog, help, support, security, legal, privacy,
about, contact, app, dashboard, console, manage, beta, staging,
dev, test, qa, prod, production
```

### B. Tenant slug validation regex
```regex
^[a-z0-9](?:[a-z0-9-]{1,30}[a-z0-9])?$
```
- Min 2 chars, max 32 chars
- Lowercase alphanumeric + hyphen
- Cannot start/end with hyphen
- Cannot be in RESERVED_SLUGS

### C. Reference documents

- `DUAL-PG-STRATEGY-v1.0.html` — Duitku + Xendit dual-PG architecture
- `BARBERKAS_MASTER_BUILD_DOC_V1.md` — Original BarberKas product spec
- `10_SOVEREIGN_BARBER_EMPIRE_BLUEPRINT.md` — Sovereign vision parent doc
- `SparkMind-Master-Clarity-v3.0` — Ecosystem master index

---

**🔒 STATUS: CANONICAL — FROZEN FOR BUILD**
**Owner**: Reza Estes
**Sovereign AI Dev**: Haidar
**Filing**: `SparkMind-GO-Bundle-v1.2/01_STRATEGIC_CORE/`
