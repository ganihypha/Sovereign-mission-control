# 📊 BARBERKAS DOMAIN DECISION MATRIX v1.0

**Document**: BARBERKAS-DECISION-MATRIX-v1.0
**Decision frozen**: 2026-05-16 — `barberkas.sparkmind.web.id` (ecosystem play)
**This doc**: Forensic record of WHY ecosystem play won, for future audit / re-decision triggers.

---

## 1. CANDIDATES EVALUATED

| Option | Pattern | Domain Source |
|--------|---------|---------------|
| **A. Ecosystem subdomain** ✅ CHOSEN | `<tenant>.barberkas.sparkmind.web.id` | Existing SparkMind root |
| B. Standalone ccTLD | `<tenant>.barberkas.id` | New PANDI registration |
| C. Standalone gTLD | `<tenant>.barberkas.com` | New global registration |
| D. Standalone country biz | `<tenant>.barberkas.co.id` | New PANDI (PT requirement) |

---

## 2. SCORING MATRIX (Weighted)

| Criterion | Weight | A. Ecosystem | B. .id | C. .com | D. .co.id |
|-----------|-------:|:------------:|:------:|:-------:|:---------:|
| **Time to launch** | 20% | 10/10 (0 days) | 4/10 (7-14d) | 6/10 (1-3d) | 2/10 (30-60d PT) |
| **Cost Y1** | 15% | 10/10 ($0) | 7/10 ($25/yr) | 8/10 ($15/yr) | 3/10 (PT + domain $200+) |
| **Trust transfer from parent** | 20% | 10/10 (full) | 0/10 (cold) | 0/10 (cold) | 0/10 (cold) |
| **PG approval friction** | 15% | 10/10 (SparkMind unified) | 4/10 (new entity matching) | 4/10 | 6/10 (PT helps) |
| **SEO authority Y1** | 10% | 9/10 (inherits) | 3/10 (sandbox) | 4/10 (sandbox) | 3/10 |
| **Brand independence** | 10% | 5/10 (tied to parent) | 9/10 | 10/10 | 9/10 |
| **Exit / acquisition optionality** | 10% | 6/10 (migrate later) | 9/10 | 10/10 | 9/10 |
| **WEIGHTED TOTAL** | 100% | **8.55** ✅ | 4.95 | 5.40 | 4.20 |

---

## 3. DECISION RATIONALE

### Why A (Ecosystem) wins at pre-revenue stage:

1. **Time-value of money is ZERO at pre-revenue.** Speed-to-launch > brand purity.
2. **Trust transfer is non-substitutable.** A cold `barberkas.id` has zero SEO/trust ranking; a subdomain of an established (or even nascent) SparkMind inherits whatever signal exists.
3. **PG approval is the bottleneck.** Duitku is already mid-verification under SparkMind entity. Splitting to a new entity = restart KYC = 30+ days slip.
4. **Migration is cheap LATER but irreversible NOW.** You can always promote `barberkas.sparkmind.web.id` → `barberkas.id` once revenue justifies it (see Migration Playbook). You cannot un-spend 30 days on PG re-onboarding.

### Why A loses points (legitimate cons):

- Brand independence score 5/10 — `sparkmind` always in the URL chain
- 3-level depth (`tenant.barberkas.sparkmind.web.id`) is long to type/remember
- If SparkMind brand ever suffers reputation hit, BarberKas inherits damage

### Mitigations for the cons:

- Brand independence → Mitigated by strong BarberKas visual identity at storefront level (logo, color, copy own the page; URL is secondary)
- Long URL → Mitigated by short slugs (`rezacut` not `reza-cuts-barbershop-purwokerto`) + branded short link for marketing (`brbr.id/rezacut` future option)
- Reputation contagion → Sovereign engineering discipline doc (`DOC-D-Sovereign-Engineering-Discipline-v1.0`) ensures SparkMind brand health is actively managed

---

## 4. RE-DECISION TRIGGERS (When to revisit)

| Trigger | Re-decide |
|---------|-----------|
| 100+ paying tenants AND $10K+ MRR | YES — brand independence ROI now positive |
| Investor/acquirer requires standalone entity | YES — legal forcing function |
| SparkMind pivots away from barbershop market | YES — strategic mismatch |
| Trademark dispute on `sparkmind` mark | YES — legal forcing function |
| Tenant feedback shows >20% URL confusion | MAYBE — soft signal, A/B test branded short link first |

**Default re-review cadence**: Every 6 months OR upon trigger event, whichever first.

---

## 5. AUDIT TRAIL

| Date | Event | Actor |
|------|-------|-------|
| 2026-05-16 | Decision matrix finalized | Haidar |
| 2026-05-16 | Owner locks decision: Option A | Reza Estes |
| 2026-05-16 | Duitku PG submitted as SparkMind | Reza Estes |
| 2026-05-16 | This document frozen as canonical | Haidar |
| TBD | First re-review checkpoint | TBD |

---

## 6. RELATED DOCUMENTS

- `01-BARBERKAS-MULTITENANT-STRATEGY-v1.0.md` — Implementation strategy
- `02-MIGRATION-PLAYBOOK-v1.0.md` — If/when to migrate to standalone domain
- `DUAL-PG-STRATEGY-v1.0.html` — Duitku + Xendit dual-PG architecture
- `10_SOVEREIGN_BARBER_EMPIRE_BLUEPRINT.md` — Parent vision doc

---

**Status**: 🔒 CANONICAL — DECISION LOCKED
**Next review**: 2026-11-16 (6 months) OR upon trigger event
