# GAP MATRIX ANTAR DOC — v2.0 (4-Sub-Brand Edition)

**Tanggal**: 2026-05-19
**Owner**: Reza Estes / Haidar — Sovereign AI Dev
**Anchor**: DOC-AUDIT v2.0 + KuratorKas PRD v2.0 + 4-Sub-Brand Lock
**Supersedes**: GAP-MATRIX v1.0 (3-sub-brand)

═══════════════════════════════════════════════════════════════

## §1 · CROSS-BRAND GAPS (P0/P1 — blocks multiple sub-brands)

| Gap ID | Description | Severity | Cascade | Owner | Deadline |
|--------|-------------|----------|---------|-------|----------|
| GAP-Z1 | Shared identity (`@sparkmind/identity-core`) not implemented | **P0** | HIGH → blocks all 4 sub-brand auth | Haidar | D10 |
| GAP-Z2 | Shared payments (`@sparkmind/payments` adapter dual-PG) | **P0** | HIGH → blocks BK D30 + KK D45 + NU D60 | Haidar | D14 |
| GAP-Z3 | Shared UI tokens (`@sparkmind/ui-kit`) | **P1** | HIGH → 4-sub-brand UI inconsistent | Haidar | D18 |
| GAP-Z4 | Monorepo CI/CD (Turborepo + pnpm + CF Pages) | **P1** | HIGH → all deploys manual | Haidar | D15 |
| GAP-Z5 | Root domain Doctrine + 4-sub-brand showcase | **P1** | MEDIUM → no umbrella narrative | Haidar | D20 |
| GAP-Z6 | Cross-brand observability (Analytics Engine 4 datasets) | **P2** | LOW | Haidar | D40 |
| GAP-Z7 | Cross-brand persona surface (settings/billing/notif) | **P1** | MEDIUM → 1-user-4-personas hollow | Haidar | D35 |
| **GAP-Z8** | **Curator.OS runtime shared package (`@sparkmind/curator-os`)** | **P1** | **MEDIUM → KK Locked, future AI ext** | Haidar | **D25** |

═══════════════════════════════════════════════════════════════

## §2 · BARBERKAS GAPS (BK)

| Gap ID | Description | Severity | Status | Deadline |
|--------|-------------|----------|--------|----------|
| GAP-BK-1 | Tenant onboarding pipeline (signup → claim → seed) | P0 | Stubbed | D12 |
| GAP-BK-2 | Multi-tenant isolation middleware `withTenantContext()` | P0 | None | D14 |
| GAP-BK-3 | Duitku PG integration (QRIS 0.7%) | P0 | Doctrine done, code absent | D18 |
| GAP-BK-4 | Subdomain DNS automation | P1 | Manual | D20 |
| GAP-BK-5 | Subscription billing (monthly tier) | P0 | Tier defined, not wired | D24 |
| GAP-BK-6 | WhatsApp reminders via Fonnte | P1 | Not wired | D26 |
| GAP-BK-7 | Multi-tenant isolation tests | P0 | None | D14 |
| GAP-BK-8 | Tenant data export | P2 | Not designed | D28 |

═══════════════════════════════════════════════════════════════

## §3 · KURATORKAS GAPS (KK) — NEW v2.0

| Gap ID | Description | Severity | Status | Deadline |
|--------|-------------|----------|--------|----------|
| GAP-KK-1 | Subdomain claim `kuratorkas.sparkmind.web.id` + Worker init | P0 | None | D17 |
| GAP-KK-2 | Reverse-extract BK auth + tenant middleware | P0 | None | D20 |
| GAP-KK-3 | AI Stylist Curator MVP (Workers AI image embedding) | P0 | None | D25 |
| GAP-KK-4 | Content Curator (text-gen IG/TikTok captions) | P0 | None | D30 |
| GAP-KK-5 | Marketplace Curator (Shopee/Tokopedia/TikTok Shop sync) | P1 | None | D38 |
| GAP-KK-6 | Pricing Curator + Trend Curator | P1 | None | D45 |
| GAP-KK-7 | UMKM tenant onboarding flow (reuse BK pattern) | P1 | None | D32 |
| GAP-KK-8 | Catalog schema + image upload (R2) | P0 | None | D22 |

═══════════════════════════════════════════════════════════════

## §4 · PACELOKAL GAPS (PL)

| Gap ID | Description | Severity | Status | Deadline |
|--------|-------------|----------|--------|----------|
| GAP-PL-1 | Subdomain `pacelokal.sparkmind.web.id` + Worker init | P0 | None | D15 |
| GAP-PL-2 | Verify-Stub MVP (GPS hyperlocal verify) | P0 | None | D22 |
| GAP-PL-3 | Sunday Run Generator (Banyumas rute) | P1 | None | D28 |
| GAP-PL-4 | Leaderboard + R2 GPX storage | P1 | None | D34 |
| GAP-PL-5 | Strava import bridge | P2 | None | D40 |
| GAP-PL-6 | Race Director dashboard (Persona C) | P2 | None | D44 |
| GAP-PL-7 | Banyumas community seed (Strava-verified 2k) | P1 | None | D38 |
| GAP-PL-8 | WhatsApp-first onboarding (Persona B blue ocean) | P0 | None | D42 |

═══════════════════════════════════════════════════════════════

## §5 · NURANI.OS GAPS (NU)

| Gap ID | Description | Severity | Status | Deadline |
|--------|-------------|----------|--------|----------|
| GAP-NU-1 | Subdomain `nurani.os.sparkmind.web.id` + Worker init | P0 | None | D30 |
| GAP-NU-2 | Quran reader (basic surface) | P0 | None | D38 |
| GAP-NU-3 | Murattal audio R2 streaming | P0 | None | D42 |
| GAP-NU-4 | Tadarus group MVP (gotong-royong khataman) | P0 | None | D48 |
| GAP-NU-5 | Juz-tracking kolektif | P1 | None | D50 |
| GAP-NU-6 | Privacy-first analytics (aggregate cohort only) | P1 | None | D52 |
| GAP-NU-7 | Xendit donation/waqf integration | P1 | None | D55 |
| GAP-NU-8 | NU + Muhammadiyah endorsement-pathway outreach | P2 | None | D58 |
| GAP-NU-9 | Public preview + alpha enrollment open | P0 | None | D60 |

═══════════════════════════════════════════════════════════════

## §6 · ENGINEERING DISCIPLINE GAPS (D)

| Gap ID | Description | Severity | Status | Deadline |
|--------|-------------|----------|--------|----------|
| GAP-D-1 | E1 — Daily public commit ritual not enforced | P1 | Drift | D15 |
| GAP-D-2 | E3 — PoWPL Ledger entries < 1/day | P1 | Drift | D7 |
| GAP-D-3 | E4 — Webhook idempotency tests missing | P0 | None | D18 |
| GAP-D-4 | CI/CD smoke tests untuk 4 apps | P0 | None | D15 |
| GAP-D-5 | Sovereign cadence (05:30 wake, deep work) compliance | P1 | Partial | Ongoing |

═══════════════════════════════════════════════════════════════

## §7 · CONFLICT/OVERLAP ANTAR DOCUMENT

| Conflict ID | Doc A | Doc B | Resolution |
|-------------|-------|-------|------------|
| C-1 | DOC-Y v1.0 (3 lanes) | MASTER-CONSOLIDATED v2.0 (4 lanes) | **Resolve**: Promote DOC-Y v1.0 → v1.2 with LANE K added |
| C-2 | DOC-S v1.0 says subdomain `nurani.sparkmind.web.id` | v2.0 lock says `nurani.os.sparkmind.web.id` | **Resolve**: Refresh DOC-S §01, deprecate `nurani.sparkmind.web.id` |
| C-3 | DOC-Z v1.0 (5 shared packages) | MASTER-CONSOLIDATED v2.0 (6 shared packages) | **Resolve**: Promote DOC-Z → v1.1 with `@sparkmind/curator-os` added |
| C-4 | KuratorKas PRD v2.0 (sub-brand: KuratorKas) | DOC-AUDIT v2.0 (3-brand audit, KK absent) | **Resolve**: Next DOC-AUDIT iteration (v2.1) include KK pillar |
| C-5 | MASTER-ARCHITECT-PROMPT v5.0 (3-brand mention §1.2) | MASTER-CONSOLIDATED v2.0 (4-brand) | **Resolve**: MASTER-ARCHITECT-PROMPT v5.1 refresh sub-brand list |

═══════════════════════════════════════════════════════════════

## §8 · RESOLUTION PRIORITY MATRIX

### Pre-D15 (5 hari pertama lock)

1. **GAP-Z1** Shared identity — blocks 4 brands (P0, Haidar, D10)
2. **GAP-Z4** CI/CD turborepo + 4 apps wiring (P1, D15)
3. **GAP-D-4** CI/CD smoke tests untuk 4 apps (P0, D15)
4. **GAP-PL-1** PaceLokal subdomain claim (P0, D15)
5. **Conflict C-1, C-2, C-3**: DOC-Y → v1.2, DOC-S §01 refresh, DOC-Z → v1.1

### D15 → D30

6. **GAP-Z2** Shared payments (P0, D14, slight slip OK)
7. **GAP-BK-1..3, BK-7**: BarberKas core hardening
8. **GAP-KK-1, KK-2, KK-8**: KuratorKas scaffold + reverse-extract
9. **GAP-Z3, Z5, Z7**: UI tokens, root domain showcase, persona surface
10. **GAP-PL-2..4**: PaceLokal MVP features

### D30 → D60

11. **GAP-KK-3..6**: Curator.OS 5 modules
12. **GAP-NU-1..9**: Nurani.OS preview build
13. **GAP-BK-4..8**: BarberKas remaining polish
14. **GAP-PL-5..8**: PaceLokal completion
15. **Conflict C-4, C-5**: DOC-AUDIT v2.1 + MASTER-ARCHITECT-PROMPT v5.1 refresh

═══════════════════════════════════════════════════════════════

## §9 · BURNDOWN CHART (Conceptual)

```
Total gaps (v2.0):  42 (8 cross + 8 BK + 8 KK + 8 PL + 9 NU + 5 D - dedupes)
P0 gaps:            17 (must resolve by D30)
P1 gaps:            17 (must resolve by D45)
P2 gaps:            8  (must resolve by D60)

D0:    42 gaps open
D15:   30 gaps open (12 closed — foundation + BK + PL launch + KK init)
D30:   20 gaps open (10 closed — KK MVP + cross-brand integration)
D45:   10 gaps open (10 closed — KK Curator.OS + PL complete + NU preview start)
D60:   0–3 gaps open (10+ closed — sprint pass)
```

═══════════════════════════════════════════════════════════════

# END OF GAP MATRIX v2.0

Doctrine date: 2026-05-19 · Owner: Reza Estes / Haidar — Sovereign AI Dev
**Status**: CANONICAL · 4-SUB-BRAND EDITION
