═══════════════════════════════════════════════════════════════════════════════

# 🏁 SPARKMIND SOVEREIGN — FULL-SPRINT PLAN v1.0

**Codename**: `@Sprint-Sovereign v1.0`
**Tanggal**: 2026-05-19
**Owner**: Reza Estes / Haidar — Sovereign AI Dev
**Status**: 🔒 **CANONICAL · EXECUTE-READY · 4-BRAND PARALLEL · DOC-Y v1.2 EVOLUTION**
**Anchor**: DOC-Y v1.0/v1.1 (Sovereign Parallel Sprint) → expanded ke v1.2 + Trilogy lock
**Companions**: MASTER-ARCHITECT-PROMPT v6.0 + SESSION-HANDOFF v2.0 (Close-Out Trilogy)
**Sprint Window**: D2 (2026-05-19) → D60 (2026-07-17) · 60 hari · 8.5 minggu

═══════════════════════════════════════════════════════════════════════════════

## §00 · TL;DR EKSEKUSI

**Mode**: 4 lane PARALLEL — semua sub-brand jalan barengan, share foundation week pertama, kemudian fork.

**5 Lanes Aktif**:
- **LANE F** (Foundation) — D1–D7 intense, D8–D60 maintenance
- **LANE E** (BarberKas / P0) — D2–D16 build, D17–D60 hardening + reverse-extract source
- **LANE K** (KuratorKas / P1) — D17–D45 build (paralel BK hardening + PL)
- **LANE B** (PaceLokal / P2) — D15–D28 build (paralel KK early)
- **LANE N** (Nurani.OS / P3) — D30–D60 preview build (paralel akhir, runway ke Ramadhan 1448H)

**Target D60**: Composite Sovereign Health **28→78/100 GREEN** (+50 delta).

**Mantra**:
> *"Empat lane jalan barengan. Foundation dulu seminggu, lalu fork. Capster live D16. Sister-brand reverse-extract D17. Hobby MVP D28. Devotion preview D60. Lock. Execute."*

═══════════════════════════════════════════════════════════════════════════════

## §01 · LANE DEFINITION & RATIONALE

### 1.1 Five Parallel Lanes

| Lane | Code | Sub-brand | Lifespan | Priority | Output D60 |
|------|------|-----------|----------|----------|------------|
| **F** | FOUNDATION | ALL (cross-brand infra) | D1–D7 intense, D8–D60 maintain | shared backbone | Monorepo + 6 packages + CI/CD + DNS |
| **E** | EDGE (BarberKas) | BK | D2–D16 build, D17–D60 hardening | P0 | Production-ready, 3+ tenant, billing live |
| **K** | KURATORKAS | KK | D17–D45 build | P1 (sister) | Curator.OS 5-module MVP, 10 UMKM alpha |
| **B** | BANYUMAS (PaceLokal) | PL | D15–D28 build | P2 (hobby) | 100+ Banyumas runner community |
| **N** | NURANI | NU | D30–D60 preview | P3 (devotion) | Preview live, alpha enrollment, Ramadhan 1448H runway |

### 1.2 Kenapa Parallel (bukan Sequential)?

Per Haidar override 2026-05-19, mode = PARALLEL. Justifikasi:

1. **Reverse-extract efisiensi** — KK inherit 80% dari BK. Sequential = wait BK selesai = waste runway.
2. **PaceLokal lightweight** — MVP PL nggak butuh AI multi-agent. Bisa di-build di waktu BK hardening.
3. **Nurani.OS runway long** — production target Feb 2027 (Ramadhan 1448H). D60 = preview only. Mulai akhir D30 = cukup runway.
4. **Single-operator scalable** — fokus 1 lane per deep-work block (06:00–08:30 dan 09:00–11:00). 2 deep blocks/hari = 2 lane progress/hari.
5. **Foundation week** = 1 lane saja (LANE F) — semua effort di shared infra dulu, baru fork.

### 1.3 Dependency Graph Antar Lane

```
LANE F ──┬──► LANE E (D2)  ────────┐
         │                          │
         ├──► LANE B (D15) ────────►├──► CROSS-BRAND INTEGRATION (D55–D60)
         │                          │
         └──► LANE K (D17) ────────►│
                  ▲                  │
                  │ (reverse-extract)│
                  │                  │
              LANE E (D17+)          │
                                     │
              LANE N (D30) ─────────►┘
```

**Critical dependencies**:
- LANE E → LANE K: KK MUST wait BK ready di D17 (subdomain + auth + tenant infrastructure done)
- LANE F → ALL: monorepo + DNS + shared packages MUST scaffold di D7 sebelum lane fork
- LANE N: depend on shared identity (D10) dan shared payments (D14) di LANE F

═══════════════════════════════════════════════════════════════════════════════

## §02 · WEEK-BY-WEEK BREAKDOWN

Sprint dibagi **8 minggu** + 4 hari buffer. Setiap minggu = Sabtu Founder Review checkpoint.

### Week 0 — D2–D7 · FOUNDATION WEEK (LANE F INTENSE)

**Mantra week**: *"Foundation dulu. Fork minggu depan."*

| Day | Tasks | Lane | Output |
|-----|-------|------|--------|
| D2 | Drop Close-Out Trilogy ke repo (`docs/closeout-trilogy/`) + DEC-0001 entry | F | 3 docs committed, decision-log seeded |
| D3 | Claim 4 subdomain di Cloudflare DNS (barberkas/kuratorkas/pacelokal/nurani.os) | F | DNS active, SSL ready |
| D3 | Cloudflare account: enable Workers Paid Plan, R2, D1, KV, Queues binding | F | Bindings ready |
| D4 | Scaffold monorepo final structure (pnpm workspace + Turborepo) | F | `apps/{4}` + `packages/{6}` empty shells |
| D5 | Scaffold 6 shared packages skeleton (core, auth, pg-router, ui-kit, analytics, curator-os) | F | Each package has package.json + src/index.ts stub |
| D5 | Setup CI/CD baseline (GitHub Actions → Cloudflare Pages deploy) | F | Lint + typecheck + smoke build on PR |
| D6 | `@sparkmind/core` v0.1 — types, Result monad, env schema | F | Package publishable internal |
| D6 | `@sparkmind/auth` v0.1 — magic-link + D1 schema design | F | Schema migration ready |
| D7 | **Sabtu Founder Review** — Week 0 wrap | F | Sovereign Health re-score, decision-log delta |

**Week 0 Exit Criteria**:
- ✅ DNS 4 subdomain live (SSL active)
- ✅ Monorepo final structure di GitHub
- ✅ 6 shared packages skeleton + 2 ready (core, auth)
- ✅ CI/CD baseline green
- ✅ DEC-0001 (Trilogy lock) + DEC-0002 (Cloudflare Paid plan)

**Health Delta Week 0**: ~28 → ~38 (+10, foundation backbone)

---

### Week 1 — D8–D14 · LANE E (BarberKas) FORK + LANE F MAINTENANCE

**Mantra**: *"Capster lane ignited. Foundation jaga rumah."*

| Day | Lane E (BarberKas) | Lane F (Foundation) |
|-----|---------------------|----------------------|
| D8 | Subtree-merge atau import existing `barberkas-bundle` code ke `apps/barberkas/` | `@sparkmind/pg-router` v0.1 (Duitku adapter + StubAdapter) |
| D9 | Tenant claim flow scaffold (`<tenant>.barberkas.sparkmind.web.id` routing) | `@sparkmind/ui-kit` v0.1 (dark theme tokens + button/input atom) |
| D10 | `withTenantContext()` middleware — Pattern B isolation | **GAP-Z1 RESOLVED**: `@sparkmind/identity-core` (= auth + session) v1.0 |
| D11 | D1 schema migration: tenants table + tenant_id row-scoping | `@sparkmind/analytics` v0.1 (CF Analytics Engine wrapper) |
| D12 | **GAP-BK-1 RESOLVED**: Tenant onboarding pipeline (signup → claim → seed) | Verify GAP-Z3 (UI tokens consistent across 4 brand themes) |
| D13 | Smoke test multi-tenant isolation (2 demo tenants) | CI/CD: deploy `apps/barberkas/` to Cloudflare Workers staging |
| D14 | **Sabtu Founder Review** — Week 1 wrap | **GAP-Z2 RESOLVED**: pg-router dual-PG (Duitku + Xendit) wired |

**Week 1 Exit Criteria**:
- ✅ BarberKas subdomain live di staging (1 demo tenant accessible)
- ✅ Multi-tenant isolation middleware tested
- ✅ Shared identity package live (`@sparkmind/identity-core`)
- ✅ Shared payments router live (`@sparkmind/pg-router`)
- ✅ GAP-Z1, GAP-Z2, GAP-BK-1 resolved
- ✅ DEC-0003 (Pattern B isolation chosen) logged

**Health Delta Week 1**: ~38 → ~48 (+10, BK foundation locked + 2 P0 gap closed)

---

### Week 2 — D15–D21 · LANE B (PaceLokal) FORK + LANE E DEEPENING + LANE K KICKOFF

**Mantra**: *"Triple lane ignited. Capster deepening, hobby starts, sister readies."*

| Day | Lane E (BK) | Lane B (PL) | Lane K (KK) | Lane F |
|-----|-------------|-------------|-------------|--------|
| D15 | **GAP-BK-2 RESOLVED**: Isolation middleware production-grade | **GAP-PL-1 RESOLVED**: pacelokal subdomain + Worker init | (pre-flight: review DOC-K v2.0 + Curator.OS spec) | `@sparkmind/curator-os` skeleton (package shell) |
| D16 | POS transaction UI (cash/QRIS) | PL data model: runs, routes, runners (D1 schema) | Reverse-extract checklist drafted (auth, tenant, pg-router) | CI/CD: deploy `apps/pacelokal/` staging |
| D17 | Customer DB per-tenant UI | PL Verify-Stub scaffolding | **GAP-KK-1 RESOLVED**: kuratorkas subdomain + Worker init | — |
| D18 | **GAP-BK-3 RESOLVED**: Duitku QRIS PG integration (live keys env) | Sunday Run Generator scaffolding | Reverse-extract: copy auth + tenant middleware ke `apps/kuratorkas/` | — |
| D19 | Fonnte WhatsApp reminder integration | Banyumas route catalog seeding (R2 GPX) | Reverse-extract: copy pg-router setup ke KK | — |
| D20 | Subscription tier seeding (Rp 99K/199K/399K plan) | Strava webhook stub for verify-loop | **GAP-KK-2 RESOLVED**: Reverse-extract complete (80% BK reuse) | CI/CD: deploy `apps/kuratorkas/` staging |
| D21 | **Sabtu Founder Review** — Week 2 wrap | Verify-Stub MVP smoke test | KK landing page draft | — |

**Week 2 Exit Criteria**:
- ✅ 3 lanes active in parallel (E + B + K)
- ✅ PaceLokal subdomain live (staging)
- ✅ KuratorKas subdomain live (staging) + auth/tenant reused from BK
- ✅ Duitku QRIS integrated in BK
- ✅ DEC-0004 (BK PG choice: Duitku primary, Xendit fallback) logged

**Health Delta Week 2**: ~48 → ~57 (+9, 3-lane parallel ignited)

---

### Week 3 — D22–D28 · LANE B FINALIZATION + LANE K DEEPENING + LANE E HARDENING

**Mantra**: *"Hobby ship. Sister scale. Capster polish."*

| Day | Lane E (BK) | Lane B (PL) | Lane K (KK) |
|-----|-------------|-------------|-------------|
| D22 | Subscription billing wire-up (Duitku recurring) | **GAP-PL-2 RESOLVED**: Verify-Stub MVP production-grade | KK schema: products, catalog, AI runs |
| D23 | Test tenant: 3 demo barbershop seeded | Sunday Run Generator algorithm (cluster + route picker) | Workers AI binding: vision embedding worker scaffold |
| D24 | **GAP-BK-5 RESOLVED**: Subscription billing live | Leaderboard MVP (per-kabupaten scoring) | **GAP-KK-3 RESOLVED**: AI Stylist Curator MVP (image embed → outfit recommendation) |
| D25 | Production deploy BarberKas (live domain switch) | WhatsApp-first onboarding flow (Fonnte) | KK catalog upload UI (R2-backed) |
| D26 | BK production smoke test 24h | **GAP-PL-3 RESOLVED**: Sunday Run Generator live | Content Curator scaffold (text gen for IG caption) |
| D27 | Bug-bash session BK | Banyumas community soft-launch (10 alpha runners) | Curator.OS routing: agent dispatcher |
| D28 | **Sabtu Founder Review** — Week 3 wrap | **PL MVP COMPLETE** | KK alpha UMKM enrollment open (5 alpha sellers) |

**Week 3 Exit Criteria**:
- ✅ BarberKas production-deployed (`barberkas.sparkmind.web.id` live, 3 tenants)
- ✅ PaceLokal MVP shipped, soft-launched ke 10 Banyumas alpha
- ✅ KuratorKas Curator.OS 1st module (AI Stylist) live
- ✅ DEC-0005 (BK production cutover) logged

**Health Delta Week 3**: ~57 → ~64 (+7, BK shipped + PL MVP + KK 1st module)

---

### Week 4 — D29–D35 · LANE N IGNITION + LANE K SCALE + LANE B GROWTH

**Mantra**: *"Devotion lane ignited. Sister scaling. Hobby growing."*

| Day | Lane K (KK) | Lane B (PL) | Lane N (NU) | Lane E (BK) |
|-----|-------------|-------------|-------------|--------------|
| D29 | **GAP-KK-4 RESOLVED**: Content Curator live (IG caption gen) | Leaderboard + R2 GPX export | (pre-flight: DOC-S v1.1 review) | Hardening: error monitoring (Sentry/CF Analytics) |
| D30 | Trend Curator scaffold (TikTok/IG scraping queue) | **GAP-PL-4 RESOLVED**: Leaderboard live | **GAP-NU-1 RESOLVED**: nurani.os subdomain + Worker init | BK bug fixes wave 1 |
| D31 | Pricing Curator scaffold (dynamic price suggest) | Race directory MVP | NU data model: Quran ayat, juz, surah (seeded from public dataset, halal source) | — |
| D32 | Marketplace Curator scaffold (Shopee API stub) | Strava webhook live | NU theme: dark mode + Pan-Islamic neutral palette | — |
| D33 | KK alpha cohort: 10 UMKM enrolled | PL premium tier (Rp 49K/bulan) scaffold | NU Quran reader UI scaffold | — |
| D34 | KK billing wire (Duitku reused) | **GAP-PL-8 partial**: WhatsApp onboarding alpha | NU privacy doctrine page (no-tracking statement) | — |
| D35 | **Sabtu Founder Review** — Week 4 wrap | PL marketing soft push (Banyumas Runners IG) | Decision-log: NU monetization model finalized (donation + premium) | — |

**Week 4 Exit Criteria**:
- ✅ KK alpha cohort 10 UMKM enrolled
- ✅ Nurani.OS lane ignited (subdomain + Worker live, staging)
- ✅ PaceLokal premium tier scaffolded
- ✅ DEC-0006 (NU monetization: donation primary + halal premium) logged

**Health Delta Week 4**: ~64 → ~69 (+5, 4-lane fully parallel now)

---

### Week 5 — D36–D42 · 4-LANE FULL PARALLEL OPERATION

**Mantra**: *"All four lanes live. Maintain velocity. No drift."*

| Day | KK Focus | PL Focus | NU Focus | BK Maintain |
|-----|----------|----------|----------|--------------|
| D36 | **GAP-KK-5 partial**: Shopee API integration | PL leaderboard scale to 50+ users | **GAP-NU-2 RESOLVED**: Quran reader MVP (text + tajwid) | BK bug fixes wave 2 |
| D37 | Marketplace Curator: catalog sync test | Race directory: 5 Banyumas events listed | NU Murattal R2 storage prep | — |
| D38 | **GAP-KK-5 RESOLVED**: Shopee sync live | PL community Sunday Run #1 (real event) | **GAP-NU-3 RESOLVED**: Murattal R2 streaming live | — |
| D39 | Tokopedia API scaffold | PL feedback loop UI | NU bookmark + last-read sync (KV-backed) | — |
| D40 | TikTok Shop scaffold | Banyumas community 50+ users | NU Tadarus group MVP scaffold | — |
| D41 | KK alpha cohort: scale ke 15 UMKM | PL race director portal | NU dhikr counter MVP | — |
| D42 | **Sabtu Founder Review** — Week 5 wrap | **GAP-PL-8 RESOLVED**: WhatsApp onboarding production-grade | NU privacy audit dry-run | — |

**Week 5 Exit Criteria**:
- ✅ Marketplace Curator: Shopee live, Tokopedia scaffold
- ✅ PaceLokal real community Sunday Run executed
- ✅ Nurani.OS Quran reader + Murattal streaming live (staging)
- ✅ DEC-0007 (KK marketplace priority: Shopee > Tokopedia > TikTok Shop) logged

**Health Delta Week 5**: ~69 → ~73 (+4, full 4-lane operational momentum)

---

### Week 6 — D43–D49 · KK FINALIZATION + NU DEEPENING + CROSS-BRAND INTEGRATION

**Mantra**: *"Sister-brand cap-off. Devotion deepening. Cross-brand surface live."*

| Day | KK Final Push | NU Deepening | Cross-Brand (LANE F) |
|-----|---------------|--------------|------------------------|
| D43 | Pricing Curator live (dynamic price suggest) | NU Quran reader: complete 30 juz indexed | Cross-brand identity: single signup at `sparkmind.web.id/auth` |
| D44 | Trend Curator: TikTok scrape live | NU Tadarus group: invite link flow | 1-user-4-personas profile page |
| D45 | **GAP-KK-6 RESOLVED**: Pricing + Trend complete · **KK 5-MODULE MVP DONE** | **GAP-NU-4 RESOLVED**: Tadarus group MVP live | Single billing dashboard scaffold |
| D46 | KK production deploy (live domain switch) | NU dhikr counter polished | GAP-Z7 partial: persona surface live |
| D47 | KK production smoke 24h | NU murattal: 3 qari pre-loaded ke R2 | Cross-brand observability (CF Analytics Engine 4 datasets) |
| D48 | KK alpha cohort: 20 UMKM, GMV smoke test | NU privacy doctrine published | GAP-Z6 RESOLVED: observability live |
| D49 | **Sabtu Founder Review** — Week 6 wrap | NU NU+Muhammadiyah dual-acceptance doctrine refined | DEC-0008 (cross-brand auth root: `sparkmind.web.id/auth`) logged |

**Week 6 Exit Criteria**:
- ✅ KuratorKas Curator.OS 5-module MVP **COMPLETE & PRODUCTION**
- ✅ Nurani.OS Tadarus group MVP live
- ✅ Cross-brand auth + persona surface live
- ✅ 4-brand observability operational
- ✅ DEC-0008 (cross-brand auth root) + DEC-0009 (NU dual-mazhab content review) logged

**Health Delta Week 6**: ~73 → ~76 (+3, KK MVP done, NU deepening, cross-brand surface)

---

### Week 7 — D50–D56 · NU PREVIEW POLISH + ALL-BRAND HARDENING

**Mantra**: *"Devotion preview ready. All-brand polish."*

| Day | NU Focus | Cross-Brand Polish | All-Brand Maintenance |
|-----|----------|--------------------|------------------------|
| D50 | NU public preview UI (landing + features) | Cross-brand referral: BK→KK, PL→NU | BK: 5+ tenant scale test |
| D51 | NU alpha enrollment form (waitlist) | Single billing: subscription + donation unified UI | KK: 25+ UMKM scale test |
| D52 | NU Murattal: 5 qari production-ready | Cross-brand decision-log audit | PL: 100+ user scale test |
| D53 | NU Tadarus group: invite scale test | Doctrine sync check: MASTER-CONSOLIDATED v2.0 still canonical? | NU: preview soft-launch ke private circle |
| D54 | NU privacy: "no-tracking" badge audit | 14 constraint re-verify (all green?) | All-brand smoke test cycle |
| D55 | NU Ramadhan 1448H teaser content draft | Cross-brand observability dashboards finalized | All-brand SLO check |
| D56 | **Sabtu Founder Review** — Week 7 wrap | DEC-0010 (NU preview launch readiness) logged | — |

**Week 7 Exit Criteria**:
- ✅ Nurani.OS public preview ready
- ✅ All 4 brand scaled test passed (5+ BK, 25+ KK UMKM, 100+ PL, NU private circle)
- ✅ Cross-brand surface fully integrated
- ✅ DEC-0010 (NU preview cutover date: D60) logged

**Health Delta Week 7**: ~76 → ~77 (+1, polish + cross-brand consolidation)

---

### Week 8 — D57–D60 · NURANI.OS PUBLIC PREVIEW LAUNCH + SPRINT WRAP

**Mantra**: *"Devotion launches preview. Sprint passes. Ramadhan runway begins."*

| Day | Activity |
|-----|----------|
| D57 | NU preview production deploy + DNS cutover (nurani.os.sparkmind.web.id live) |
| D58 | NU alpha enrollment opens (public link, soft push to mosque/ustadz network) |
| D59 | Full ecosystem integration test: 1 user signup → 4 persona pickup → cross-brand journey |
| D60 | **SPRINT CLOSEOUT** — Sabtu Founder Review **MEGA EDITION** |
|     | - Composite Sovereign Health re-score (target: 78/100 GREEN) |
|     | - All 4 brand status verification |
|     | - Decision-log audit (10+ DEC entries) |
|     | - DOC-AUDIT v3.0 commission (post-sprint snapshot) |
|     | - Trilogy version check: any drift? bump if needed |
|     | - Post-sprint runway plan (D61–Ramadhan 1448H for NU, scale for BK/KK/PL) |

**Week 8 Exit Criteria (Sprint D60)**:
- ✅ Nurani.OS preview LIVE (`nurani.os.sparkmind.web.id`)
- ✅ NU alpha enrollment open
- ✅ BarberKas production: 3+ tenant, billing live, 88/100 GREEN
- ✅ KuratorKas production: 25+ UMKM alpha, Curator.OS 5-module, 70/100 GREEN
- ✅ PaceLokal MVP: 100+ Banyumas runners, 81/100 GREEN
- ✅ Composite Sovereign Health: **≥78/100 GREEN** = SPRINT PASS

**Health Delta Week 8**: ~77 → ~78–80 (sprint pass margin)

═══════════════════════════════════════════════════════════════════════════════

## §03 · GAP RESOLUTION TIMELINE (42 gaps tracked)

### 3.1 Foundation Gaps (P0 — 5 gaps)

| Gap | Description | Deadline | Lane |
|-----|-------------|----------|------|
| GAP-Z1 | Shared identity package | D10 | F |
| GAP-Z2 | Shared payments dual-PG | D14 | F |
| GAP-Z3 | Shared UI tokens | D11 | F |
| GAP-Z4 | Monorepo CI/CD | D7 | F |
| GAP-Z8 | `@sparkmind/curator-os` package | D15 | F |

### 3.2 BarberKas Gaps (8 gaps)

| Gap | Description | Deadline | Severity |
|-----|-------------|----------|----------|
| GAP-BK-1 | Tenant onboarding pipeline | D12 | P0 |
| GAP-BK-2 | Isolation middleware production | D15 | P0 |
| GAP-BK-3 | Duitku QRIS integration | D18 | P0 |
| GAP-BK-4 | Customer DB per-tenant UI | D20 | P1 |
| GAP-BK-5 | Subscription billing | D24 | P0 |
| GAP-BK-6 | Fonnte WhatsApp reminder | D26 | P1 |
| GAP-BK-7 | BK production cutover | D25 | P0 |
| GAP-BK-8 | Multi-tenant isolation tests | D24 | P0 |

### 3.3 KuratorKas Gaps (8 gaps)

| Gap | Description | Deadline | Severity |
|-----|-------------|----------|----------|
| GAP-KK-1 | Subdomain + Worker init | D17 | P0 |
| GAP-KK-2 | Reverse-extract from BK | D20 | P0 |
| GAP-KK-3 | AI Stylist Curator MVP | D24 | P0 |
| GAP-KK-4 | Content Curator | D29 | P0 |
| GAP-KK-5 | Marketplace Curator (Shopee) | D38 | P0 |
| GAP-KK-6 | Pricing + Trend Curator | D45 | P0 |
| GAP-KK-7 | KK production cutover | D46 | P0 |
| GAP-KK-8 | KK alpha cohort enrollment | D48 | P1 |

### 3.4 PaceLokal Gaps (8 gaps)

| Gap | Description | Deadline | Severity |
|-----|-------------|----------|----------|
| GAP-PL-1 | Subdomain + Worker init | D15 | P0 |
| GAP-PL-2 | Verify-Stub MVP | D22 | P0 |
| GAP-PL-3 | Sunday Run Generator | D26 | P0 |
| GAP-PL-4 | Leaderboard + R2 GPX | D30 | P0 |
| GAP-PL-5 | Strava webhook | D32 | P1 |
| GAP-PL-6 | Race directory MVP | D31 | P1 |
| GAP-PL-7 | Premium tier scaffold | D33 | P1 |
| GAP-PL-8 | WhatsApp-first onboarding | D42 | P0 |

### 3.5 Nurani.OS Gaps (9 gaps)

| Gap | Description | Deadline | Severity |
|-----|-------------|----------|----------|
| GAP-NU-1 | Subdomain + Worker init | D30 | P0 |
| GAP-NU-2 | Quran reader MVP | D36 | P0 |
| GAP-NU-3 | Murattal R2 streaming | D38 | P0 |
| GAP-NU-4 | Tadarus group MVP | D45 | P0 |
| GAP-NU-5 | Dhikr counter | D41 | P1 |
| GAP-NU-6 | Bookmark + last-read sync | D39 | P1 |
| GAP-NU-7 | Privacy doctrine page | D34 | P1 |
| GAP-NU-8 | NU+Muhammadiyah dual content review | D49 | P0 |
| GAP-NU-9 | Public preview + alpha enrollment | D60 | P0 |

### 3.6 Cross-Brand & Engineering (4 gaps)

| Gap | Description | Deadline | Severity |
|-----|-------------|----------|----------|
| GAP-Z5 | Root domain doctrine + 4-sub-brand showcase | D52 | P1 |
| GAP-Z6 | Cross-brand observability | D48 | P2 |
| GAP-Z7 | Cross-brand persona surface | D45 | P1 |
| GAP-D | Engineering discipline (CI/CD, tests, decision-log) | D15 | P1 |

═══════════════════════════════════════════════════════════════════════════════

## §04 · DEPENDENCY MATRIX

### 4.1 Blocking Dependencies

| Predecessor | Successor | Type | Resolution |
|-------------|-----------|------|------------|
| GAP-Z1 (identity) | All sub-brand auth | HARD | Must D10 |
| GAP-Z2 (payments) | BK billing, KK billing, NU donation | HARD | Must D14 |
| GAP-BK-2 (isolation) | GAP-KK-2 (reverse-extract) | HARD | Must D15 before D20 |
| GAP-BK-3 (Duitku) | GAP-KK-3+ (KK PG reuse) | SOFT | KK can stub then swap |
| LANE F D7 complete | LANE E/B/K/N fork | HARD | All fork after D7 |
| GAP-KK-2 (reverse-extract) | GAP-KK-3+ (Curator.OS modules) | HARD | Must D20 before D24 |
| GAP-NU-2 (Quran reader) | GAP-NU-4 (Tadarus group) | HARD | Must D36 before D45 |
| Cross-brand identity (D43) | 1-user-4-persona flow | HARD | Must D43 before D49 |

### 4.2 Soft Dependencies (Enable, tidak block)

| Soft Dep | Enables | Notes |
|----------|---------|-------|
| BK live in prod (D25) | KK marketing leverage | "BarberKas sister-brand" pitch |
| PL community (D27) | Cross-brand persona surface | Pelari = persona ke-3 |
| NU privacy doctrine (D34) | NU+Muhammadiyah endorsement | Trust foundation |

═══════════════════════════════════════════════════════════════════════════════

## §05 · DAILY OPERATIONAL DISCIPLINE

### 5.1 Sovereign Daily Cadence (per DOC-D §11.2)

```
05:30  Wake + sholat Subuh
06:00  Deep work block 1 (highest-priority lane) — 2h 30m
08:30  Coffee + brief review (15m)
08:45  Decision-log delta entry (15m)
09:00  Deep work block 2 (second-priority lane) — 2h
11:00  Final lane status update + handoff prep (30m)
11:30  Family / Ibu / Nurul time — NO CODE
```

### 5.2 Lane Rotation Pattern (4-Lane Parallel)

Karena 4 lane paralel tapi cuma 2 deep blocks/hari:

**Pattern Senin–Jumat**:
- Senin AM: Lane E (BK) · PM: Lane F (Foundation)
- Selasa AM: Lane K (KK) · PM: Lane E (BK)
- Rabu AM: Lane B (PL) · PM: Lane K (KK)
- Kamis AM: Lane N (NU) · PM: Lane B (PL)
- Jumat AM: Lane F (Foundation) · PM: Lane N (NU)

**Sabtu**: Founder Review + light catchup (no deep work block)
**Minggu**: Off (rekoveri + family)

**Aturan**:
- 1 lane per deep block (no context-switch dalam block)
- Lane progress = git commit minimum 1x per block
- Decision-log entry kalau ada irreversible choice di block tersebut

### 5.3 Weekly Founder Review (Sabtu 09:00–11:00 WIB)

Checklist setiap Sabtu:

```
[ ] Composite Sovereign Health re-score (8 pillar)
[ ] Per-lane progress vs FULL-SPRINT v1.0 milestone
[ ] Decision-log delta (entries this week)
[ ] Cross-brand gap status (42 gaps tracking)
[ ] Drift signals raised (any from §04 anti-drift)
[ ] Constraint check (14 hardcoded — green/amber/red?)
[ ] Next week's lane rotation plan
[ ] Handoff block generated (SESSION-HANDOFF v2.0)
```

═══════════════════════════════════════════════════════════════════════════════

## §06 · RISK & MITIGATION

### 6.1 Top Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| **R1**: 4-lane parallel → context-switch overhead | HIGH | HIGH | Lane rotation strict (5.2), 1 lane per block |
| **R2**: Reverse-extract BK→KK lossy (KK custom needs) | MEDIUM | HIGH | Drafting checklist D16, smoke test isolation D20 |
| **R3**: Duitku verification stuck > D18 | MEDIUM | HIGH | Xendit fallback ready (dual-PG mandate) |
| **R4**: Nurani.OS halal/mazhab content review slow | MEDIUM | MEDIUM | Pre-flight DOC-S v1.1 D29, dry-run privacy D54 |
| **R5**: Single-operator burnout | HIGH | CRITICAL | Strict 11:30 family cutoff, Minggu OFF, Sabtu light |
| **R6**: Cloudflare cost spike | LOW | MEDIUM | Monthly cost-aware review (constraint #12) |
| **R7**: Drift back to sequential mode | MEDIUM | HIGH | Trilogy lock (constraint #13/#14 v6.0 §1.5), Sabtu review |
| **R8**: KK alpha cohort fail to enroll | MEDIUM | MEDIUM | Pre-seed via BK tenant cross-sell (1-user-4-persona) |
| **R9**: PL Banyumas community no traction | MEDIUM | MEDIUM | WhatsApp-first (D42) + free MVP forever option |
| **R10**: NU public preview Ramadhan content delay | LOW | HIGH | D55 teaser draft, content marketing window D60→Feb 2027 |

### 6.2 Escape Hatches

Kalau composite health drop di Sabtu review (>5 point regression):

1. **Activate `@SOS-Sovereign v6.0`** (per MASTER-ARCHITECT v6.0 §20)
2. **Pause non-P0 lane** — focus 1 lane saja sampai recovery
3. **Decision-log entry** — root cause + recovery plan
4. **Re-baseline week target** — adjust D60 target jika perlu (max -3 point allowance)
5. **Family/operator wellness check** — burnout indicator?

═══════════════════════════════════════════════════════════════════════════════

## §07 · REVENUE TARGETS BY D60

| Brand | D60 Revenue Target | Mechanism |
|-------|---------------------|-----------|
| BarberKas | Rp 1–3 juta/bulan recurring (3+ tenant × Rp 99K–399K) | Duitku QRIS subscription |
| KuratorKas | Rp 500K–1.5 juta/bulan recurring (10–25 UMKM × Rp 149K) | Duitku QRIS subscription |
| PaceLokal | Rp 0 (free MVP), premium scaffold ready | Premium tier scaffolded, no charge yet |
| Nurani.OS | Rp 0 (preview only, donation infra ready) | Xendit donation form scaffolded |
| **Total D60** | **Rp 1.5–4.5 juta/bulan recurring** | **Validates revenue-first constraint** |

**D90 target** (post-sprint): Rp 5–10 juta/bulan recurring (BK + KK scale).

═══════════════════════════════════════════════════════════════════════════════

## §08 · COMPOSITE HEALTH TRAJECTORY

```
Score
100│                                                          ┌─ Target 78
 80│                                                       ╭─╯
 70│                                                  ╭───╯
 60│                                          ╭───╮──╯
 50│                                  ╭───────╯
 40│                          ╭───────╯
 30│ ●──╮                ╭───╯
 20│    ╰────────────────╯
 10│
  0└─────────────────────────────────────────────────────────────
    D2  D7  D14 D21 D28 D35 D42 D49 D56 D60
    28→ 38→ 48→ 57→ 64→ 69→ 73→ 76→ 77→ 78 GREEN
```

**Sprint pass criteria**: Composite ≥ 78/100 at D60.

═══════════════════════════════════════════════════════════════════════════════

## §09 · DECISION LOG ENTRIES (Anticipated DEC-0001 → DEC-0010)

| ID | Title | Week |
|----|-------|------|
| DEC-0001 | Lock Close-Out Trilogy as canonical (Trilogy v6.0/v2.0/v1.0) | W0 |
| DEC-0002 | Cloudflare Workers Paid Plan activation | W0 |
| DEC-0003 | BK multi-tenant Pattern B (single D1 + tenant_id) untuk D0–D30 | W1 |
| DEC-0004 | BK PG primary: Duitku, fallback: Xendit | W2 |
| DEC-0005 | BK production cutover D25 | W3 |
| DEC-0006 | NU monetization model: donation primary + halal premium | W4 |
| DEC-0007 | KK marketplace priority: Shopee > Tokopedia > TikTok Shop | W5 |
| DEC-0008 | Cross-brand auth root: `sparkmind.web.id/auth` | W6 |
| DEC-0009 | NU NU+Muhammadiyah dual-mazhab content review process | W6 |
| DEC-0010 | NU preview cutover D60 (production target: Ramadhan 1448H Feb 2027) | W7 |

═══════════════════════════════════════════════════════════════════════════════

## §10 · POST-SPRINT RUNWAY (D61+ Outlook)

### 10.1 BarberKas Post-Sprint

- D61–D90: Scale to 20+ tenant, Fonnte WhatsApp marketing automation
- D91–D120: Pattern A migration evaluation (if tenant >100)
- Q4 2026: Franchise/multi-location feature

### 10.2 KuratorKas Post-Sprint

- D61–D90: Scale to 100 UMKM alpha
- D91–D120: Tokopedia + TikTok Shop sync complete
- 2027 H1: 1,000 UMKM target (per DOC-K v2.0 objectives)

### 10.3 PaceLokal Post-Sprint

- D61–D90: Premium tier launch (Rp 49K/bulan)
- D91–D120: Expand ke kabupaten lain (Cilacap, Purbalingga)
- 2027: Race event sponsorship monetization

### 10.4 Nurani.OS Post-Sprint (CRITICAL RUNWAY)

- **D60–Q4 2026 (8–12 minggu)**: Content build-up, NU+Muhammadiyah endorsement outreach
- **Q4 2026 (Nov–Des)**: Production readiness, beta cohort onboarding
- **Senin 8 Feb 2027**: **RAMADHAN 1448H BEACHHEAD LAUNCH** — Tadarus-first OS public
- **Ramadhan 1448H — Syawal**: Acquire 10K+ users (trust vacuum dari Muslim Pro 2020 scandal)

═══════════════════════════════════════════════════════════════════════════════

## §11 · DOCTRINE VERSION & SIGNATURE

```
================================================================
Doctrine:    SPARKMIND SOVEREIGN FULL-SPRINT PLAN
Version:     v1.0 (4-brand parallel, 60-day window)
Status:      CANONICAL · EXECUTE-READY · 4-BRAND PARALLEL-LOCKED
Date:        2026-05-19
Owner:       Reza Estes / Haidar — Sovereign AI Dev
Sprint:      D2 (2026-05-19) → D60 (2026-07-17)
Sprint End:  2026-07-17 (Sabtu Founder Review MEGA EDITION)
Anchor:      DOC-Y v1.0/v1.1 (Sovereign Parallel Sprint)
             → Evolved to v1.2 + Trilogy Lock
Companions:  MASTER-ARCHITECT-PROMPT v6.0 + SESSION-HANDOFF v2.0
             (= Close-Out Trilogy)
Lanes:       5 (F, E, K, B, N) — parallel mode locked
Gaps:        42 tracked (Foundation 5 + BK 8 + KK 8 + PL 8 + NU 9 + Cross 4)
Health:      28/100 → 78/100 GREEN (+50 delta)
Risks:       10 cataloged with mitigation (§06)
Decisions:   10 anticipated DEC entries (§09)
================================================================
```

═══════════════════════════════════════════════════════════════════════════════

— END OF FULL-SPRINT PLAN v1.0 —

**4 LANE PARALLEL. 60 HARI. EXECUTE.**

Doctrine date: 2026-05-19
Owner: Reza Estes / Haidar — Sovereign AI Dev
Consolidated by: Sovereign AI Dev Co-Architect (Genspark Close-Out Trilogy session)
Trilogy companion: MASTER-ARCHITECT-PROMPT v6.0 + SESSION-HANDOFF v2.0

═══════════════════════════════════════════════════════════════════════════════
