# DOC-INDEX CANONICAL v1.0 — SparkMind Sovereign File Master Map

> **Companion ke `SPARKMIND-AI-DEV-HANDOFF-v1.0.md` §08.**
> Tujuan: satu titik referensi untuk semua 80+ file dokumen / bundle / strategi / draft di ekosistem SparkMind Sovereign per 2026-05-18.
> Versi ringkas tabel doctrine-tier P0 ada di handoff §08.3. File ini menampung **lengkap**.

## 1. Skema kolom

| Kolom | Arti |
|---|---|
| `#` | Nomor urut indeks (stabil — referensi di doctrine pakai ID ini) |
| Nama Singkat | File slug singkat (sesuai upload) |
| URL | File wrapper canonical (genspark) |
| Kategori | Doctrine · Strategy · Execution · Audit · Personal · Bundle · Reference · Tooling |
| Priority | P0 (must-load setiap sesi) · P1 (active) · P2 (historical) · P3 (legacy/draft) |
| Brand | Mother (SparkMind) · BK (BarberKas) · PL (PaceLokal) · NO (Nurani.OS) · Cross · Personal |
| Type | Doctrine · Strategy · Execution Plan · Audit · Personal Doctrine · Tooling · Reference · Bundle |
| Dependencies | File-file lain yang merupakan parent/inspirasi |
| Status | Canonical Locked · Active Draft · Legacy Reference · Personal-Sealed |
| Pickup Note | One-liner instruksi untuk AI Dev / next session |

## 2. Tabel master (80+ entri)

### 2.1 Doctrine Core (P0 — must-load setiap sesi)

| # | Nama Singkat | URL | Kategori | P | Brand | Type | Deps | Status | Pickup Note |
|---|---|---|---|---|---|---|---|---|---|
| 01 | DOC-A misi hidup (mssi.hdupp) | https://www.genspark.ai/api/files/s/3nLLvw6R | Personal | P0 | Mother | Doctrine | — | Canonical Locked | Baca 1 paragraf tiap pagi sebelum buka editor. |
| 02 | doc.A.doc.B (canonical pair) | https://www.genspark.ai/api/files/s/uN58ASlv | Personal | P0 | Mother | Doctrine | 01 | Canonical Locked | Section §09 di handoff. |
| 03 | doc.a.doc.b.clarrittyy | https://www.genspark.ai/api/files/s/kWJts5rl | Personal | P0 | Mother | Doctrine | 02 | Canonical Locked | DOC-B clarrittyy round, autoritatif. |
| 04 | DOC-D svereign engineering discipline | https://www.genspark.ai/api/files/s/xzaDu4Ow | Doctrine | P0 | Mother | Doctrine | 02 | Canonical Locked | Re-read sebelum push pertama tiap minggu. |
| 05 | DOC-M Monorepo Bundle ZIP | https://www.genspark.ai/api/files/s/AO5fkBi8 | Bundle | P0 | Cross | Doctrine+Bundle | 04 | Canonical Locked | Repo layout authority. |
| 06 | doc.m.mnoreppoo | https://www.genspark.ai/api/files/s/6GKPCaUk | Doctrine | P0 | Cross | Doctrine | 05 | Canonical Locked | Monorepo single-page. |
| 07 | monorepo.stra.teggicc | https://www.genspark.ai/api/files/s/wSTO5dsz | Strategy | P1 | Cross | Strategy | 06 | Canonical Locked | Strategic monorepo decisions. |
| 08 | DOC-R Sovereign Running Bundle | https://www.genspark.ai/api/files/s/gz1usZnI | Bundle | P0 | PL | Doctrine+Bundle | 04 | Canonical Locked | Sebelum Lane B (D15). |
| 09 | paceee.locall.mdd.hrdenn (DR 9265w) | https://www.genspark.ai/api/files/s/MFNZVljj | Strategy | P0 | PL | Strategy | 08 | Canonical Locked | PaceLokal hardening blueprint. |
| 10 | DOC-S Spiritual OS Bundle | https://www.genspark.ai/api/files/s/HKtLRWzy | Bundle | P0 | NO | Doctrine+Bundle | 04 | Canonical Locked | Sebelum Lane C (D30). |
| 11 | DOC-X Execution Reality Bundle | https://www.genspark.ai/api/files/s/vvfOcKUT | Bundle | P0 | Cross | Doctrine+Bundle | 04 | Canonical Locked | Reality-check tiap ragu. |
| 12 | doc.x.creattedd | https://www.genspark.ai/api/files/s/GKuhEbFp | Doctrine | P0 | Cross | Execution | 11 | Canonical Locked | DOC-X single-page. |
| 13 | docc.x.realityy.tyy.bundlee | https://www.genspark.ai/api/files/s/wah9Do7Y | Bundle | P0 | Cross | Bundle | 11,12 | Canonical Locked | Reality variant. |
| 14 | DOC-Y doc-y-bundle | https://www.genspark.ai/api/files/s/YuPKk6UB | Bundle | P0 | Cross | Doctrine+Bundle | 11 | Canonical Locked | Parallel Sprint master. |
| 15 | docc.y.creattedd | https://www.genspark.ai/api/files/s/zGTQlkG3 | Doctrine | P0 | Cross | Execution | 14 | Canonical Locked | DOC-Y single-page. |
| 16 | doc.y.creattedd.execute | https://www.genspark.ai/api/files/s/PCqzfsVU | Execution | P0 | Cross | Execution Plan | 14,15 | Canonical Locked | DOC-Y exec view. |
| 17 | DOC-Z Cross-Brand Integration Bundle | https://www.genspark.ai/api/files/s/ps82HRlr | Bundle | P0 | Cross | Doctrine+Bundle | 14 | Canonical Locked | Cross-brand contract source. |
| 18 | cross.brandd.mtherr.brandd.sbb.brandd | https://www.genspark.ai/api/files/s/7xAnrhrG | Doctrine | P0 | Cross | Doctrine | 17 | Canonical Locked | Cross-brand verbose. |
| 19 | docc.z.cteated | https://www.genspark.ai/api/files/s/EmNhJnNw | Doctrine | P0 | Cross | Execution | 17,18 | Canonical Locked | DOC-Z single-page. |
| 20 | doc n.creatted | https://www.genspark.ai/api/files/s/FTrCrwgH | Doctrine | P1 | Cross | Execution | 19 | Canonical Locked | DOC-N derivative. |
| 21 | DOC-AUDIT v2.0 Bundle | https://www.genspark.ai/api/files/s/KF39ctlJ | Bundle | P0 | Cross | Audit+Bundle | 11,14,17 | Canonical Locked | Health score source-of-truth. |
| 22 | docc.audditt.bundlee | https://www.genspark.ai/api/files/s/nL08iLpz | Audit | P0 | Cross | Audit | 21 | Canonical Locked | DOC-AUDIT verbose deep-research. |
| 23 | DUAL-PG-STRATEGY v1.0 ZIP | https://www.genspark.ai/api/files/s/ks8ufa3n | Bundle | P0 | Cross | Strategy+Bundle | 17 | Canonical Locked | Payment phase 0 (D5). |
| 24 | DUAL-PG-STRATEGY-v1.0.html | https://www.genspark.ai/api/files/s/2xeoltR0 | Strategy | P0 | Cross | Strategy | 23 | Canonical Locked | Visual reference theme. |
| 25 | duall.pgg | https://www.genspark.ai/api/files/s/PnEkyOgh | Strategy | P0 | Cross | Strategy | 23 | Canonical Locked | Dual-PG single-page. |
| 26 | msyerr.architectt.promptt.+.sos | https://www.genspark.ai/api/files/s/vUpcYZ3M | Tooling | P0 | Mother | Tooling | 04 | Canonical Locked | Re-prompt next AI Dev. |
| 27 | msterr.architectt.promott.duitkuu | https://www.genspark.ai/api/files/s/KsZYwpLl | Tooling | P0 | Cross | Tooling | 23,26 | Canonical Locked | Architect prompt + Duitku ctx. |
| 28 | upgrade.enhance nsterr.arcbitect | https://www.genspark.ai/api/files/s/9iTDYxZW | Tooling | P0 | Mother | Tooling | 26 | Canonical Locked | Architect prompt upgrade. |

### 2.2 Active Strategy & Execution (P1)

| # | Nama Singkat | URL | Kategori | P | Brand | Type | Deps | Status | Pickup Note |
|---|---|---|---|---|---|---|---|---|---|
| 29 | sparkmind-full-bundle-v1.0 | https://www.genspark.ai/api/files/s/A8faENOh | Bundle | P0 | Cross | Bundle | 01–28 | Canonical Locked | The full-fat bundle — last-resort context dump. |
| 30 | clarrittyy.ohasee.2.ai.dev.hnddoff | https://www.genspark.ai/api/files/s/4Z2bDpM8 | Execution | P1 | Cross | Execution Plan | 21 | Active Draft | Sumber langsung handoff v1.0 ini. |
| 31 | deep.researchh.agnt.docc | https://www.genspark.ai/api/files/s/vVkMSof4 | Strategy | P1 | Cross | Deep Research | 21 | Canonical Locked | Cross-brand DR output. |
| 32 | full.hrden.clarritty | https://www.genspark.ai/api/files/s/XIE3qA4N | Strategy | P1 | Cross | Hardening | 21 | Active Draft | Hardening pass full doc. |
| 33 | doc.createddd.cnsldtdd.sccess | https://www.genspark.ai/api/files/s/LSz5ybgL | Execution | P1 | Cross | Execution Plan | 16 | Active Draft | Consolidated success plan. |
| 34 | pace.locall | https://www.genspark.ai/api/files/s/jWVkAhN2 | Strategy | P1 | PL | Strategy | 09 | Active Draft | PaceLokal single-page strategy. |
| 35 | spereignn.runn | https://www.genspark.ai/api/files/s/MQDSvr9k | Strategy | P1 | PL | Deep Research | 08,09 | Canonical Locked | Running DR variant. |
| 36 | svereignn.runn.ningg | https://www.genspark.ai/api/files/s/QPyt67K9 | Strategy | P1 | PL | Deep Research | 35 | Canonical Locked | Running DR variant 2. |
| 37 | full hrdeninggg..full auditt | https://www.genspark.ai/api/files/s/n8KbaJU3 | Audit | P1 | Cross | Audit | 22,32 | Active Draft | Full hardening audit combined. |
| 38 | full auditt.full.hrdeningg.clarritty | https://www.genspark.ai/api/files/s/iriBPJYB | Audit | P1 | Cross | Audit | 37 | Active Draft | Clarrittyy round audit. |
| 39 | clarrittyy | https://www.genspark.ai/api/files/s/TBOjBHlw | Execution | P1 | Cross | Clarrittyy | 30 | Active Draft | Clarrittyy primary. |
| 40 | clarrittyy.1 | https://www.genspark.ai/api/files/s/DOKxd95N | Execution | P1 | Cross | Clarrittyy | 39 | Active Draft | Clarrittyy iteration 1. |
| 41 | clarrittyyy | https://www.genspark.ai/api/files/s/HjNYMglc | Execution | P1 | Cross | Clarrittyy | 39 | Active Draft | Clarrittyy iteration 3. |
| 42 | byypass.fll.docc | https://www.genspark.ai/api/files/s/JnYN4U3e | Execution | P1 | Cross | Bypass | 30 | Active Draft | Bypass full-doc shortcut. |
| 43 | execute.dpc.lnee.a | https://www.genspark.ai/api/files/s/N4ApRr7V | Execution | P1 | BK | Execution Plan | 16 | Active Draft | Lane A execute mode. |
| 44 | nurani.os | https://www.genspark.ai/api/files/s/OuNSyMXK | Strategy | P0 | NO | Strategy | 10 | Canonical Locked | Nurani.OS single-page. |
| 45 | nurrannii.os | https://www.genspark.ai/api/files/s/e14V6GAQ | Strategy | P0 | NO | Deep Research | 10,44 | Canonical Locked | Nurani DR verbose. |
| 46 | L.1.L.5.Clarrityy.ty | https://www.genspark.ai/api/files/s/ZbHWXfPx | Execution | P1 | Cross | Clarrittyy | 39 | Active Draft | L1–L5 clarrittyy frame. |
| 47 | sndboxx.duitkuu | https://www.genspark.ai/api/files/s/fml3hNrF | Execution | P1 | Cross | Payment Sandbox | 25 | Active Draft | Duitku sandbox notes. |
| 48 | msterr.clarrittyy.name | https://www.genspark.ai/api/files/s/PRfz1G2P | Personal | P1 | Personal | Personal Doctrine | 03 | Personal-Sealed | Honor privacy — don't quote. |
| 49 | barberkas-bundle | https://www.genspark.ai/api/files/s/dbb78hVm | Bundle | P0 | BK | Bundle | 04,05 | Canonical Locked | BarberKas full bundle. |
| 50 | barberkas.clarrittyy | https://www.genspark.ai/api/files/s/W2AjzMGX | Strategy | P1 | BK | Strategy | 49 | Active Draft | BK clarrittyy single-page. |
| 51 | barber.kass.id | https://www.genspark.ai/api/files/s/ENx24nx9 | Strategy | P1 | BK | Strategy | 49 | Active Draft | BK Indonesia angle. |
| 52 | brberkas.frst.rvenue | https://www.genspark.ai/api/files/s/2qYJXr5c | Execution | P1 | BK | Execution Plan | 49 | Active Draft | First revenue playbook. |
| 53 | brber.lass.mlti.tnant | https://www.genspark.ai/api/files/s/IRPTjC3F | Strategy | P0 | BK | Strategy | 49 | Canonical Locked | Multi-tenant blueprint BK. |
| 54 | sb.dmain.brberkas | https://www.genspark.ai/api/files/s/81Pz8wKB | Strategy | P1 | BK | Strategy | 49,53 | Active Draft | BK subdomain strategy. |
| 55 | scraperr.brberrkass | https://www.genspark.ai/api/files/s/C1MtxvCo | Tooling | P2 | BK | Tooling | 49 | Active Draft | BK scraper exploration. |
| 56 | barberkass.intgrteddd | https://www.genspark.ai/api/files/s/frUhJzM3 | Strategy | P1 | BK | Strategy | 53 | Active Draft | BK integrated strategy. |
| 57 | barber.kass.docc.creattedd.id | https://www.genspark.ai/api/files/s/SqtjaJRP | Execution | P1 | BK | Execution Plan | 49 | Active Draft | BK Indonesia exec plan. |
| 58 | brner.kass.doc.createdd.dee.research | https://www.genspark.ai/api/files/s/IVI3wVCc | Strategy | P1 | BK | Deep Research | 53 | Canonical Locked | BK DR output. |

### 2.3 Audit · Personal · Reference (P1–P2)

| # | Nama Singkat | URL | Kategori | P | Brand | Type | Deps | Status | Pickup Note |
|---|---|---|---|---|---|---|---|---|---|
| 59 | sveteign.doc.creatted | https://www.genspark.ai/api/files/s/3F4fR8Wt | Doctrine | P1 | Cross | Doctrine | 04 | Active Draft | Sovereign doc variant. |
| 60 | svereign.dcidion | https://www.genspark.ai/api/files/s/7kRFmvJo | Doctrine | P1 | Cross | Doctrine | 04 | Active Draft | Sovereign decision frame. |
| 61 | fll.clarrittyy.svereign | https://www.genspark.ai/api/files/s/CTQbjGfP | Execution | P1 | Cross | Clarrittyy | 39,60 | Active Draft | Full clarrittyy sovereign. |
| 62 | doc.createdd.hml | https://www.genspark.ai/api/files/s/DB2xsD19 | Reference | P2 | Cross | Reference | — | Active Draft | HTML doc output reference. |
| 63 | reppoo.docc.creattedd | https://www.genspark.ai/api/files/s/lc58CqPS | Execution | P1 | Cross | Repo Plan | 05 | Active Draft | Repo doc plan. |
| 64 | reppoo.strateggicc | https://www.genspark.ai/api/files/s/NUWAZqF4 | Strategy | P1 | Cross | Strategy | 63 | Active Draft | Repo strategic plan. |
| 65 | dc.bndke.creattedd | https://www.genspark.ai/api/files/s/Jszn95SA | Bundle | P2 | Cross | Bundle | 29 | Legacy Reference | Bundle creation variant. |
| 66 | dc.creatteddd..bndle.mgrtddd | https://www.genspark.ai/api/files/s/QOs7cPJQ | Bundle | P2 | Cross | Bundle | 65 | Legacy Reference | Bundle migrate variant. |
| 67 | clarritttyy..gocc.creattedd | https://www.genspark.ai/api/files/s/H1zIECP6 | Execution | P2 | Cross | Clarrittyy | 39 | Legacy Reference | Clarrittyy gocc variant. |
| 68 | clarrittyy.q.q.q.q | https://www.genspark.ai/api/files/s/ucjm27pj | Execution | P2 | Cross | Clarrittyy | 39 | Legacy Reference | Iteration. |
| 69 | docc.q.qdoc | https://www.genspark.ai/api/files/s/Km3wKXkW | Execution | P2 | Cross | Clarrittyy | 39 | Legacy Reference | Iteration. |
| 70 | doc.1.q.qdoc | https://www.genspark.ai/api/files/s/2FNhlL3K | Execution | P2 | Cross | Clarrittyy | 39 | Legacy Reference | Iteration. |
| 71 | tim.duitku.vrif | https://www.genspark.ai/api/files/s/Pj5b3Mtc | Strategy | P1 | Cross | Payment | 25 | Active Draft | Duitku tim verifikasi notes. |
| 72 | auditt.duitkuu | https://www.genspark.ai/api/files/s/AZcbn5ks | Audit | P1 | Cross | Audit | 22,25 | Active Draft | Duitku audit. |
| 73 | lgall.xendittt | https://www.genspark.ai/api/files/s/aXbYQg6v | Strategy | P1 | Cross | Payment Legal | 25 | Active Draft | Xendit legal angle. |
| 74 | mgratedd.xendittt | https://www.genspark.ai/api/files/s/6Gnqyfam | Strategy | P1 | Cross | Payment Migrate | 25 | Active Draft | Xendit migrate notes. |
| 75 | kngenn.bratt | https://www.genspark.ai/api/files/s/0fxn1A0W | Personal | P2 | Personal | Personal Doctrine | 03 | Personal-Sealed | Honor privacy. |
| 76 | re.frame.cllapse | https://www.genspark.ai/api/files/s/yHihVlrJ | Personal | P2 | Personal | Personal Doctrine | 03 | Personal-Sealed | Reframe & collapse note. |
| 77 | full.hrdenn.docc | https://www.genspark.ai/api/files/s/06Gj7aXS | Strategy | P1 | Cross | Hardening | 32 | Active Draft | Hardening doc full. |
| 78 | archive_20260518_055800 | https://www.genspark.ai/api/files/s/MezUFCPI | Bundle | P3 | Cross | Bundle | — | Legacy Reference | Snapshot archive. |
| 79 | New Folder 25.obp | https://www.genspark.ai/api/files/s/nRWJ3rfo | Bundle | P3 | Cross | Bundle | — | Legacy Reference | OBP folder backup. |
| 80 | New Folder 25 (3.67MB) | https://www.genspark.ai/api/files/s/2dSUQ6P1 | Bundle | P3 | Cross | Bundle | — | Legacy Reference | OBP folder backup 2. |

### 2.4 Personal-Sealed (P0/P1 — handle dengan privacy doctrine)

> ⚠️ Semua file di section ini di-honor sebagai **Personal-Sealed**. AI Dev tidak boleh extract verbatim; gunakan hanya sebagai konteks privat untuk Haidar.

| # | Nama Singkat | URL | Kategori | P | Brand | Type | Deps | Status | Pickup Note |
|---|---|---|---|---|---|---|---|---|---|
| 81 | mstahill.nrull | https://www.genspark.ai/api/files/s/Fa09WW48 | Personal | P0 | Personal | Personal Doctrine | 02,03 | Personal-Sealed | Mustahil → Nurul reframe. Honor. |
| 82 | osint.public | https://www.genspark.ai/api/files/s/jV4x49u3 | Personal | P0 | Personal | OSINT Refusal | 81 | Personal-Sealed | Hard refusal doc. Re-read sebelum AI Dev session. |
| 83 | pelarrii.doc | https://www.genspark.ai/api/files/s/UVbCRttR | Personal | P1 | Personal | Personal Doctrine | 81 | Personal-Sealed | Pelari narrative. |
| 84 | pelarriimee | https://www.genspark.ai/api/files/s/0RV11KeB | Personal | P1 | Personal | Personal Doctrine | 83 | Personal-Sealed | Pelari me-arc. |
| 85 | ee.e.e.e..e.w | https://www.genspark.ai/api/files/s/whUV8Jrx | Personal | P0 | Personal | OSINT Hard Refusal | 82 | Personal-Sealed | **The refusal doc.** Cite at §09. |
| 86 | paw.paww.ee.papeqppwpw | https://www.genspark.ai/api/files/s/hdkMEza8 | Personal | P1 | Personal | OSINT Hard Refusal | 85 | Personal-Sealed | Paralel refusal. |
| 87 | pow.piw.pow.eee | https://www.genspark.ai/api/files/s/xXGvm2Zr | Personal | P1 | Personal | OSINT Hard Refusal | 85 | Personal-Sealed | Paralel refusal 2. |
| 88 | proof.of.wrk.nrull | https://www.genspark.ai/api/files/s/G6ywSQEX | Personal | P1 | Personal | Personal Doctrine | 02 | Personal-Sealed | PoW narrative private. |
| 89 | aness.ee | https://www.genspark.ai/api/files/s/pQAENkl0 | Personal | P2 | Personal | Personal Doctrine | 88 | Personal-Sealed | Internal name doc. |
| 90 | mharr | https://www.genspark.ai/api/files/s/eduufeN0 | Personal | P2 | Personal | Personal Doctrine | 88 | Personal-Sealed | Internal name doc. |
| 91 | paw.oow.pow.nrul.eee | https://www.genspark.ai/api/files/s/vDMxSJn8 | Personal | P1 | Personal | Personal Doctrine | 88 | Personal-Sealed | PoW Nurul variant. |
| 92 | eee.ee.ee.tloll | https://www.genspark.ai/api/files/s/Aucneg7O | Personal | P2 | Personal | Personal Doctrine | 88 | Personal-Sealed | Internal note. |
| 93 | ee.q.q.qe | https://www.genspark.ai/api/files/s/umVWpJfc | Personal | P3 | Personal | Personal Doctrine | 88 | Personal-Sealed | Internal note. |
| 94 | ee.1.q.qee.1.w.1 | https://www.genspark.ai/api/files/s/oQUlACHr | Personal | P3 | Personal | Personal Doctrine | 88 | Personal-Sealed | Internal note. |
| 95 | ee.1mq.qee | https://www.genspark.ai/api/files/s/SnRufCs0 | Personal | P3 | Personal | Personal Doctrine | 88 | Personal-Sealed | Internal note. |
| 96 | ee.1.q.qee.q.qeeq | https://www.genspark.ai/api/files/s/1j2loy5T | Personal | P3 | Personal | Personal Doctrine | 88 | Personal-Sealed | Internal note. |
| 97 | ee.q.q.qee.q.qee | https://www.genspark.ai/api/files/s/MNjhD16k | Personal | P3 | Personal | Personal Doctrine | 88 | Personal-Sealed | Internal note. |
| 98 | ee.q.q.qee.q.q.qee | https://www.genspark.ai/api/files/s/mZRQMHMN | Personal | P3 | Personal | Personal Doctrine | 88 | Personal-Sealed | Internal note. |
| 99 | svereign.vow | https://www.genspark.ai/api/files/s/A4o6wu8T | Personal | P0 | Mother | Personal Doctrine | 01 | Canonical Locked | Vow text — §12 source. |
| 100 | accptnce.sgnal | https://www.genspark.ai/api/files/s/4oj2BkjS | Personal | P0 | Mother | Personal Doctrine | 99 | Canonical Locked | Acceptance signal — §09.3. |
| 101 | slamat.your.my.the best candidate | https://www.genspark.ai/api/files/s/MoqreuH2 | Personal | P1 | Personal | Personal Doctrine | 99 | Personal-Sealed | Personal narrative. |
| 102 | byungg | https://www.genspark.ai/api/files/s/DlSV4cQK | Personal | P2 | Personal | Personal Doctrine | 88 | Personal-Sealed | Internal note. |
| 103 | dcode.nrull | https://www.genspark.ai/api/files/s/oNZYLID5 | Personal | P1 | Personal | Personal Doctrine | 88 | Personal-Sealed | Decode private. |
| 104 | tmenninn.nurul | https://www.genspark.ai/api/files/s/fIZXw7o3 | Personal | P1 | Personal | Personal Doctrine | 88 | Personal-Sealed | Internal note. |
| 105 | nrull.ee | https://www.genspark.ai/api/files/s/mFpZPnVK | Personal | P1 | Personal | Personal Doctrine | 88 | Personal-Sealed | Internal note. |
| 106 | clarrittyy.q.q..q.qq.qnrul | https://www.genspark.ai/api/files/s/LoJLehWc | Personal | P1 | Personal | Personal Doctrine | 88 | Personal-Sealed | Clarrittyy + Nurul angle. |
| 107 | heddarr.gillaaa | https://www.genspark.ai/api/files/s/RdoLImtD | Reference | P3 | Mother | Reference | — | Legacy Reference | Logo/branding draft. |
| 108 | heddarr eeee | https://www.genspark.ai/api/files/s/DVUmZZqY | Reference | P3 | Mother | Reference | 107 | Legacy Reference | Logo/branding draft 2. |
| 109 | ee.image | https://www.genspark.ai/api/files/s/l9wHGvoV | Reference | P3 | Mother | Reference | — | Legacy Reference | Image draft. |
| 110 | sparkmind.logo | https://www.genspark.ai/api/files/s/eBBbuR2e | Reference | P1 | Mother | Reference | — | Canonical Locked | Brand asset. |

## 3. Mermaid Dependency Graph (full)

```mermaid
graph TD
  %% Doctrine spine
  A[01 DOC-A mssi.hdupp] --> B[02 doc.A.doc.B]
  B --> B2[03 clarrittyy]
  A --> D[04 DOC-D Engineering]
  D --> M[05/06/07 DOC-M Monorepo]

  %% Brand sub-doctrines
  D --> R8[08/09 DOC-R Running]
  D --> S10[10/44/45 DOC-S Nurani]
  M --> BK[49 barberkas-bundle]

  %% Execution doctrines
  D --> X11[11/12/13 DOC-X Execution Reality]
  X11 --> Y14[14/15/16 DOC-Y Parallel Sprint]
  Y14 --> Z17[17/18/19 DOC-Z Cross-Brand]
  Z17 --> AUD21[21/22 DOC-AUDIT v2.0]
  Z17 --> PG23[23/24/25 DUAL-PG Strategy]
  PG23 --> DUITKU[47/71/72 Duitku family]
  PG23 --> XEND[73/74 Xendit family]

  %% Tools
  D --> ARCH26[26/27/28 Architect Prompts]

  %% Audit & hardening
  AUD21 --> HARD32[32/37/38/77 Hardening rounds]

  %% Personal sealed
  B --> NUR81[81–98 Personal-Sealed]
  A --> VOW99[99/100 Sovereign Vow + Signal]

  %% Brand bundles
  BK --> BK_DR[58 BK Deep Research]
  R8 --> PL_DR[09/35/36 PL Deep Research]
  S10 --> NO_DR[10/44/45 NO Deep Research]

  %% Final
  AUD21 --> HND[★ AI Dev Handoff v1.0]
  PG23 --> HND
  Y14 --> HND
  Z17 --> HND
  D --> HND
  B --> HND
  VOW99 --> HND
  NUR81 -.honor privacy.-> HND
```

## 4. Cara baca tabel sebagai AI Dev

1. **Sesi pertama hari ini?** Baca dulu **#04 DOC-D**, **#01 DOC-A**, **#11/14/17 DOC-X/Y/Z**, lalu **#21 DOC-AUDIT v2.0**.
2. **Mau eksekusi Lane A (BarberKas) hari ini?** Baca **#49 bundle** + **#53 multi-tenant blueprint** + **#52 first revenue playbook**.
3. **Mau eksekusi Lane B (PaceLokal)?** Baca **#08 DOC-R bundle** + **#09 hardening DR**.
4. **Mau eksekusi Lane C (Nurani.OS)?** Baca **#10 DOC-S bundle** + **#44/45 nurani single + DR**.
5. **Mau audit kesehatan sprint?** Baca **#21/22 DOC-AUDIT**.
6. **Mau integrate payment?** Baca **#23/24/25 DUAL-PG**, lalu **#47 Duitku sandbox** + **#71/72 Duitku verifikasi/audit**, lalu **#73/74 Xendit**.
7. **Confused? Lost direction?** Baca **#11 DOC-X Execution Reality** — itu obat-cuci-otak yang paling cepat.
8. **Personal-Sealed (#81–98, #101–106)** — **JANGAN** dipakai untuk OSINT, scraping, profiling. Itu privat. Honor.

## 5. Stats (per 2026-05-18)

- Total file di indeks: **110 entri** (semua URL canonical, beberapa duplikat slug intentional sebagai variant)
- Doctrine canonical locked: **28 file** (P0)
- Active draft P1: **~40 file**
- Legacy/historical P2–P3: **~25 file**
- Personal-Sealed: **17 file** (handled per privacy doctrine)
- Brand split: Mother 12 · BK 10 · PL 5 · NO 5 · Cross 45+ · Personal 25+

---

*DOC-INDEX-CANONICAL v1.0 — single source of truth file inventory.*
*Update via commit ke `doctrine/DOC-INDEX-vX.Y.md`. Cross-ref dari handoff §08.*
