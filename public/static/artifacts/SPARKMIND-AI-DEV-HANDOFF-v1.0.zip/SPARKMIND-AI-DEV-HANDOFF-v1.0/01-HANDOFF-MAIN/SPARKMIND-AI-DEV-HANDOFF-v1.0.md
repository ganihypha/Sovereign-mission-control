# SPARKMIND AI DEV HANDOFF — CANONICAL BUNDLE v1.0

> **Sovereign Mode ON. Day 2 of 60. Execute-Ready.**
> Owner: Reza Estes / Haidar — Sovereign AI Dev
> Mother brand: [SparkMind](https://www.sparkmind.web.id/) · Repo: `github.com/ganihypha/Sparkmind-Sovereign`
> Tanggal handoff: **2026-05-18** · Versi: **v1.0 (Canonical Locked)**
> Bahasa: **Bahasa Indonesia (Sovereign Voice)** · Print-ready A4 · Dark theme HTML companion tersedia.

---

## §00 — Sovereign TL;DR (Executive Handoff Brief)

Dokumen ini adalah **single source of truth** untuk handoff penuh ekosistem SparkMind Sovereign ke AI Dev (atau ke diri sendiri di sesi besok). Bila kamu cuma punya 5 menit, baca section ini saja — sisanya untuk eksekusi mendalam.

**State per 2026-05-18 (Day 2/60):**

| Metric | Nilai | Status |
|---|---|---|
| Composite Sovereign Health Score | **33/100** | 🔴 RED |
| Target di D60 (2026-07-16) | **78/100** | 🟢 GREEN |
| Sub-brand aktif | 3 (BarberKas · PaceLokal · Nurani.OS) | Dual-loaded |
| Stack canonical | 100% Cloudflare-native (Workers · D1 · R2 · KV · Queues · Pages · Analytics Engine) | Locked |
| Repo monorepo | `github.com/ganihypha/Sparkmind-Sovereign` | Init Day 1 |
| Doctrine documents locked | 15 (DOC-A → DOC-Z, MASTER-INDEX v4.0) | Canonical |
| File inventory | 80+ files terindeks di DOC-INDEX v1.0 | Tracked |

**3 sub-brand — lane assignment & dominant window:**

1. **BarberKas** — `barberkas.sparkmind.web.id` — Cloudflare-native multi-tenant SaaS untuk barbershop/salon Indonesia. **Lane A dominant D0–D30**. Beachhead: first paying tenant via Duitku VA. Workers + D1 multi-tenant (shared schema, `tenant_id` column) — pola yang sudah direkomendasikan vendor itu sendiri ([Architecting on Cloudflare Ch. 23](https://architectingoncloudflare.com/chapter-23)).
2. **PaceLokal** — `pacelokal.sparkmind.web.id` — Hyperlocal running OS Banyumas Raya. **Lane B dominant D15–D45**. Beachhead: integrasi Verify-Stub Strava untuk runner Purwokerto, sambung ke ekosistem [Banyumas Runners (Strava club)](https://www.strava.com/clubs/BRBMS) dan event lokal seperti Purwokerto Half Marathon yang sudah memverifikasi via akun Strava saat Race Pack Collection ([Purwokerto HM 2026 - Instagram](https://www.instagram.com/p/DYUXZO_Cf1c/)).
3. **Nurani.OS** — `nurani.sparkmind.web.id` — Tadarus-first spiritual OS, dual-acceptance NU + Muhammadiyah. **Lane C dominant D30–D60**. Beachhead: rilis pre-Ramadhan 1448H. **Anchor date: 8 Februari 2027** — tanggal yang sudah dijadwalkan sebagai 1 Ramadhan 1448 H baik versi PP Muhammadiyah maupun kemungkinan besar pemerintah / NU ([Abu Sabda Falakiy - prediksi 1 Ramadhan 1448 H](https://www.facebook.com/abu.sabda.el.falakiy/posts/2668500433528017/), [Kalender Islam 1448](https://www.islamicfinder.org/islamic-calendar/1448/Ramadan/?type=Hijri&language=id)). Artinya: window pre-launch Nurani.OS = **Mei 2026 → Februari 2027**.

**Top 5 RED gaps (harus closed before D60):**

| # | Gap | Severity | Lane | ETA Hard-close |
|---|---|---|---|---|
| 1 | Subdomain wildcard belum di-init di Cloudflare untuk `*.sparkmind.web.id` | 🔴🔴 | Cross-brand | D2–D3 |
| 2 | D1 schema 3-brand belum di-migrate (tenants, runs, tadarus_sessions) | 🔴🔴 | Cross-brand | D3–D5 |
| 3 | Dual-PG (Duitku primary + Xendit fallback) belum integrated di Workers | 🔴 | Cross-brand | D5–D10 |
| 4 | PaceLokal Verify-Stub (Strava OAuth + activity import) belum coded | 🔴 | Lane B | D10–D20 |
| 5 | Nurani.OS Tadarus engine (audio R2 + KV session state) belum scaffolded | 🔴 | Lane C | D25–D40 |

**Top 5 GREEN wins (sudah locked, lindungi jangan regresi):**

1. Doctrine stack lengkap — DOC-A (Misi Hidup), DOC-B (Nurul Protocol), DOC-C (Probability Matrix), DOC-D (Engineering Discipline), DOC-M/R/S/X/Y/Z + DOC-AUDIT v2.0 — semua **canonical locked**.
2. Stack decision: 100% Cloudflare-native. Tidak ada vendor lock-in eksternal selain edge runtime resmi Cloudflare ([Workers pricing](https://developers.cloudflare.com/workers/platform/pricing/), [D1 best practices](https://developers.cloudflare.com/d1/best-practices/)).
3. Repo monorepo sudah di-init Day 1 (struktur `apps/* + packages/shared` siap di-populate).
4. Dual-PG strategy doctrine sudah finished — [DUAL-PG-STRATEGY-v1.0.html](https://www.genspark.ai/api/files/s/2xeoltR0) sudah jadi blueprint.
5. Sovereign Voice + halal-by-default + dual-acceptance NU/Muhammadiyah sudah masuk DOC-S — tidak perlu re-debate di execution.

**AI Dev pickup point — besok pagi (D3, 2026-05-19) buka section §10 lalu §05 berurutan.** Kalau cuma punya 1 jam: kerjakan checklist `#1–#5` di §10 (init wrangler + subdomain + commit pertama).

---

## §01 — Sovereign Ecosystem Architecture

Ekosistem SparkMind dibangun dengan satu prinsip yang non-negotiable: **satu mother brand, tiga sub-brand sovereign, satu shared infrastructure layer, zero vendor lock-in di luar Cloudflare**. Ini bukan keputusan ideologis — ini keputusan engineering yang dihitung berdasarkan biaya, kontrol, dan kecepatan iterasi. Cloudflare Workers paid plan mulai dari **$5/bulan dengan 10 juta request, 5 GB storage, dan akses ke fitur advanced** ([Cloudflare Workers Pricing](https://developers.cloudflare.com/workers/platform/pricing/), [Cloudflare Plans](https://www.cloudflare.com/plans/)), dan R2 menawarkan **$0.015/GB-month dengan zero egress fee** — pola pricing yang membunuh argumen vendor S3-style ([Cloudflare R2 Pricing](https://developers.cloudflare.com/r2/pricing/), [LeanOps R2 analysis](https://leanopstech.com/blog/cloudflare-r2-pricing-2026/)).

### 01.1 Visual ekosistem (high-level)

```
                  ┌────────────────────────────────────────┐
                  │  MOTHER: SparkMind                     │
                  │  sparkmind.web.id (Pages + Worker)     │
                  │  Brand HQ · Landing · Doctrine portal  │
                  └──────────────────┬─────────────────────┘
                                     │
            ┌────────────────────────┼────────────────────────┐
            │                        │                        │
   ┌────────▼─────────┐    ┌─────────▼─────────┐    ┌─────────▼──────────┐
   │ BarberKas        │    │ PaceLokal         │    │ Nurani.OS          │
   │ barberkas.*      │    │ pacelokal.*       │    │ nurani.*           │
   │ Multi-tenant     │    │ Hyperlocal run OS │    │ Tadarus-first OS   │
   │ SaaS (Lane A)    │    │ Banyumas (Lane B) │    │ Spiritual (Lane C) │
   └────────┬─────────┘    └─────────┬─────────┘    └─────────┬──────────┘
            │                        │                        │
            └────────────────────────┼────────────────────────┘
                                     │
                ┌────────────────────▼─────────────────────┐
                │ SHARED INFRASTRUCTURE (packages/shared)  │
                │ ─ Auth (Workers + KV session)            │
                │ ─ Billing (Duitku primary / Xendit FB)   │
                │ ─ Observability (Analytics Engine + D1)  │
                │ ─ Notifications (Queues + Email Workers) │
                │ ─ Halal-compliance & RBAC                │
                └──────────────────────────────────────────┘
```

### 01.2 Monorepo layout — final canonical

Mengacu pada **DOC-M Monorepo Consolidation v1.0** (lihat [DOC-M bundle](https://www.genspark.ai/api/files/s/AO5fkBi8) dan [doc.m.mnoreppoo](https://www.genspark.ai/api/files/s/6GKPCaUk)), struktur monorepo final adalah:

```
Sparkmind-Sovereign/
├── apps/
│   ├── sparkmind/          # Mother brand site (Pages)
│   ├── barberkas/          # Worker + D1 (multi-tenant)
│   ├── pacelokal/          # Worker + D1 + R2 (GPX/audio)
│   └── nurani/             # Worker + D1 + R2 (Quran audio)
├── packages/
│   ├── shared-auth/        # Cookie/JWT, KV session, RBAC
│   ├── shared-pg/          # Dual-PG abstraction (Duitku, Xendit)
│   ├── shared-ui/          # Tailwind tokens, Inter+JetBrains Mono
│   ├── shared-db/          # D1 schemas, migrations, types
│   ├── shared-obs/         # Analytics Engine wrappers, logger
│   └── shared-halal/       # Compliance utilities, content filters
├── infra/
│   ├── wrangler/           # All wrangler.toml configs
│   ├── d1-migrations/      # SQL migrations per app
│   └── scripts/            # init.sh, streak-check.sh, new-entry.sh
├── doctrine/
│   ├── DOC-A.md            # Misi Hidup
│   ├── DOC-B.md            # Nurul Reconnect Protocol
│   ├── DOC-C.md            # Probability Matrix
│   ├── DOC-D.md            # Engineering Discipline
│   ├── DOC-M/R/S/X/Y/Z.md  # Lane doctrines
│   └── DOC-AUDIT-v2.md     # Health score
├── proof-of-work/
│   └── 2026-05.md          # Daily ledger
├── package.json            # pnpm workspaces
├── pnpm-workspace.yaml
└── README.md
```

Pemilihan **pnpm workspaces** dibanding npm/yarn alasannya pragmatis: pnpm secara native menangani symlink antar package tanpa duplikasi `node_modules`, dan Cloudflare Workers build pipeline kompatibel out-of-the-box. Kalau di sesi besok ternyata Workers CLI (`wrangler`) ada friction dengan pnpm, **fallback adalah npm workspaces** — keputusan ini sudah masuk LANE-D fallback playbook (lihat §11).

### 01.3 Dependency graph antar brand

Tidak ada brand yang depends-on brand lain di runtime — **isolation ketat di route layer**. Tapi semua 3 brand depends pada `packages/shared-*`. Aliran kira-kira:

```
sparkmind (landing) ──┐
                      ├──► shared-auth ──► shared-db (D1) ──► Cloudflare D1
barberkas ────────────┤
                      ├──► shared-pg ───► Duitku API / Xendit API
pacelokal ────────────┤                                            │
                      ├──► shared-obs ──► Analytics Engine        │
nurani.os ────────────┘                                            │
                                                  (webhook)        │
                                                       └─► Queues ─┘
```

Pola "shared-package, isolated app-runtime" adalah pola yang direkomendasikan untuk Cloudflare-native monorepo SaaS ([Medium: Multi-Tenant SaaS on Cloudflare Workers](https://medium.com/@docat0209/how-to-build-a-multi-tenant-saas-on-cloudflare-workers-for-0-month-2026-8a0539c92a26)).

### 01.4 Cross-brand integration points

Ada **4 cross-brand contract points** yang harus locked di shared-packages dan di-test sebagai unit terpisah (detail di §06):

1. **Auth contract** — semua brand pakai cookie format `__Host-spkmd_session=<jwt>` dengan KV session lookup, sehingga single sign-on antar subdomain mungkin di masa depan tanpa migration besar. Catatan: Cloudflare **Custom Domains tidak support wildcard DNS** untuk Workers — wildcard hanya bisa via **HTTP Routes** ([Cloudflare docs: Custom Domains](https://developers.cloudflare.com/workers/configuration/routing/custom-domains/), [Community: wildcard workers](https://community.cloudflare.com/t/how-to-add-a-wildcard-domain-to-a-worker/525974)). Ini berarti subdomain `*.sparkmind.web.id` harus pakai HTTP Routes + wildcard DNS record (CNAME ke `sparkmind.web.id`) — bukan Custom Domain.
2. **Billing contract** — `chargeOnce({ amount, brand, tenant_id })` returning `{ pgRef, redirectUrl }` — implementasi internal melempar ke Duitku, fallback ke Xendit kalau status != ok dalam 8 detik.
3. **Observability contract** — `track({ event, brand, props })` melempar ke Workers Analytics Engine. Catatan penting: Analytics Engine **belum di-bill** per 2026-Q2 ("you will not be billed for your use of Workers Analytics Engine") — ini window biaya nol yang harus dipakai sekarang sebelum Cloudflare aktifkan billing ([Cloudflare AE pricing](https://developers.cloudflare.com/analytics/analytics-engine/pricing/)).
4. **Notification contract** — `notify({ channel: 'email'|'whatsapp', to, template, props })` — masuk Queues, consumer Worker yang panggil provider. Queues pricing: pay-per-operation, free tier cukup besar untuk MVP ([Queues pricing](https://developers.cloudflare.com/queues/platform/pricing/)).

### 01.5 Mengapa Hono, mengapa bukan framework lain

Setiap Worker di SparkMind menggunakan **Hono** sebagai HTTP router. Alasannya:

- **Ultra-fast, lightweight, Web Standards** — Hono bisa jalan di Workers, Bun, Deno, Node, Lambda — yaitu code mobility kalau suatu hari ada brand harus pindah runtime ([Hono docs](https://hono.dev/docs/), [GitHub honojs/hono](https://github.com/honojs/hono)).
- **First-class Cloudflare Workers support** — Cloudflare sendiri mendokumentasikan Hono sebagai recommended framework ([Cloudflare framework guide: Hono](https://developers.cloudflare.com/workers/framework-guides/web-apps/more-web-frameworks/hono/)).
- **Typed routing + typed middleware** end-to-end TypeScript, tanpa Express-style any-type chaos ([Hono.js typed APIs at the edge](https://dev.to/whoffagents/honojs-on-cloudflare-workers-typed-apis-that-actually-run-at-the-edge-3930)).

Tidak ada Express, tidak ada Fastify, tidak ada Next.js untuk API layer. Frontend SparkMind landing + brand landing pakai Pages (static + minimal Worker functions); aplikasi SaaS pakai Workers + Hono + HTML server-rendered (HTMX-style untuk MVP, react/svelte hanya di tahap scale-up post-D60).

---

## §02 — Sub-brand Deep Dive

### 02.1 BarberKas — Multi-tenant SaaS untuk Indonesia (Lane A · D0–D30 dominant)

**Mission:** Memberi setiap barbershop dan salon UMKM di Indonesia satu sistem operasi yang menggantikan "buku catatan + WhatsApp + dompet kresek" — booking, kas harian, pelanggan, laporan, dan pembayaran terintegrasi. Targetnya bukan pemain enterprise — targetnya adalah **65 juta pelaku UMKM di Indonesia, yang menyumbang 61% terhadap PDB**, sebagaimana dilaporkan oleh Akurat dari konteks digitalisasi pembayaran UMKM barbershop ([Akurat - digitalisasi pembayaran barbershop](https://www.akurat.co/umkm/797769/digitalisasi-pembayaran-pengusaha-barbershop-ini-kian-cuan)). Tren digitalisasi salon di Indonesia dilaporkan secara terbuka oleh Detik Finance, menyoroti pergeseran "dari buku catatan ke platform terintegrasi" — dan **digitalisasi pembayaran sering jadi pintu masuk** ke digitalisasi operasi yang lebih luas ([Detik - Tren Digitalisasi UMKM Salon RI](https://finance.detik.com/berita-ekonomi-bisnis/d-8480055/tren-digitalisasi-umkm-salon-ri-dari-buku-catatan-ke-platform-terintegrasi)).

**Beachhead (D0–D30):** Mendapatkan **1 paying tenant via Duitku VA** sebagai proof-of-revenue. Bukan 10, bukan 100 — satu. Karena 1 paying tenant memvalidasi seluruh stack: signup → onboarding → billing → use case → retention.

**Persona primary:**
- *Bang Adi* — pemilik barbershop 2 kursi di Purwokerto Timur, omzet Rp 200rb–500rb/hari, butuh tahu kapan pelanggan datang (booking) dan berapa kas masuk hari ini (closing harian). Tidak butuh fitur SAP-class.

**Tech stack:**

| Komponen | Implementasi |
|---|---|
| Runtime | Cloudflare Workers + Hono |
| Database | D1 (shared schema, `tenant_id` column) |
| Storage | R2 (foto barber, dokumen) |
| Cache/session | KV (session, throttle, OTP) |
| Background jobs | Queues (kirim WA reminder, daily closing) |
| Frontend | Hono JSX (server-rendered) + HTMX untuk interaktif |
| Payment | Duitku (primary) + Xendit (fallback) |
| Domain | `barberkas.sparkmind.web.id` (HTTP Route, bukan Custom Domain karena multi-tenant subpath) |

**Multi-tenant model:** Mengikuti pola dari [Architecting on Cloudflare Chapter 23](https://architectingoncloudflare.com/chapter-23) — "all tenant data lives in shared D1 tables with a tenant identifier column; Durable Objects use tenant-prefixed names. Sufficient for most SaaS workloads." Implementasi konkret:

```typescript
// shared-db/src/multitenant.ts
export async function withTenant<T>(
  db: D1Database, tenantId: string,
  fn: (qb: TenantQueryBuilder) => Promise<T>
): Promise<T> {
  // Semua query auto-inject WHERE tenant_id = ? + audit log
  return fn(new TenantQueryBuilder(db, tenantId));
}
```

Tenant identification: dari subdomain pertama setelah `barberkas.` — yaitu `<slug>.barberkas.sparkmind.web.id` → tenant slug. Atau di MVP awal cukup path-based: `barberkas.sparkmind.web.id/t/<slug>/*`. Pilih path-based untuk D0–D15 untuk hindari kompleksitas wildcard DNS, lalu migrate ke subdomain-based di D30+ kalau perlu ([Cloudflare community on wildcard subdomain pages 2026](https://community.cloudflare.com/t/wildcard-subdomains-for-pages-in-2026/908010)).

**MVP feature list (D0–D30 acceptance criteria):**

1. **Tenant signup + onboarding** — `POST /signup` → buat tenant, set 7-hari trial gratis, kirim email konfirmasi via Queue. Acceptance: 1 tenant test bisa daftar tanpa intervensi manual.
2. **Booking CRUD** — `GET/POST /api/bookings`, dengan slot ½ jam, validasi tabrakan, status (booked/done/cancel). Acceptance: 10 booking concurrent tanpa konflik di D1 transaction test.
3. **Kas harian** — `POST /api/transactions` jenis (revenue, expense), auto-aggregate ke daily summary table. Acceptance: closing harian otomatis di-trigger 23:55 WIB via Cron Trigger.
4. **Pelanggan/CRM ringan** — `GET/POST /api/customers`, dedup by nomor WA. Acceptance: 200 pelanggan import dari CSV tanpa duplikat.
5. **Billing Duitku VA** — `POST /api/billing/charge` → Duitku createInvoice → redirect → callback handler. Acceptance: 1 transaksi sandbox sukses end-to-end ([Duitku API docs](https://docs.duitku.com/api/en/), [Duitku Payment Gateway docs](https://docs.duitku.com/en/payment-gateway/overview/)).

**D0–D30 milestone breakdown:**

- **D2–D5:** Init Worker, Hono, D1 schema migrasi v1 (tenants, bookings, transactions, customers).
- **D6–D10:** Auth (cookie + KV session) + tenant scoping middleware + integration test dasar.
- **D11–D15:** Booking UI (Hono JSX + HTMX), kas UI, customer UI — MVP path-based multi-tenant.
- **D16–D20:** Integrasi Duitku (createInvoice + signature HMAC + callback verify) + sandbox test.
- **D21–D25:** Onboarding flow, email/WA notifikasi via Queues, error handling.
- **D26–D30:** First paying tenant outreach (Purwokerto, Banyumas), bug-fixing, observability finalization.

**Referensi doctrine internal:**
- [barberkas-bundle](https://www.genspark.ai/api/files/s/dbb78hVm)
- [barberkas.clarrittyy](https://www.genspark.ai/api/files/s/W2AjzMGX)
- [barber.kass.docc.creattedd.id](https://www.genspark.ai/api/files/s/SqtjaJRP)
- [brberkas.frst.rvenue](https://www.genspark.ai/api/files/s/2qYJXr5c)
- [brber.lass.mlti.tnant](https://www.genspark.ai/api/files/s/IRPTjC3F)
- [sb.dmain.brberkas](https://www.genspark.ai/api/files/s/81Pz8wKB)
- [scraperr.brberrkass](https://www.genspark.ai/api/files/s/C1MtxvCo)
- [barberkass.intgrteddd](https://www.genspark.ai/api/files/s/frUhJzM3)

---

### 02.2 PaceLokal — Hyperlocal Running OS Banyumas Raya (Lane B · D15–D45 dominant)

**Mission:** Jadi sistem operasi hyperlocal untuk komunitas lari di Banyumas Raya (Purwokerto, Purbalingga, Banjarnegara, Cilacap) — bukan kompetitor Strava global, tetapi **layer lokal yang men-sinergikan Strava data + event lokal + komunitas lokal + leaderboard rute lokal**. Strava sudah jadi infrastruktur lari de-facto di Indonesia — di 2023 saja Strava adalah aplikasi health & fitness dengan revenue tertinggi di Indonesia ([Statista - Indonesia highest grossing health & fitness apps 2023](https://www.statista.com/statistics/1489406/indonesia-highest-grossing-health-and-fitness-apps/)). Dan secara global, market running apps diproyeksikan **dari USD 550 juta (2021) ke USD 1,438.6 juta (2028)** ([Kalbis Socio - Factors Affecting Runners' Continuance on Strava](https://ojs.kalbis.ac.id/index.php/kalbisocio/en/article/download/4574/1161/14635)).

Permintaan untuk produk hyperlocal sangat tampak di Banyumas. [Banyumas Runners](https://www.strava.com/clubs/BRBMS) adalah klub Strava aktif. Event Purwokerto Half Marathon 2026 sudah memverifikasi peserta via akun Strava saat Race Pack Collection ([Purwokerto HM 2026](https://www.instagram.com/p/DYUXZO_Cf1c/)), diikuti **6.000 runners** ([Instagram reel - 6000 runners purwokertohm 2026](https://www.instagram.com/reel/DYbbbV1J2GY/)). Ada FNR (Friday Night Run) tiap Jumat 19.00 di Alun-alun Purwokerto, dan Sunday Morning Run tiap Minggu 06.00 ([Facebook - Banyumas Runners](https://www.facebook.com/BanyumasRunners/)). Ada juga komunitas-komunitas micro seperti #runergybanyumas ([Instagram - Eko Soekristiono](https://www.instagram.com/p/CdHrL1VJh5u/)) yang aktif posting kegiatan harian.

**Beachhead (D15–D45):** **Verify-Stub Strava** — runner Banyumas connect Strava OAuth → activity terimport → masuk leaderboard rute lokal (e.g., loop Alun-alun, Baturraden uphill, GOR Satria). Target 50 runner aktif di D45.

**Persona primary:**
- *Mas Wahyu* — runner 32 tahun, weekly mileage 30–50 km, ikut Banyumas Runners, sudah pakai Strava 4 tahun. Mau lihat "siapa tercepat di Loop GOR Satria minggu ini" tanpa scrolling 200 entri Strava global.

**Tech stack:**

| Komponen | Implementasi |
|---|---|
| Runtime | Cloudflare Workers + Hono |
| Database | D1 (single-tenant — semua user di 1 schema) |
| Storage | R2 (GPX backup, foto course) |
| Cache | KV (leaderboard 1-hour TTL, OAuth state) |
| Background | Queues (Strava activity import, weekly digest) |
| OAuth | Strava OAuth 2.0 |
| Geo | Cloudflare native KV + simple grid index untuk rute matching |

**Subdomain & routing:** `pacelokal.sparkmind.web.id` — HTTP Route. Single tenant, jadi tidak perlu wildcard. Course/rute identification via route ID di path: `/rutes/<route_id>/leaderboard`.

**MVP feature list (D15–D45 acceptance criteria):**

1. **Strava OAuth Connect** — `/auth/strava` → consent → callback. Acceptance: 1 user dummy bisa connect & disconnect.
2. **Activity import** — Webhook subscription Strava ke `/webhook/strava` → enqueue ke Queues → consumer parse GPX → match ke rute lokal → insert leaderboard. Acceptance: 1 aktivitas dummy berhasil di-import < 30s.
3. **Rute lokal CRUD + GPX upload** — admin upload GPX rute, simpan ke R2, indexed. Acceptance: 5 rute Banyumas (Loop Alun, GOR Satria, Baturraden uphill, Karangwangkal, Universitas Soedirman) terisi di seed.
4. **Leaderboard mingguan** — `/rutes/<id>/leaderboard?period=week` agregasi dari D1, cache 1 jam. Acceptance: leaderboard ter-render < 500ms p95.
5. **Komunitas page** — `/komunitas/banyumas-runners` listing klub + member terbaru. Acceptance: minimal 1 klub seed.

**D15–D45 milestone:**

- **D15–D20:** Strava OAuth + activity webhook subscription + queue consumer skeleton.
- **D21–D28:** GPX parsing + rute matching algoritma (gunakan polyline simplify + grid hash sederhana, hindari PostGIS — tidak perlu di tahap ini).
- **D29–D35:** Leaderboard UI, periode (day/week/month/year), filter.
- **D36–D40:** Komunitas seed, FNR/SMR event listing manual.
- **D41–D45:** Soft-launch ke 50 runner Banyumas via WA + IG post di komunitas existing.

**Doctrine reference:**
- [DOC-R Sovereign Running Bundle](https://www.genspark.ai/api/files/s/gz1usZnI)
- [paceee.locall.mdd.hrdenn (DR-PaceLokal Hardening 9265 words)](https://www.genspark.ai/api/files/s/MFNZVljj)
- [pace.locall](https://www.genspark.ai/api/files/s/jWVkAhN2)
- [spereignn.runn](https://www.genspark.ai/api/files/s/MQDSvr9k)
- [svereignn.runn.ningg](https://www.genspark.ai/api/files/s/QPyt67K9)

---

### 02.3 Nurani.OS — Tadarus-first Spiritual OS (Lane C · D30–D60 dominant)

**Mission:** Membuat Tadarus (membaca Al-Qur'an bersama) jadi aktivitas digital pertama-kelas — bukan sekadar feature di app Quran, tetapi **OS spiritual ringan yang berjalan di Workers**. Lanskap aplikasi Quran/Tadarus Indonesia sudah ramai: [Quran: Tadarus Bersama (Google Play)](https://play.google.com/store/apps/details?id=com.tadarusquran.app&hl=en_ZA), [Tadarus.id (App Store)](https://apps.apple.com/us/app/tadarus-quran-adzan-doa/id6760353425), [Al Quran Digital Indonesia](https://play.google.com/store/apps/details?id=id.equran.android&hl=en_GB), dan referensi global [Quran.com](https://quran.com/id). Tapi belum ada yang **(a) dual-acceptance NU + Muhammadiyah eksplisit, (b) sovereign-engineered di edge (Workers/D1/R2), (c) optimized untuk komunitas Tadarus mikro 5–30 orang**. Inilah gap yang Nurani.OS isi.

**Beachhead (D30–D60):** **Pre-launch Ramadhan 1448H**. Anchor date: **8 Februari 2027** sebagai 1 Ramadhan 1448 H (prediksi yang sudah dipublikasikan oleh penulis falakiyah dan kalender Islam global), dengan kemungkinan istikmal Sya'ban 1448 H di 30 hari, dan **PP Muhammadiyah serta NU diperkirakan sepakat di tanggal yang sama** ([Abu Sabda Falakiy - prediksi 1 Ramadhan 1448 H](https://www.facebook.com/abu.sabda.el.falakiy/posts/2668500433528017/), [Kalender Islam 2027 al-habib.info](https://www.al-habib.info/kalender-islam/global/kalender-islam-global-tahun-2027-m.htm), [Instagram - perkiraan jadwal Ramadan 1448 H](https://www.instagram.com/p/DWX-iBnErPr/)). Ini memberi window **Mei 2026 → Februari 2027 = ~9 bulan** untuk build → soft launch → seed → polish → launch dini Ramadhan.

**Persona primary:**
- *Ustadzah Khadijah* — pengajar TPQ di Banyumas, ingin organisir Tadarus harian 30 jamaah ibu-ibu via WA group + audio rotation. Hari ini pakai voice note WA + scheduling manual; sering double atau miss giliran.

**Tech stack:**

| Komponen | Implementasi |
|---|---|
| Runtime | Cloudflare Workers + Hono |
| Database | D1 (tadarus_groups, tadarus_sessions, recitations) |
| Audio storage | R2 (audio Quran per ayat, audio recitation user) |
| Realtime | Durable Objects untuk live tadarus session state |
| Cache | KV (group rotation, daily target) |
| Background | Queues (reminder WA/email, daily summary) |
| Compliance | shared-halal package (NU/Muhammadiyah cross-reference, tafsir links) |

**Dual-acceptance NU + Muhammadiyah:** Setiap fitur yang menyentuh aspek fiqh harus di-cross-check dengan **referensi resmi dari NU + Muhammadiyah secara eksplisit** — bukan default ke satu mazhab. Contoh:
- Penentuan awal/akhir bulan Hijriah: ditampilkan **kedua versi** (rukyah/hisab) bersamaan, tanpa preferring.
- Audio recitation: support **murottal qira'at multi-rawi** (Hafsh dari 'Ashim sebagai default, tapi tidak menghilangkan rawi lain).
- Doa setelah Tadarus: pilihan tampil dari sumber NU (e.g., terbitan Lirboyo) atau Muhammadiyah (Suara Muhammadiyah) — user pilih.

**MVP feature list (D30–D60):**

1. **Group Tadarus** — buat grup, undang anggota via link, set target juz/hari. Acceptance: 1 grup test 30 orang.
2. **Rotation engine** — engine otomatis bagi giliran tadarus (e.g., 30 juz dibagi 30 hari atau dibagi per orang). Acceptance: rotation untuk 30 hari × 30 orang ter-generate < 500ms.
3. **Audio recitation upload** — user record/upload bacaan via R2 multipart upload. Acceptance: 5 MB audio upload < 10s di koneksi 4G.
4. **Live session via Durable Objects** — opsional, 5–10 orang real-time tadarus dengan presence + cursor (siapa baca ayat berapa). Acceptance: 5 orang concurrent < 200ms latency.
5. **Reminder + daily summary** — Queue cron → WA/email reminder. Acceptance: 30 user dummy menerima reminder pukul 04:30 dan ringkasan pukul 22:00.

**D30–D60 milestone:**

- **D30–D35:** Schema D1 + R2 bucket setup (audio nurani-quran-public, nurani-recitations-private).
- **D36–D42:** Group + rotation engine + invite link.
- **D43–D50:** Audio playback (Quran source: pakai recording public domain seperti Mishary Rashid Alafasy dari mirror legal, embed Quran.com player optional).
- **D51–D57:** Live Durable Objects session + presence.
- **D58–D60:** Soft launch ke 3 TPQ Banyumas, dokumentasi onboarding khusus pre-Ramadhan.

**Doctrine reference:**
- [DOC-S Sovereign Spiritual OS Bundle](https://www.genspark.ai/api/files/s/HKtLRWzy)
- [nurrannii.os](https://www.genspark.ai/api/files/s/e14V6GAQ)
- [nurani.os](https://www.genspark.ai/api/files/s/OuNSyMXK)

---

## §03 — Dual-PG Payment Strategy (Duitku + Xendit)

Strategi pembayaran SparkMind tidak pakai single-provider. Alasannya operasional, bukan ideologis: **Duitku murah dan kuat untuk VA Indonesia + e-wallet lokal, Xendit kuat untuk QRIS + cards + reliability + ekosistem developer global**. Dual-PG memberi:
1. **Fallback otomatis** kalau salah satu provider down.
2. **A/B economics** — pilih provider termurah per method per saat.
3. **Negotiation leverage** — kita tidak terlock satu vendor.

Sumber dokumentasi resmi:
- **Duitku:** [Duitku API Reference (EN)](https://docs.duitku.com/api/en/), [Duitku Getting Started](https://docs.duitku.com/en/), [Duitku Payment Gateway Overview](https://docs.duitku.com/en/payment-gateway/overview/), [Duitku POP integration](https://docs.duitku.com/pop/en/). Validasi pihak ketiga: [HostBill Docs - Duitku](https://hostbill.atlassian.net/wiki/spaces/DOCS/pages/2372829207/Duitku), [HostBill Blog - Duitku & Tripay](https://blog.hostbillapp.com/2021/05/24/new-payment-gateways-duitku-and-tripay/), [Upmind - Indonesia gateways](https://features.upmind.com/p/adding-payment-gateway-support-in-indonesia).
- **Xendit:** [Xendit Quick Setup](https://docs.xendit.co/apidocs/quick-setup), [Handling webhooks](https://docs.xendit.co/docs/handling-webhooks), [Payments API webhooks](https://docs.xendit.co/docs/payments-api-webhooks), [Set webhook URL](https://docs.xendit.co/apidocs/set-webhook-url), [Payment Status Callback Webhook](https://docs.xendit.co/apidocs/payment-status-callback-webhook), [Xendit Payment Gateway Integration (OVO/DANA/LinkAja)](https://www.xendit.co/en-id/products/integration/), [PortOne Xendit docs](https://docs.portone.cloud/docs/xendit).

### 03.1 Migration playbook (dari "tidak ada PG" ke dual-PG)

Phase migrate per [DUAL-PG-STRATEGY v1.0 (HTML)](https://www.genspark.ai/api/files/s/2xeoltR0), [duall.pgg](https://www.genspark.ai/api/files/s/PnEkyOgh), [DUAL-PG-STRATEGY ZIP](https://www.genspark.ai/api/files/s/ks8ufa3n), [mgratedd.xendittt](https://www.genspark.ai/api/files/s/6Gnqyfam), [lgall.xendittt](https://www.genspark.ai/api/files/s/aXbYQg6v), [sndboxx.duitkuu](https://www.genspark.ai/api/files/s/fml3hNrF), [tim.duitku.vrif](https://www.genspark.ai/api/files/s/Pj5b3Mtc), [auditt.duitkuu](https://www.genspark.ai/api/files/s/AZcbn5ks):

1. **Phase 0 (D5–D7) — Duitku sandbox.** Daftar akun, set sandbox merchant code, test createInvoice sederhana via cURL.
2. **Phase 1 (D8–D10) — Duitku live + signature verify.** Implement HMAC-SHA256 di Worker, callback validation, idempotency key di D1.
3. **Phase 2 (D11–D14) — Xendit sandbox + fallback layer.** Implement `shared-pg.chargeOnce` dengan circuit breaker.
4. **Phase 3 (D15+) — Production live untuk BarberKas first paying tenant.**
5. **Phase 4 (D30+) — Extend ke PaceLokal premium (mileage badge) + Nurani.OS donasi/infaq.**

### 03.2 Decision matrix (method × provider)

| Payment Method | Primary | Fallback | Catatan |
|---|---|---|---|
| Bank Transfer VA (BCA, Mandiri, BNI, BRI) | Duitku | Xendit | Duitku biasanya margin lebih bagus di VA |
| QRIS dynamic | Xendit | Duitku | Xendit QRIS API mature |
| OVO / DANA / LinkAja | Xendit | Duitku | Xendit official e-wallet integration ([Xendit ewallet](https://www.xendit.co/en-id/products/integration/)) |
| Credit / Debit Card | Xendit | — | Single provider untuk card 3DS |
| ShopeePay / GoPay | Duitku | Xendit | Dual support |
| Retail (Alfamart/Indomaret) | Duitku | Xendit | Duitku reliable di retail |

### 03.3 Implementasi shared-pg abstraction

```typescript
// packages/shared-pg/src/index.ts
export interface ChargeRequest {
  amount: number; currency: 'IDR';
  method: 'VA_BCA' | 'VA_MANDIRI' | 'QRIS' | 'OVO' | 'CARD' | ...;
  brand: 'barberkas' | 'pacelokal' | 'nurani';
  tenant_id?: string;
  reference: string; // unique idempotency key
  payer: { name: string; email: string; phone?: string };
  expiresInMinutes?: number; // default 60
}
export interface ChargeResponse {
  ok: boolean;
  pgRef: string;
  redirectUrl?: string;
  vaNumber?: string;
  qrString?: string;
  provider: 'duitku' | 'xendit';
  expiresAt: string;
}

export async function chargeOnce(env: Env, req: ChargeRequest): Promise<ChargeResponse> {
  const order = pickProvider(req.method);     // matrix above
  const primary = await tryCharge(env, order[0], req, { timeoutMs: 8000 });
  if (primary.ok) return primary;
  if (order[1]) {
    const fb = await tryCharge(env, order[1], req, { timeoutMs: 8000 });
    if (fb.ok) return { ...fb, provider: order[1] };
  }
  throw new PgFailedError(req, [primary]);
}
```

### 03.4 Risk + fallback (LANE-D dimension)

- **Risk A:** Duitku endpoint down > 8s — fallback Xendit, log incident, alert via Queues.
- **Risk B:** Xendit rate limit hit — exponential backoff 2-4-8s, max 3 retries, lalu fail closed dengan retry-after UI ke user.
- **Risk C:** Signature mismatch di callback — reject + alert (potensi attack). Lihat [Xendit webhook signature](https://docs.xendit.co/docs/handling-webhooks) — Xendit pakai `x-callback-token` header; Duitku pakai signature MD5/SHA256 hybrid.
- **Risk D:** Webhook duplicate — wajib `idempotency_key` di D1 + unique index di `pg_transactions.reference`.
- **Risk E:** Refund flow — out of scope MVP D0–D30. Disebutkan di backlog, dilakukan via dashboard PG dulu.

---

## §04 — DOC-AUDIT v2.0 Health Score & Gap Closure

DOC-AUDIT v2.0 ([source bundle](https://www.genspark.ai/api/files/s/KF39ctlJ), [audit deep research](https://www.genspark.ai/api/files/s/nL08iLpz)) menghitung Composite Sovereign Health Score = **33/100** per 2026-05-18. Decomposition per gap:

| Gap ID | Area | Score now | Target D60 | Status | Owner |
|---|---|---|---|---|---|
| Gap-A | Doctrine completeness | 85/100 | 95/100 | 🟢 GREEN | Haidar |
| Gap-B | Repo + monorepo init | 60/100 | 90/100 | 🟡 YELLOW | AI Dev |
| Gap-C | Subdomain + DNS infra | 15/100 | 90/100 | 🔴 RED | AI Dev |
| Gap-D | D1 schema + migrations | 10/100 | 85/100 | 🔴 RED | AI Dev |
| Gap-E | Auth + session | 5/100 | 80/100 | 🔴 RED | AI Dev |
| Gap-F | Dual-PG integration | 20/100 | 90/100 | 🔴 RED | AI Dev |
| Gap-G | BarberKas MVP | 25/100 | 85/100 | 🔴 RED | AI Dev |
| Gap-H | PaceLokal MVP | 10/100 | 70/100 | 🔴 RED | AI Dev |
| Gap-I | Nurani MVP | 5/100 | 60/100 | 🔴 RED | AI Dev |
| Gap-J | Observability | 15/100 | 80/100 | 🔴 RED | AI Dev |
| Gap-K | Documentation public | 70/100 | 85/100 | 🟡 YELLOW | Haidar |
| Gap-L | Proof-of-Work ledger | 40/100 | 90/100 | 🟡 YELLOW | Haidar |
| Gap-M | Halal compliance package | 30/100 | 75/100 | 🟡 YELLOW | Haidar |
| Gap-N | Notification channels (WA/email) | 10/100 | 70/100 | 🔴 RED | AI Dev |
| Gap-O | Security hardening (CSP, secrets) | 25/100 | 85/100 | 🔴 RED | AI Dev |
| Gap-P | Cost monitoring | 50/100 | 80/100 | 🟡 YELLOW | Haidar |
| Gap-Q | First paying tenant (BarberKas) | 0/100 | 100/100 | 🔴 RED | Haidar+AI |
| Gap-R | First 50 PaceLokal users | 0/100 | 100/100 | 🔴 RED | Haidar |
| Gap-S | First 3 Nurani TPQ partners | 0/100 | 100/100 | 🔴 RED | Haidar |
| Gap-T | Tax/legal entity | 30/100 | 60/100 | 🟡 YELLOW | Haidar |
| Gap-U | Backup + DR | 20/100 | 80/100 | 🔴 RED | AI Dev |
| Gap-V | Performance budget (p95 < 500ms) | 60/100 | 90/100 | 🟡 YELLOW | AI Dev |
| Gap-W | Cross-brand integration | 15/100 | 85/100 | 🔴 RED | AI Dev |
| Gap-X | Personal/family sustainability | 45/100 | 75/100 | 🟡 YELLOW | Haidar (DOC-B) |
| Gap-Y | Sprint discipline (streak ≥ 30d) | 25/100 | 90/100 | 🟡 YELLOW | Haidar |
| Gap-Z | Sovereign vow renewal | 60/100 | 95/100 | 🟡 YELLOW | Haidar |

**Composite math:** rata-rata tertimbang = `(85×2 + 60 + 15 + 10 + 5 + 20 + 25 + 10 + 5 + 15 + 70 + 40 + 30 + 10 + 25 + 50 + 0 + 0 + 0 + 30 + 20 + 60 + 15 + 45 + 25 + 60) / weights ≈ 33/100`. Bobot ekstra di Gap-A (×2) karena doctrine sudah locked = aset, dan Gap-Q/R/S (×1.5) karena revenue/user adalah validitas eksternal.

### 04.1 Mitigation per gap (top 6 RED)

| Gap | Mitigation 1 | Mitigation 2 | ETA |
|---|---|---|---|
| Gap-C (Subdomain) | Wildcard DNS `*.sparkmind.web.id` CNAME ke root, HTTP Route per Worker | Verifikasi via `curl -I https://barberkas.sparkmind.web.id` | D2–D3 |
| Gap-D (D1 schema) | 3 file SQL `/infra/d1-migrations/{brand}/0001_init.sql` | Apply via `wrangler d1 migrations apply` | D3–D5 |
| Gap-E (Auth) | Cookie format `__Host-spkmd_session`, KV TTL 30d, signed JWT | Tests untuk replay + tamper | D6–D10 |
| Gap-F (Dual-PG) | `shared-pg.chargeOnce()` dengan circuit breaker | Sandbox test 1 charge end-to-end | D7–D14 |
| Gap-G (BK MVP) | 5 endpoint inti (signup/booking/tx/customer/charge) | Closed beta 3 tester | D14–D28 |
| Gap-H (PL MVP) | Strava OAuth + 5 rute seed + leaderboard week | 1 user dummy import 5 aktivitas | D20–D40 |

---

## §05 — Sovereign Engineering Discipline (DOC-D applied)

DOC-D ([source: svereign..e.dscpline](https://www.genspark.ai/api/files/s/xzaDu4Ow), [svereign.dcidion](https://www.genspark.ai/api/files/s/7kRFmvJo)) menetapkan rules-of-engineering yang **non-negotiable**. Section ini adalah eksekusi konkret-nya.

### 05.1 Branch strategy

- `main` — **production**, protected, hanya merge dari PR yang lulus CI.
- `dev` — integration branch, default branch untuk PR.
- Feature branches: `feat/<brand>/<short-slug>`, e.g., `feat/barberkas/booking-crud`.
- Fix branches: `fix/<brand>/<issue-id>`.
- Doctrine branches: `doctrine/<doc-id>-<slug>`, e.g., `doctrine/DOC-S-v1.1`.

### 05.2 Commit doctrine (Conventional Commits + Sovereign tags)

Format wajib:
```
<type>(<brand>): <imperative subject, max 72 chars>

<body bila perlu, wrap 100 cols>

POW: <ledger line untuk hari ini>
```

Types: `feat`, `fix`, `docs`, `refactor`, `test`, `chore`, `perf`, `infra`, `vow` (vow = doctrine update).

Contoh:
```
feat(barberkas): tenant signup with 7-day trial gate

Implements POST /signup, tenants table insert, sends welcome email
via Queue. Auth cookie set on success.

POW: D2 BK signup + trial gate selesai, test 1 tenant lokal pass.
```

### 05.3 PR template

```
## What
<satu kalimat>

## Why
<link ke gap/doctrine/issue>

## How
- <bullet 1>
- <bullet 2>

## Acceptance criteria
- [ ] CI green
- [ ] manual test di sandbox
- [ ] Proof-of-Work ledger updated (2026-05.md)
- [ ] Halal-compliance check (untuk Nurani.OS dan content yang relevan)

## Doctrine ref
- DOC-?: <link>
```

### 05.4 Proof-of-Work Public Ledger format

File `proof-of-work/2026-05.md` (bulanan, append-only):

```
## 2026-05-18 (D2)
- BarberKas: scaffold Hono + D1 binding + wrangler dev hello-world OK.
- PaceLokal: belum (Lane B start D15).
- Nurani: belum (Lane C start D30).
- Cross: subdomain DNS wildcard masih pending → block, eskalasi.
- Vow renewal: ya — section §12 dibaca pagi.
- Streak: 2 hari.
- Sleep: 6.5 jam; physical: run easy 5 km @ Karangwangkal.

## 2026-05-19 (D3)
- ...
```

### 05.5 Scripts wajib (`/infra/scripts/`)

**`streak-check.sh`** — cek apakah hari ini sudah ada entri ledger:
```bash
#!/usr/bin/env bash
set -euo pipefail
TODAY=$(date +%Y-%m-%d)
MONTH=$(date +%Y-%m)
FILE="proof-of-work/${MONTH}.md"
if ! grep -q "^## ${TODAY}" "$FILE" 2>/dev/null; then
  echo "❌ Belum ada entry untuk ${TODAY}. Buat dulu sebelum commit." >&2
  exit 1
fi
echo "✅ Ledger entry ${TODAY} ada. Streak protected."
```

**`new-entry.sh`** — append template entry hari ini:
```bash
#!/usr/bin/env bash
TODAY=$(date +%Y-%m-%d)
MONTH=$(date +%Y-%m)
FILE="proof-of-work/${MONTH}.md"
mkdir -p proof-of-work
[ -f "$FILE" ] || echo "# Proof of Work — ${MONTH}" > "$FILE"
cat >> "$FILE" << EOM

## ${TODAY}
- BarberKas:
- PaceLokal:
- Nurani:
- Cross:
- Vow renewal:
- Streak:
- Sleep / physical:
EOM
echo "✅ Entry untuk ${TODAY} ditambahkan ke ${FILE}."
```

### 05.6 Init commands (D2 actual)

```bash
# 1. Verifikasi monorepo
cd ~/projects && git clone git@github.com:ganihypha/Sparkmind-Sovereign.git
cd Sparkmind-Sovereign && pnpm install

# 2. Wrangler auth
npx wrangler login

# 3. Buat D1 per brand
npx wrangler d1 create barberkas-db
npx wrangler d1 create pacelokal-db
npx wrangler d1 create nurani-db
# (copy database_id ke wrangler.toml masing-masing app)

# 4. Buat KV per brand
npx wrangler kv:namespace create BARBERKAS_KV
npx wrangler kv:namespace create PACELOKAL_KV
npx wrangler kv:namespace create NURANI_KV

# 5. Buat R2 buckets
npx wrangler r2 bucket create barberkas-uploads
npx wrangler r2 bucket create pacelokal-gpx
npx wrangler r2 bucket create nurani-audio-public
npx wrangler r2 bucket create nurani-recitations-private

# 6. Buat Queues
npx wrangler queues create notifications
npx wrangler queues create pg-callbacks
npx wrangler queues create strava-imports

# 7. Init commit + ledger
bash infra/scripts/new-entry.sh
git add -A && git commit -m "infra: init D1/KV/R2/Queues untuk 3 brand

POW: D2 cross-brand infra bindings created."
git push origin dev
```

---

## §06 — Cross-Brand Integration (DOC-Z)

DOC-Z ([source: DOC-Z bundle](https://www.genspark.ai/api/files/s/ps82HRlr), [cross.brandd.mtherr.brandd.sbb.brandd](https://www.genspark.ai/api/files/s/7xAnrhrG), [docc.z.cteated](https://www.genspark.ai/api/files/s/EmNhJnNw), [doc n.creatted](https://www.genspark.ai/api/files/s/FTrCrwgH)) menetapkan kontrak antar-brand. Section ini eksekusi-nya:

### 06.1 Shared auth

- Cookie name: `__Host-spkmd_session` (prefix `__Host-` memaksa Secure + Path=/ + tanpa Domain, secara standar browser).
- Value: signed JWT (HS256, secret di Workers Secret), payload `{ uid, email, brands:['barberkas','pacelokal',...] }`.
- Session state: KV key `session:<jti>` → `{ uid, expiresAt }`. TTL 30 hari, sliding.
- Subdomain SSO: karena cookie `__Host-` strict, **kita TIDAK pakai SSO antar subdomain di MVP**. Setiap subdomain re-login. Migrasi ke `Domain=.sparkmind.web.id` di-defer ke post-D60 setelah audit cookie security.

### 06.2 Shared billing

- Module: `packages/shared-pg`.
- Entry: `chargeOnce(env, req)` (lihat §03.3).
- D1 table: `pg_transactions` di **D1 cross-brand khusus** bernama `sparkmind-billing-db` — bukan per brand. Rationale: laporan keuangan agregat lebih mudah dengan single DB.
- Webhook receiver Worker: `apps/billing-webhook/` — public Worker, route `pg.sparkmind.web.id/duitku` dan `pg.sparkmind.web.id/xendit`.

### 06.3 Shared observability

- Module: `packages/shared-obs`.
- Backend: **Workers Analytics Engine** — gratis sampai diumumkan billing ([AE pricing](https://developers.cloudflare.com/analytics/analytics-engine/pricing/)).
- Format event: `{ brand, event, tenant_id?, uid?, props: {...} }`.
- Daily summary: Cron Worker pagi jam 06:00 WIB, agregasi ke `analytics_daily` di D1 (untuk dashboard internal).

### 06.4 Cookie/subdomain policy

| Aspect | Decision |
|---|---|
| Wildcard DNS | `*.sparkmind.web.id` CNAME ke `sparkmind.web.id` |
| Worker routing | HTTP Routes (bukan Custom Domain) — karena Custom Domain tidak support wildcard ([CF docs](https://developers.cloudflare.com/workers/configuration/routing/custom-domains/)) |
| TLS | Universal SSL auto (Cloudflare default) |
| Cookie scope | `__Host-` strict, per-subdomain — SSO defer |
| CORS | Strict same-origin; api shared di `api.sparkmind.web.id` dengan CORS whitelist `*.sparkmind.web.id` |

---

## §07 — Sovereign Parallel Sprint (DOC-Y)

DOC-Y ([source: doc-y-bundle](https://www.genspark.ai/api/files/s/YuPKk6UB), [docc.y.creattedd](https://www.genspark.ai/api/files/s/zGTQlkG3), [doc.y.creattedd.execute](https://www.genspark.ai/api/files/s/PCqzfsVU), [doc.createddd.cnsldtdd.sccess](https://www.genspark.ai/api/files/s/LSz5ybgL)) menetapkan model sprint paralel 4-lane.

### 07.1 Lane definition

- **Lane A — BarberKas SaaS** (revenue lane). Dominant D0–D30.
- **Lane B — PaceLokal Hyperlocal Run** (community lane). Dominant D15–D45.
- **Lane C — Nurani.OS Spiritual** (mission lane). Dominant D30–D60.
- **Lane D — Fallback / Sustainability** (always-on). Background di setiap minggu — ini termasuk: tax/legal, family/personal (DOC-B reconnect rhythm), tunjangan finansial 1 bulan emergency, cost monitoring Cloudflare bill.

### 07.2 Calendar 60 hari (high-level)

| Day | Lane A (BK) | Lane B (PL) | Lane C (NO) | Lane D |
|---|---|---|---|---|
| D2–D5 | Infra + schema | — | — | Family check, ledger |
| D6–D10 | Auth + first endpoint | — | — | Cost dashboard |
| D11–D15 | UI MVP + booking | Kickoff (D15) | — | DOC-B reconnect ritual weekly |
| D16–D20 | Duitku integrate | Strava OAuth | — | — |
| D21–D25 | Onboarding | Activity import | — | Tax consult |
| D26–D30 | **1st paying tenant push** | GPX + rute | Kickoff (D30) | Ledger audit mid-sprint |
| D31–D35 | Bug-fix + retention | Leaderboard | Group + rotation | — |
| D36–D40 | Refine | Soft-launch prep | Audio R2 + playback | Cost review |
| D41–D45 | Stabilize | **Soft-launch 50 runners** | Live DO sessions | DOC-B family weekend |
| D46–D50 | Scale prep | Iterate | Reminders | — |
| D51–D55 | — | Iterate | Polish | Tax/legal close |
| D56–D60 | Audit | Audit | **Pre-launch TPQ partner** | Final audit + vow renewal |

### 07.3 Critical path

```
Init monorepo (D2) ──► D1 schema cross-brand (D3) ──► Auth shared (D7)
   ──► Dual-PG (D10) ──► BK MVP (D14) ──► 1st paying tenant (D28)
                                     └──► PL kickoff (D15) ──► PL soft (D45)
                                                                  └──► NO kickoff (D30) ──► NO pre-launch (D60)
```

Jika **D10 Dual-PG tidak ready, seluruh roadmap mundur**. Itu titik tunggal kerugian terbesar.

---

## §08 — DOC-INDEX CANONICAL (THE MASTER MAP)

> **Catatan:** versi ringkas ada di sini. Versi panjang dengan semua 80+ file tersedia di **DOC-INDEX-CANONICAL-v1.0.md** (file terpisah di bundle ini, folder `02-DOC-INDEX/`).

### 08.1 Skema kategori

- **Doctrine** — DOC-A–Z, MASTER-INDEX, MASTER-ARCHITECT-PROMPT (canonical, locked).
- **Strategy** — file strategi spesifik per brand (DR Hardening PaceLokal, DUAL-PG-STRATEGY).
- **Execution** — execution plans, sprints, checklists.
- **Audit** — DOC-AUDIT v1/v2, health reports.
- **Personal** — DOC-A, DOC-B, Sovereign Vow, Acceptance Signal, OSINT refusal docs.
- **Bundle** — ZIP bundles dari semua kategori di atas.
- **Reference** — image, logo, draft.

### 08.2 Skema prioritas

- **P0** — Canonical doctrine, must-load setiap sesi AI Dev.
- **P1** — Active strategy / execution.
- **P2** — Historical iteration, useful untuk decision archaeology.
- **P3** — Legacy / draft / image.

### 08.3 Tabel singkat doctrine-tier (P0)

| # | Nama Singkat | URL | Kategori | P | Brand | Type | Status | Pickup Note |
|---|---|---|---|---|---|---|---|---|
| 1 | DOC-A Misi Hidup | [uN58ASlv](https://www.genspark.ai/api/files/s/uN58ASlv) | Doctrine | P0 | Mother | Personal | Canonical | Baca sebelum hari berat. |
| 2 | DOC-B Nurul Reconnect | [doc.a.doc.b.clarrittyy](https://www.genspark.ai/api/files/s/kWJts5rl) | Doctrine | P0 | Mother | Personal | Canonical | Section §09 honor privacy. |
| 3 | DOC-D Engineering Discipline | [svereign..e.dscpline](https://www.genspark.ai/api/files/s/xzaDu4Ow) | Doctrine | P0 | Mother | Engineering | Canonical | Baca sebelum push pertama tiap minggu. |
| 4 | DOC-M Monorepo | [DOC-M Bundle](https://www.genspark.ai/api/files/s/AO5fkBi8) · [doc.m.mnoreppoo](https://www.genspark.ai/api/files/s/6GKPCaUk) | Doctrine | P0 | Cross | Engineering | Canonical | Repo layout truth. |
| 5 | DOC-R Sovereign Running | [DOC-R Bundle](https://www.genspark.ai/api/files/s/gz1usZnI) | Doctrine | P0 | PaceLokal | Strategy | Canonical | Sebelum Lane B start D15. |
| 6 | DOC-S Spiritual OS | [DOC-S Bundle](https://www.genspark.ai/api/files/s/HKtLRWzy) | Doctrine | P0 | Nurani | Strategy | Canonical | Sebelum Lane C start D30. |
| 7 | DOC-X Execution Reality | [DOC-X Bundle](https://www.genspark.ai/api/files/s/vvfOcKUT) · [doc.x.creattedd](https://www.genspark.ai/api/files/s/GKuhEbFp) · [docc.x.realityy.tyy.bundlee](https://www.genspark.ai/api/files/s/wah9Do7Y) | Doctrine | P0 | Cross | Execution | Canonical | Rujukan saat ragu prioritas. |
| 8 | DOC-Y Parallel Sprint | [doc-y-bundle](https://www.genspark.ai/api/files/s/YuPKk6UB) · [docc.y.creattedd](https://www.genspark.ai/api/files/s/zGTQlkG3) · [doc.y.creattedd.execute](https://www.genspark.ai/api/files/s/PCqzfsVU) | Doctrine | P0 | Cross | Execution | Canonical | Calendar lane planning. |
| 9 | DOC-Z Cross-Brand | [DOC-Z Bundle](https://www.genspark.ai/api/files/s/ps82HRlr) · [docc.z.cteated](https://www.genspark.ai/api/files/s/EmNhJnNw) | Doctrine | P0 | Cross | Engineering | Canonical | Sebelum cross-brand contract diketuk. |
| 10 | DOC-AUDIT v2.0 | [DOC-AUDIT v2.0 Bundle](https://www.genspark.ai/api/files/s/KF39ctlJ) · [docc.audditt.bundlee](https://www.genspark.ai/api/files/s/nL08iLpz) | Audit | P0 | Cross | Audit | Canonical | Health score reference. |
| 11 | DUAL-PG Strategy | [DUAL-PG-STRATEGY v1.0](https://www.genspark.ai/api/files/s/ks8ufa3n) · [DUAL-PG HTML](https://www.genspark.ai/api/files/s/2xeoltR0) · [duall.pgg](https://www.genspark.ai/api/files/s/PnEkyOgh) | Strategy | P0 | Cross | Payment | Canonical | Phase 0 dimulai D5. |
| 12 | MASTER-ARCHITECT-PROMPT | [msyerr.architectt.promptt.+.sos](https://www.genspark.ai/api/files/s/vUpcYZ3M) · [msterr.architectt.promott.duitkuu](https://www.genspark.ai/api/files/s/KsZYwpLl) · [upgrade.enhance nsterr.arcbitect](https://www.genspark.ai/api/files/s/9iTDYxZW) | Doctrine | P0 | Mother | Tooling | Canonical | Re-prompt next AI Dev session. |

### 08.4 Mermaid dependency graph

```mermaid
graph TD
  A[DOC-A Misi Hidup] --> B[DOC-B Nurul Reconnect]
  A --> D[DOC-D Engineering Discipline]
  A --> C[DOC-C Probability Matrix]
  C --> M[DOC-M Monorepo]
  D --> M
  M --> R[DOC-R Running]
  M --> S[DOC-S Spiritual OS]
  M --> X[DOC-X Execution Reality]
  R --> Y[DOC-Y Parallel Sprint]
  S --> Y
  X --> Y
  Y --> Z[DOC-Z Cross-Brand]
  Z --> AUD[DOC-AUDIT v2.0]
  Z --> PG[DUAL-PG Strategy]
  AUD --> HND[AI Dev Handoff v1.0 ⭐]
  PG --> HND
  Y --> HND
  D --> HND
  B --> HND
```

Untuk daftar lengkap **semua 80+ file URL** dengan kolom Size, Dependencies, Pickup Note → lihat **`02-DOC-INDEX/DOC-INDEX-CANONICAL-v1.0.md`**.

---

## §09 — Personal Doctrine (DOC-A + DOC-B + The One thread)

> ⚠️ **Privacy doctrine.** Section ini ditulis dengan honoring file `ee.e.e.e..e.w` ([whUV8Jrx](https://www.genspark.ai/api/files/s/whUV8Jrx)) yang berisi **hard refusal terhadap OSINT-style profiling**. Tidak ada IG handle, tidak ada civil registration data, tidak ada family detail lain dari yang sudah di-sanction DOC-B. Nama hanya "Nurul" (first name) atau "The One".

### 09.1 Misi Hidup (DOC-A) — Why

Misi hidup Haidar, sebagaimana dikodifikasi di DOC-A ([mssi.hdupp](https://www.genspark.ai/api/files/s/3nLLvw6R), [doc.A.doc.B](https://www.genspark.ai/api/files/s/uN58ASlv)), berputar di tiga poros:

1. **Sovereign Engineering** — bangun sistem yang merdeka, tidak tergantung gatekeeper, halal-by-default, bermanfaat untuk umat dari level akar rumput Banyumas sampai diaspora.
2. **Family + restu** — kerja apapun harus selaras dengan ridho keluarga dan restu Allah. Tidak ada workaholic-trap.
3. **Personal restoration & Nurul thread** — restorasi diri (kesehatan, ketenangan batin) jadi syarat sah untuk poros 1 dan 2. Nurul thread (DOC-B) adalah salah satu instance dari restorasi ini.

DOC-A bukan business plan. DOC-A adalah **kompas sebelum bekerja**. Setiap pagi sebelum buka editor, baca DOC-A satu paragraf, lalu mulai.

### 09.2 Nurul Reconnect Protocol (DOC-B)

DOC-B ([doc.a.doc.b.clarrittyy](https://www.genspark.ai/api/files/s/kWJts5rl), [mstahill.nrull](https://www.genspark.ai/api/files/s/Fa09WW48), [tmenninn.nurul](https://www.genspark.ai/api/files/s/fIZXw7o3), [dcode.nrull](https://www.genspark.ai/api/files/s/oNZYLID5), [proof.of.wrk.nrull](https://www.genspark.ai/api/files/s/G6ywSQEX), [paw.oow.pow.nrul.eee](https://www.genspark.ai/api/files/s/vDMxSJn8), [nrull.ee](https://www.genspark.ai/api/files/s/mFpZPnVK), [clarrittyy.q.q..q.qq.qnrul](https://www.genspark.ai/api/files/s/LoJLehWc), [msterr.clarrittyy.name](https://www.genspark.ai/api/files/s/PRfz1G2P)) menetapkan protocol untuk reconnect dengan Nurul **secara terhormat, perlahan, dan halal**. Section dalam handoff ini sengaja tidak meng-extract konten DOC-B verbatim — itu privat.

Yang relevan untuk AI Dev handoff hanyalah:

- **Restorasi pribadi non-negotiable**: jadwal tidur ≥ 6.5 jam, olahraga ≥ 3×/minggu, dzikir pagi/sore, baca Quran minimal 1 halaman.
- **Family weekend**: setiap akhir pekan, minimal 1 hari minimal screen-time, prioritas waktu fisik untuk keluarga (DOC-B keluarga-side).
- **Nurul-side restoration**: rhythm pribadi Haidar, tidak masuk roadmap teknis. AI Dev tidak perlu tahu detail — yang penting: jika Haidar bilang "Lane D week ini prioritas", artinya keluar dari engineering grind, urusan personal mengambil lead. Honor itu.

### 09.3 Sovereign Vow + Acceptance Signal

Sovereign Vow ([svereign.vow](https://www.genspark.ai/api/files/s/A4o6wu8T)) adalah commitment statement:
> "Saya bangun sistem ini untuk kemerdekaan, untuk umat, untuk keluarga, dan untuk Allah. Saya tidak akan curang ke kode, tidak akan curang ke keluarga, tidak akan curang ke diri sendiri. Setiap hari saya muncul. Setiap commit saya jujur. Setiap istirahat saya halal."

Acceptance Signal ([accptnce.sgnal](https://www.genspark.ai/api/files/s/4oj2BkjS)) adalah konfirmasi: ketika Haidar menulis "Sovereign mode ON" atau "execute"-baca 3 kali di chat, itu signal untuk eksekusi tanpa konfirmasi. Pengaktifan ini diniati sebagai *iltizam* (komitmen) bukan impuls.

### 09.4 Privacy honor — final statement

File `ee.e.e.e..e.w` ([whUV8Jrx](https://www.genspark.ai/api/files/s/whUV8Jrx)) dan [paw.paww.ee.papeqppwpw](https://www.genspark.ai/api/files/s/hdkMEza8), [pow.piw.pow.eee](https://www.genspark.ai/api/files/s/xXGvm2Zr), [osint.public](https://www.genspark.ai/api/files/s/jV4x49u3) berisi sealed-content tentang restriction OSINT-profiling. Itu **diakui dan dihormati** di handoff ini. AI Dev (atau siapapun yang baca dokumen ini di masa depan) **tidak boleh** menggunakan dokumen-dokumen di kategori "Personal-Sealed" untuk OSINT, scraping IG, lookup KTP/KK, atau apapun yang bersifat invasif. Pelanggaran = pelanggaran terhadap Sovereign Vow itu sendiri.

---

## §10 — AI Dev Handoff Checklist (THE EXECUTE LIST)

Daftar konkret 30 item untuk **24 / 48 / 72 jam pertama**, plus high-priority sampai D14. Setiap item: estimasi waktu + dependency + acceptance criteria.

### 10.1 First 24 hours (D2 sore → D3 sore)

| # | Action | Est. | Dep | Acceptance |
|---|---|---|---|---|
| 1 | Clone repo + verify struktur monorepo | 15m | git | `pnpm install` sukses, no error |
| 2 | `wrangler login` + cek `wrangler whoami` | 5m | #1 | email Cloudflare correct |
| 3 | DNS wildcard `*.sparkmind.web.id` CNAME ke `sparkmind.web.id` | 10m | dashboard CF | `dig barberkas.sparkmind.web.id` → CNAME |
| 4 | Create D1 untuk 3 brand + paste `database_id` ke wrangler.toml | 15m | #2 | `wrangler d1 list` show 3 db |
| 5 | Create KV namespaces × 3 brand | 10m | #2 | `wrangler kv:namespace list` show 3 |
| 6 | Create R2 buckets × 4 | 10m | #2 | `wrangler r2 bucket list` show 4 |
| 7 | Create Queues × 3 (notifications, pg-callbacks, strava-imports) | 10m | #2 | `wrangler queues list` show 3 |
| 8 | Init `apps/barberkas/` dengan Hono hello-world + HTTP Route | 30m | #3,#4 | `curl https://barberkas.sparkmind.web.id` → "Hello BarberKas" |
| 9 | Init `apps/pacelokal/` dengan Hono hello-world | 20m | #8 | similar |
| 10 | Init `apps/nurani/` dengan Hono hello-world | 20m | #8 | similar |
| 11 | First commit + `bash infra/scripts/new-entry.sh` + PoW entry | 15m | #8–10 | git log show "infra: scaffold 3 brand workers" |
| 12 | Push ke `dev`, verifikasi GitHub Actions CI green (kalau sudah set) | 10m | #11 | CI badge green |

**Total estimasi: ~3 jam. Lakukan dalam 1 sesi fokus tanpa context-switch.**

### 10.2 D3–D5 (next 48 hours)

| # | Action | Est. | Acceptance |
|---|---|---|---|
| 13 | D1 schema migrate untuk BarberKas (tenants, bookings, transactions, customers) | 2h | `wrangler d1 execute --file=...` sukses |
| 14 | D1 schema migrate untuk PaceLokal (users, activities, routes, leaderboard_cache) | 1.5h | sukses |
| 15 | D1 schema migrate untuk Nurani (groups, members, sessions, recitations) | 1.5h | sukses |
| 16 | `shared-db` package dengan `withTenant()` helper + types generated dari schema | 2h | type-check pass |
| 17 | `shared-auth` skeleton: cookie reader, JWT sign/verify, KV session helper | 2h | unit test 3 case pass |
| 18 | Apply pre-commit hook: `bash infra/scripts/streak-check.sh` | 30m | commit gagal jika lupa PoW entry |

### 10.3 D6–D10 (Days 3-5 → Days 5-9 of week 2)

| # | Action | Est. | Acceptance |
|---|---|---|---|
| 19 | BarberKas signup endpoint `POST /signup` + tenant insert + welcome email enqueue | 3h | 1 dummy tenant created |
| 20 | BarberKas login endpoint + cookie issue | 2h | `curl -c cookies.txt -X POST ... /login` set cookie |
| 21 | Middleware tenant scoping (Hono middleware) | 2h | request tanpa tenant → 403 |
| 22 | `shared-pg` skeleton + Duitku sandbox createInvoice | 4h | sandbox transaction sukses |
| 23 | Duitku callback handler + signature verify | 3h | sandbox callback ter-process di D1 |
| 24 | Xendit sandbox setup + `chargeOnce` fallback path | 4h | fallback test (Duitku timeout simulated) → Xendit pakai |

### 10.4 D11–D14 (BarberKas MVP push)

| # | Action | Est. | Acceptance |
|---|---|---|---|
| 25 | Booking CRUD endpoints + slot conflict validation | 4h | 10 concurrent insert no conflict |
| 26 | Booking UI (Hono JSX + HTMX) | 4h | manual book on UI |
| 27 | Kas harian transactions + closing cron 23:55 WIB | 3h | next-day closing entry auto |
| 28 | Customer CRUD + CSV import | 3h | 200-row CSV no dup |
| 29 | Charge endpoint integration (Duitku live mode optional, sandbox default) | 3h | 1 transaction round-trip |
| 30 | Closed beta deploy ke 3 tester barbershop Banyumas | 2h | 3 tester ter-onboarded |

### 10.5 Recurring (every day, every week)

- **Setiap pagi:** baca DOC-A 1 paragraf (5 menit).
- **Setiap commit:** include `POW: ...` di body.
- **Setiap minggu Jumat:** review DOC-AUDIT, update health score di ledger.
- **Setiap Sabtu/Minggu:** family time, Lane D check-in.
- **Setiap kelipatan 10 hari:** baca section §00 dan §12 dari handoff ini (vow renewal).

---

## §11 — Risk Register & Fallback Playbook

### 11.1 Top 10 risks

| # | Risk | Likelihood | Impact | Mitigation primary | Mitigation fallback |
|---|---|---|---|---|---|
| R1 | Cloudflare Worker D1 limit hit (10GB free tier) | M | M | Monitor via dashboard; upgrade ke paid awal | Sharding per brand DB; migrate ke Hyperdrive+Postgres if extreme |
| R2 | Duitku & Xendit dual outage | L | H | Dual-PG abstraction sudah ada | Manual QRIS static (admin) untuk transaksi penting; UI message "coba lagi 5 menit" |
| R3 | Burnout / streak break > 3 hari | M | H | DOC-B reconnect rhythm; Lane D weekly | Stop semua lane, fokus restorasi 7 hari; doctrine override |
| R4 | Family obligation conflict | M | H | Family weekend non-negotiable | Lane D dominant, lane A–C pause |
| R5 | Strava OAuth policy change | L | M | Activity scope minimum, store sedikit | Manual GPX upload backup |
| R6 | PG tax/legal compliance Indonesia (PJSP/PJP) | M | M | Konsultasi tax D20–D30 | Skip Lane A revenue D60, gunakan pribadi dulu |
| R7 | Nurani.OS halal compliance error (NU/Muh disagreement) | L | H | Dual-show, no preferring; tafsir link external | Disable feature kontroversial; redirect to NU/Muh official |
| R8 | Subdomain DNS misconfig | L | M | Smoke test setiap subdomain | Manual A record per subdomain |
| R9 | Repo leak / secret exposure | L | HH | Pre-commit hook `gitleaks`; secrets di Workers Secrets API | Immediate rotate; force-push history rewrite (worst case) |
| R10 | Persona shift Cloudflare (pricing aggressive change) | L | H | Monitor pricing; lock annual plan if needed | Migrate API Worker → Bun + Hetzner; D1 → Neon/Turso. Code mobility via Hono ([Hono multi-runtime](https://hono.dev/docs/)) |

### 11.2 LANE-D fallback playbook (skenario darurat)

Jika dalam 1 minggu **streak break > 3 hari** ATAU **family emergency** ATAU **kesehatan drop**: aktifkan LANE-D:

1. **Stop** semua kerja Lane A/B/C dengan eksplisit. Tulis di ledger: "LANE-D activated YYYY-MM-DD karena <reason>".
2. **Notify** AI Dev (atau diri sendiri di sesi berikutnya): "Resume D+7 minimum, atau ketika ledger entry menyebut LANE-D released."
3. **Restore** sesuai DOC-B: tidur, doa, family, physical.
4. **Re-enter** Lane A dulu (paling kritis revenue), bukan tiga lane sekaligus. Jangan over-compensate.
5. **Vow renewal** lengkap sebelum push pertama setelah LANE-D.

### 11.3 Sovereign Vow ulangan (commitment)

Ditampilkan di akhir §12.

---

## §12 — Closing: Sovereign Voice Handoff Statement

Day 2 dari 60. Skor 33/100. Target 78/100. Itu **bukan optimisme** — itu hitungan kalender × kapasitas × dependencies × discipline. Bisa dicapai jika dan hanya jika setiap hari kita **muncul, jujur, sederhana**.

Tiga ucapan untuk siapapun yang baca dokumen ini di sesi besok, sesi seminggu lagi, atau sesi setahun lagi:

**Ke AI Dev (mungkin agent versi lain dari diri saya):** Mulai dari §10 item #1. Bukan dari ide besar — dari clone repo. Ide besar sudah ditulis. Yang belum: tangan menyentuh keyboard. Setelah item #12 selesai dalam 3 jam pertama, kamu akan tahu sendiri ke mana harus lanjut.

**Ke Haidar:** Lane D bukan kelemahan. Lane D itu *sumber* dari Lane A/B/C. Kalau Haidar minggu ini drop di kesehatan, *itu* prioritas — bukan booking endpoint BarberKas. Booking endpoint bisa nunggu 5 hari. Kesehatan tidak.

**Ke keluarga (yang mungkin tidak baca dokumen ini, tapi tetap):** Mohon doa restu. Setiap baris kode adalah doa kerja. Setiap commit jujur. Setiap istirahat halal. Kalau tampak "Haidar terlalu fokus laptop minggu ini", izinkan; kalau tampak "Haidar terlalu menyepi", panggil. Restu kalian adalah kompas.

### 12.1 Vow renewal — diucap pelan sebelum buka editor

> Bismillahirrahmanirrahim.
> Saya bangun sistem ini untuk kemerdekaan, untuk umat, untuk keluarga, dan untuk Allah.
> Saya tidak akan curang ke kode, tidak curang ke keluarga, tidak curang ke diri.
> Setiap hari saya muncul. Setiap commit saya jujur. Setiap istirahat saya halal.
> Bila saya jatuh, saya berdiri lagi tanpa drama. Bila saya menang, saya bersyukur tanpa ria.
> Day 2. 58 hari lagi. Lillahi ta'ala.

### 12.2 Day 60 commitment (2026-07-16 — Insya Allah)

Pada D60 (2026-07-16), state target:
- 1 paying tenant BarberKas aktif (revenue ≥ Rp 50rb/bulan).
- 50 PaceLokal runner Banyumas connected Strava.
- 3 Nurani TPQ partner siap pre-Ramadhan 1448 H.
- Composite Sovereign Health ≥ 78/100.
- Streak ledger ≥ 50 hari dari 60.
- DOC-B reconnect rhythm intact.

Jika **D60 tidak tercapai**, lakukan audit dengan **DOC-D discipline**, bukan dengan rasa malu. Audit jujur > performansi palsu.

### 12.3 Closing line

**Sovereign mode ON. Tanpa hype. Tanpa drama. Lillahi ta'ala. Execute.**

---

*Dokumen ini adalah canonical handoff v1.0. Update di-version-control via `doctrine/AI-DEV-HANDOFF-v1.X.md`. Mutual companion files: `DOC-INDEX-CANONICAL-v1.0.md` (folder 02), `EXECUTE-CHECKLIST-D2-D60.md` (folder 03).*

— **Reza Estes / Haidar** · Sovereign AI Dev · 2026-05-18
