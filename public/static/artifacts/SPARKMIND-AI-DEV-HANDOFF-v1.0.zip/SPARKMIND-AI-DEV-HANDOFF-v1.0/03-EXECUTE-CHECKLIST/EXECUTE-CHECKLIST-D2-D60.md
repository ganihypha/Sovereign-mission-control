# EXECUTE-CHECKLIST D2 → D60 — Kanban Action List

> SparkMind Sovereign 60-day sprint actionable checklist.
> Tanggal mulai: **2026-05-18 (D2)** · Tanggal selesai target: **2026-07-16 (D60)**
> Owner: Reza Estes / Haidar · Companion ke handoff §10.
> Lihat juga: `01-HANDOFF-MAIN/SPARKMIND-AI-DEV-HANDOFF-v1.0.md` untuk konteks penuh.

## Konvensi

- `[ ]` = belum
- `[~]` = in progress
- `[x]` = done
- `[!]` = blocked (catat alasan di samping)
- Tag: `(BK)` BarberKas · `(PL)` PaceLokal · `(NO)` Nurani.OS · `(X)` Cross-brand · `(D)` Lane D personal/legal/family

---

## 🚀 WEEK 1 — Foundation (D2–D8)

### D2 (Senin 2026-05-18) — Today, kickoff
- [ ] (X) Clone repo `Sparkmind-Sovereign`, `pnpm install` clean
- [ ] (X) `wrangler login` + `wrangler whoami` verified
- [ ] (X) DNS wildcard `*.sparkmind.web.id` CNAME → `sparkmind.web.id`
- [ ] (X) Create D1: `barberkas-db`, `pacelokal-db`, `nurani-db`, `sparkmind-billing-db`
- [ ] (X) Create KV: `BARBERKAS_KV`, `PACELOKAL_KV`, `NURANI_KV`
- [ ] (X) Create R2: `barberkas-uploads`, `pacelokal-gpx`, `nurani-audio-public`, `nurani-recitations-private`
- [ ] (X) Create Queues: `notifications`, `pg-callbacks`, `strava-imports`
- [ ] (BK) Scaffold `apps/barberkas/` Hono hello-world + HTTP Route
- [ ] (PL) Scaffold `apps/pacelokal/` Hono hello-world
- [ ] (NO) Scaffold `apps/nurani/` Hono hello-world
- [ ] (X) PoW ledger entry untuk D2 di `proof-of-work/2026-05.md`
- [ ] (X) First commit + push ke `dev`
- [ ] (D) Sleep ≥ 6.5h, dzikir, run easy 5km (opsional bila energy ok)

### D3 (Selasa 2026-05-19)
- [ ] (BK) D1 schema migration 0001: `tenants`, `users`, `sessions`
- [ ] (BK) D1 schema migration 0002: `bookings`, `services`
- [ ] (X) `packages/shared-db` package init + types generator
- [ ] (X) `packages/shared-auth` skeleton (cookie reader, JWT sign/verify)
- [ ] (X) Pre-commit hook: `streak-check.sh`
- [ ] (X) PoW entry D3

### D4 (Rabu 2026-05-20)
- [ ] (BK) D1 schema migration 0003: `transactions`, `customers`
- [ ] (X) `packages/shared-auth`: KV session helper + integration test
- [ ] (X) GitHub Actions CI: lint + type-check + test pipeline
- [ ] (BK) Hono middleware `tenantScope()` — auto-inject tenant_id ke query context
- [ ] (X) PoW entry D4

### D5 (Kamis 2026-05-21)
- [ ] (X) Sign up Duitku sandbox account (atau check existing)
- [ ] (X) Sign up Xendit sandbox account (atau check existing)
- [ ] (X) Store secrets via `wrangler secret put`: `DUITKU_KEY`, `DUITKU_CODE`, `XENDIT_KEY`, `JWT_SECRET`
- [ ] (X) `packages/shared-pg` skeleton interface + types
- [ ] (X) Duitku `createInvoice` standalone test via cURL — sandbox sukses
- [ ] (X) PoW entry D5

### D6 (Jumat 2026-05-22)
- [ ] (BK) `POST /signup` endpoint full + welcome email enqueue
- [ ] (BK) `POST /login` + cookie set
- [ ] (BK) `GET /me` protected endpoint test
- [ ] (X) Weekly review: DOC-AUDIT health score update di ledger
- [ ] (X) PoW entry D6
- [ ] (D) Plan weekend: family time (Sabtu prioritas)

### D7 (Sabtu 2026-05-23) — Lane D dominant
- [ ] (D) Family weekend — minimal 1 hari minimal-screen
- [ ] (D) Personal check: tidur, makan, doa
- [ ] (X) PoW entry singkat (Lane D-only OK)

### D8 (Minggu 2026-05-24) — Lane D + light Lane A
- [ ] (D) Light: review minggu lalu, plan minggu depan
- [ ] (BK) Light: catat ide UI booking di Notes/Obsidian
- [ ] (X) PoW entry D8

---

## ⚙️ WEEK 2 — BarberKas Auth + Dual-PG Skeleton (D9–D15)

### D9 (Senin 2026-05-25)
- [ ] (BK) Booking CRUD endpoints (`POST/GET/PATCH/DELETE /api/bookings`)
- [ ] (BK) Slot conflict validation (D1 transaction + unique partial index)
- [ ] (X) PoW entry D9

### D10 (Selasa 2026-05-26) — 🎯 Dual-PG D-DAY
- [ ] (X) `shared-pg.chargeOnce(env, req)` end-to-end Duitku sandbox
- [ ] (X) Duitku callback handler Worker + signature verify HMAC
- [ ] (X) Idempotency table `pg_transactions` di `sparkmind-billing-db`
- [ ] (X) Smoke test: 1 sandbox transaction round-trip
- [ ] (X) PoW entry D10 — celebrate satu langkah besar

### D11 (Rabu 2026-05-27)
- [ ] (X) Xendit `createInvoice` integration di `shared-pg`
- [ ] (X) Fallback path: simulate Duitku timeout 8s → verify Xendit dipakai
- [ ] (X) Xendit callback handler + `x-callback-token` verify ([Xendit webhook docs](https://docs.xendit.co/docs/handling-webhooks))
- [ ] (X) PoW entry D11

### D12 (Kamis 2026-05-28)
- [ ] (BK) Booking UI dasar (Hono JSX + HTMX) — list + form
- [ ] (BK) Kas transaksi UI — add revenue/expense, daily summary
- [ ] (X) PoW entry D12

### D13 (Jumat 2026-05-29)
- [ ] (BK) Customer CRUD + CSV import
- [ ] (BK) Daily closing Cron Worker 23:55 WIB
- [ ] (X) Weekly review DOC-AUDIT
- [ ] (X) PoW entry D13

### D14 (Sabtu 2026-05-30) — Lane D
- [ ] (D) Family weekend
- [ ] (D) DOC-B reconnect rhythm check (private)

### D15 (Minggu 2026-05-31) — 🎯 PaceLokal Kickoff
- [ ] (PL) `apps/pacelokal/` schema migration 0001: `users`, `strava_accounts`, `activities`
- [ ] (PL) Strava OAuth app registered di Strava dev portal (callback `https://pacelokal.sparkmind.web.id/auth/strava/cb`)
- [ ] (PL) `/auth/strava` redirect endpoint
- [ ] (X) PoW entry D15

---

## 🏃 WEEK 3 — PL Verify-Stub + BK MVP polish (D16–D22)

### D16 (Senin 2026-06-01)
- [ ] (PL) Strava OAuth callback + token exchange + store in KV+D1
- [ ] (PL) Strava webhook subscription registration
- [ ] (BK) Duitku live mode test (1 transaksi pribadi, refund manual)
- [ ] (X) PoW entry D16

### D17 (Selasa 2026-06-02)
- [ ] (PL) `/webhook/strava` endpoint + enqueue to `strava-imports`
- [ ] (PL) Consumer Worker — parse activity payload, fetch detail dari Strava API, simpan ke D1
- [ ] (X) PoW entry D17

### D18 (Rabu 2026-06-03)
- [ ] (PL) GPX parser sederhana (polyline simplify, no PostGIS)
- [ ] (PL) Route schema + admin upload GPX endpoint
- [ ] (PL) Seed 5 rute Banyumas (Alun Loop, GOR Satria, Baturraden uphill, Karangwangkal Loop, Unsoed)
- [ ] (X) PoW entry D18

### D19 (Kamis 2026-06-04)
- [ ] (PL) Rute matching algoritma: compare activity polyline vs route polyline, threshold tolerance
- [ ] (PL) Leaderboard insert pada match
- [ ] (X) PoW entry D19

### D20 (Jumat 2026-06-05)
- [ ] (D) Tax/legal consult (akuntan/konsultan PJSP atau equivalent)
- [ ] (BK) Outreach prep: 3 calon barbershop tester di Purwokerto
- [ ] (X) Weekly review
- [ ] (X) PoW entry D20

### D21–D22 (Weekend)
- [ ] (D) Family weekend
- [ ] (D) Optional: ikut Sunday Morning Run Banyumas Runners 06:00 (sambil observe komunitas)

---

## 🎯 WEEK 4 — Mid-Sprint Push (D23–D30): BK 1st Tenant + PL Leaderboard

### D23–D25
- [ ] (BK) Onboarding flow polish, email/WA template via Queues
- [ ] (BK) Outreach 3 calon paying tenant Purwokerto
- [ ] (PL) Leaderboard UI (`/rutes/<id>/leaderboard?period=week`)
- [ ] (PL) KV cache 1h untuk leaderboard

### D26–D28
- [ ] (BK) **🎯 1st PAYING TENANT** activation push
- [ ] (BK) Bug-fix loop dari tester feedback
- [ ] (PL) Komunitas page `/komunitas/banyumas-runners` seed
- [ ] (X) Mid-sprint DOC-AUDIT — update health score, target ≥ 50/100

### D29–D30 — 🎯 Nurani.OS Kickoff
- [ ] (NO) `apps/nurani/` schema 0001: `tadarus_groups`, `members`, `sessions`, `recitations`
- [ ] (NO) R2 buckets verified, public/private access policy
- [ ] (NO) Hono hello-world live di `nurani.sparkmind.web.id`

---

## 🕌 WEEK 5 — Nurani Engine + PL Polish (D31–D37)

### D31–D33
- [ ] (NO) Group create + invite link
- [ ] (NO) Rotation engine algoritma (30 juz / N orang / X hari)
- [ ] (NO) Test: 30 dummy members → rotation generated correctly
- [ ] (PL) Bug-fix leaderboard, performance tuning < 500ms p95

### D34–D35
- [ ] (NO) Audio R2 multipart upload endpoint
- [ ] (NO) Audio playback stub (HTML5 audio dari R2 public)
- [ ] (BK) Retention check: 1st paying tenant masih aktif?

### D36–D37 (Weekend)
- [ ] (D) Family weekend
- [ ] (D) Cost review: Cloudflare bill bulan pertama

---

## 📣 WEEK 6 — PL Soft-Launch + NO Live DO (D38–D45)

### D38–D40
- [ ] (PL) Soft-launch prep: IG post draft, copywriting, demo video 30s
- [ ] (NO) Durable Objects scaffolding untuk live session
- [ ] (NO) Presence + cursor logic (siapa baca ayat berapa)

### D41–D43
- [ ] (PL) **🎯 SOFT-LAUNCH** ke 50 runner Banyumas
- [ ] (PL) Onboarding bantuan via WA group
- [ ] (NO) Reminder Queue: cron 04:30 dan 22:00 WIB

### D44–D45 (Weekend)
- [ ] (D) Family weekend — celebrate 50 runners (kalau tercapai)
- [ ] (X) Mid-late audit: status semua lane

---

## 🔧 WEEK 7 — Stabilize + NO Polish (D46–D52)

### D46–D48
- [ ] (BK) Stabilization pass: error handling, edge cases
- [ ] (PL) Iterate berdasarkan feedback 50 runners
- [ ] (NO) Halal-compliance check oleh ustadz/kyai (NU + Muhammadiyah)

### D49–D50
- [ ] (D) Tax/legal close: dokumen siap (NIB, PJSP/PJP awareness)
- [ ] (NO) Audio playback polish, recitation upload UX

### D51–D52 (Weekend)
- [ ] (D) Family weekend
- [ ] (D) Personal restoration audit

---

## 🏁 WEEK 8–9 — Final Push (D53–D60)

### D53–D55
- [ ] (X) Security hardening: CSP headers, secrets audit, gitleaks
- [ ] (X) Backup + DR rehearsal: D1 export, R2 cross-region replication
- [ ] (NO) Soft-launch internal: 1 TPQ test 5–10 jamaah

### D56–D58
- [ ] (NO) **🎯 PRE-LAUNCH** outreach: 3 TPQ partner siap Ramadhan 1448H
- [ ] (BK) Final retention check 1st tenant
- [ ] (PL) Final leaderboard polish

### D59 (Kamis 2026-07-15)
- [ ] (X) Final DOC-AUDIT v3.0 — target 78/100
- [ ] (X) Vow renewal session: baca §12, ucap pelan
- [ ] (X) Update DOC-INDEX v1.1 dengan file baru selama 60 hari

### D60 (Jumat 2026-07-16) — 🎯 FINAL DAY
- [ ] (X) Tulis closing ledger entry — narasi singkat 60 hari
- [ ] (X) Commit `vow(): 60-day sprint complete — alhamdulillah`
- [ ] (X) Plan next sprint (D61–D120) — DOC-Y v1.1
- [ ] (D) Family celebration

---

## 📌 Recurring rhythms (jangan dilewat)

- **Setiap pagi (Senin–Jumat):**
  - 5 menit baca DOC-A 1 paragraf
  - `bash infra/scripts/streak-check.sh` (atau pre-commit handle)
- **Setiap sore (Senin–Jumat):**
  - PoW ledger entry di `proof-of-work/2026-05.md` (atau bulan aktif)
  - Setidaknya 1 commit jujur (boleh kecil)
- **Setiap Jumat sore:**
  - Weekly review: status semua lane, update DOC-AUDIT
  - Plan minggu depan: 3 prioritas saja
- **Setiap Sabtu–Minggu:**
  - Lane D dominant: family, doa, rest
  - Minimal screen-time 1 hari penuh
- **Setiap kelipatan 10 hari (D10/D20/D30/D40/D50/D60):**
  - Baca §00 + §12 handoff
  - Vow renewal singkat
  - Mid-sprint pivot decision kalau ada

---

## 🚨 LANE-D Trigger (jangan-malu pakai)

Aktifkan LANE-D kalau salah satu terjadi:
- Streak break > 3 hari
- Sakit > 1 hari
- Family emergency
- Burnout signal (irritable, gak fokus 2 hari berturut)

Aktivasi: tulis di ledger "LANE-D activated YYYY-MM-DD karena <reason>", lalu **stop semua Lane A/B/C 7 hari minimum**.

---

*Dokumen ini hidup. Update bebas tiap hari. Yang penting: streak entry, vow intact, commit jujur.*
*Companion: `SPARKMIND-AI-DEV-HANDOFF-v1.0.md` §10 untuk detail acceptance criteria per task.*

**Sovereign mode ON. Lillahi ta'ala. Execute.**
