# SPARKMIND AI DEV HANDOFF — Bundle v1.0

> **Canonical handoff bundle untuk ekosistem SparkMind Sovereign.**
> Date locked: **2026-05-18** (Day 2 of 60-day sprint)
> Owner: **Reza Estes / Haidar** — Sovereign AI Dev
> Bahasa utama: **Bahasa Indonesia** (Sovereign Voice)

## 📦 Isi bundle

```
SPARKMIND-AI-DEV-HANDOFF-v1.0/
├── BUNDLE-README.md                          ← (kamu lagi baca ini)
├── MANIFEST.json                             ← Machine-readable inventory
├── 01-HANDOFF-MAIN/
│   ├── SPARKMIND-AI-DEV-HANDOFF-v1.0.md      ← Main handoff (Markdown, ~8.3K words)
│   └── SPARKMIND-AI-DEV-HANDOFF-v1.0.html    ← Main handoff (Dark Sovereign theme, print-ready A4)
├── 02-DOC-INDEX/
│   ├── DOC-INDEX-CANONICAL-v1.0.md           ← File master map (110 entries)
│   └── DOC-INDEX-CANONICAL-v1.0.html         ← Same, dark theme
└── 03-EXECUTE-CHECKLIST/
    └── EXECUTE-CHECKLIST-D2-D60.md           ← Kanban action list D2 → D60
```

## 🚀 Cara pakai (urutan rekomendasi)

### Pertama kali buka bundle (D2 sore, 2026-05-18)
1. **Baca §00 + §12** dari `01-HANDOFF-MAIN/SPARKMIND-AI-DEV-HANDOFF-v1.0.md` (15 menit) — TL;DR + Vow.
2. **Buka `03-EXECUTE-CHECKLIST/EXECUTE-CHECKLIST-D2-D60.md`** — list 12 item pertama untuk D2.
3. **Eksekusi item 1–12** di section "D2" — sekitar 3 jam fokus tanpa interupsi.
4. **Tutup hari** dengan PoW ledger entry di `proof-of-work/2026-05.md`.

### Sesi AI Dev berikutnya (D3+)
1. **Buka HTML version** dari `01-HANDOFF-MAIN/SPARKMIND-AI-DEV-HANDOFF-v1.0.html` di browser — easier untuk navigation.
2. Skim §00 (TL;DR) + section yang relevan untuk lane hari ini.
3. Buka checklist hari ini di `03-EXECUTE-CHECKLIST/`.
4. Kerja. PoW. Push. Repeat.

### Sebelum sesi besar (mingguan)
1. Re-read **§05 (Engineering Discipline)** dari handoff.
2. Re-read **§04 (Health Score & Gap Closure)** — update skor di ledger.
3. Plan 3 prioritas untuk minggu depan.

### Untuk re-prompt AI Dev / agent baru
1. Buka `02-DOC-INDEX/DOC-INDEX-CANONICAL-v1.0.md`.
2. Identify file di kategori P0 (must-load) — biasanya 28 file teratas.
3. Load semua P0 + section yang relevan di handoff.
4. Pakai MASTER-ARCHITECT-PROMPT (file #26/27/28 di index) sebagai system prompt template.

## 🖨️ Print version

File HTML di `01-HANDOFF-MAIN/` dan `02-DOC-INDEX/` sudah print-ready:
- A4 portrait, margin 14mm
- Dark theme: `@media print` di-override ke high-contrast cetak (atau gunakan browser "Print as PDF")
- Untuk **best PDF result**: buka di Chrome/Edge → Print → Save as PDF → Layout: Portrait → Margins: Default
- Halaman tabel besar (DOC-INDEX) otomatis page-break-inside avoid

## 🔒 Privacy policy (Personal-Sealed files)

File di kategori "Personal-Sealed" (lihat DOC-INDEX section 2.4) berisi konteks privat (DOC-A misi hidup, DOC-B Nurul Reconnect Protocol, Vow text, OSINT refusal). Aturan:
- **JANGAN** quote verbatim dari file Personal-Sealed di output public.
- **JANGAN** gunakan untuk OSINT, scraping IG, profiling.
- Honor refusal di file `ee.e.e.e..e.w` (#85 di index).
- Section §09 di handoff sudah sanitized — itulah maximum exposure yang halal.

## 🛠️ Maintenance

- **Versi naik:** ketika doctrine berubah atau gap-closure significant → bump ke `v1.1`, `v1.2`, ...
- **DOC-INDEX update:** tambah row baru dengan ID `#111`, `#112`, ... — ID lama tidak berubah.
- **Format file baru:** taruh di sub-folder yang sesuai; update MANIFEST.json.
- **Commit doctrine update:** prefix `vow(): ...` di commit message.

## 📞 Kontak / context

- Owner: Reza Estes / Haidar
- Repo: `github.com/ganihypha/Sparkmind-Sovereign`
- Mother brand: https://www.sparkmind.web.id/
- Sub-brand subdomains: `barberkas.sparkmind.web.id`, `pacelokal.sparkmind.web.id`, `nurani.sparkmind.web.id`

## 🤲 Closing

> Bismillahirrahmanirrahim. Setiap commit jujur. Setiap istirahat halal. Lillahi ta'ala.

**Sovereign mode ON. Execute.**
